# Run logs

Raw stdout of every run. Training lines carry the per-epoch validation metric
used for early stopping and model selection; `DONE` lines carry the test metrics
of the selected checkpoint; attack logs end with the evasion rate.

| File | What it covers |
|---|---|
| `qA*.log`, `qB*.log`, `qC*.log` | early BMD and ClaMP training sweeps |
| `qD2.log`, `qD3.log` | MOTIF training (CertiProto, R-GAT, twin, MLP on EMBER) |
| `qE.log`, `qF.log`, `qL2.log` | MOTIF LightGBM on EMBER vectors, retuned (lr 0.3, 15 leaves) |
| `qR2.log` | MOTIF insertion test (`motif_robust.py`) |
| `qAbl.log` | ClaMP ablation, three seeds per variant, then ablation attacks |
| `qExpl.log` | faithfulness run for the no-MIL ablation |
| `post_bmd*.log`, `post_clamp.log` | calibration, certified curves, explanations |
| `atk_bmd.log` | first attack budget (25 insertions, or 15 + 4 edits) |
| `atk_hi_bmd.log`, `atk_hi_bmd2.log` | **reported** attack (40 insertions, or 20 + 8 edits) |
| `atk_hi_clamp.log` | ClaMP insertion-only at budget 60 |
| `atk_hi_clamp2.log` | ClaMP strong attack (40 insertions, or 20 + 8 edits) |
| `probe_*.log` | design probes that were **rejected** (see below) |
| `lgbtest.log` | LightGBM hyper-parameter probe on MOTIF |
| `qMlp.log`, `motifpost.log` | extra MLP seeds on BMD; MOTIF post-processing queue |

## Rejected design probes

These were run, judged on validation data, and not adopted. They are kept so the
selection can be checked rather than taken on trust.

| Probe | Log | Outcome |
|---|---|---|
| 26 epochs + 64 prototypes, BMD | `probe_bmd.log` | validation AUC below the 14-epoch run at every matched epoch |
| 28 epochs, BMD | `probe_bmd2.log` | validation AUC 0.9908 against 0.9921 for the shorter schedule |
| 120 epochs, MOTIF | `probe_motif.log` | validation accuracy 0.689 against 0.668, but test accuracy 0.651 against 0.654 |
| piecewise-linear monotone count encoder | `probe_knots.log`, `probe_bmd_kn.log`, `probe_motif_kn.log` | +0.11 validation AUC on ClaMP, −0.14 on BMD: within seed noise |

The count encoder survives in the code as `CP_KNOTS` (see `src/cplib.py`) and is
off by default.
