#!/bin/bash
# Run jobs one after another on a small machine.
#   ./scripts/queue.sh <logname> "<dataset>:<model>:<seeds>" ...
# e.g. ./scripts/queue.sh runA bmd:certiproto-i:0,1,2 clamp:rgat:0,1,2,3,4
ROOT="${CERTIPROTO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
name=$1; shift
mkdir -p "$ROOT/logs"
for job in "$@"; do
  IFS=: read ds model seeds <<< "$job"
  if [[ $model == lgbm* || $model == mlp* ]]; then
    python3 "$ROOT/src/flat.py" "$ds" "$model" "$seeds" >> "$ROOT/logs/$name.log" 2>&1
  else
    python3 "$ROOT/src/train.py" "$ds" "$model" "$seeds" >> "$ROOT/logs/$name.log" 2>&1
  fi
  echo "FINISHED $job $(date)" >> "$ROOT/logs/$name.log"
done
echo ALLDONE >> "$ROOT/logs/$name.log"
