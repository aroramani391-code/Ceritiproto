#!/bin/bash
# Rebuild the manuscript and report its page count.
set -e
ROOT="${CERTIPROTO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
OUT="${1:-$ROOT/out/CertiProto_paper.docx}"
mkdir -p "$(dirname "$OUT")"
python3 "$ROOT/paper/build_paper.py" "$OUT"
if command -v soffice >/dev/null; then
  soffice --headless --convert-to pdf --outdir "$(dirname "$OUT")" "$OUT" >/dev/null
  pdfinfo "${OUT%.docx}.pdf" | grep Pages || true
fi
