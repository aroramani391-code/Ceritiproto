"""Repository root. Override with the CERTIPROTO_ROOT environment variable.

All scripts write under $CERTIPROTO_ROOT/{prep,results,figs,logs}; the datasets
are read from $CERTIPROTO_ROOT/data unless a script says otherwise.
"""
import os

ROOT = os.environ.get(
    'CERTIPROTO_ROOT',
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
)
