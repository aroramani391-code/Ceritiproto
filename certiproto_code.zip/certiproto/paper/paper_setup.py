"""Section 6: experimental setup (compact version)."""


def setup(d, R):
    S = R['stats']
    b, c, m = S['bmd'], S['clamp'], S['motif']
    d.h1('6. Experimental setup')
    d.h2('6.1 Datasets and splits')
    d.para('Three public datasets are used as released static metadata; no binary was downloaded or executed. The *Brazilian '
           'Malware Dataset* (BMD) publishes header fields, imports and packer or compiler identifications for goodware and '
           'for malware collected by day. <<The release used here is the public repository of \\cite{ceschin2018}, taken at '
           'the state of the `master` branch on 7 October 2026 (file `brazilian-malware.csv.zip`); the repository has grown '
           'since the 2018 article, so the window reported below is the one observed in that file rather than the one '
           f'described in the article. After removing duplicate SHA-1 hashes and 21 hashes labelled both ways, {b["n"]:,} '
           f'programs remain, dated from {b.get("tmin", "")} to {b.get("tmax", "")}.>> The split is time-aware: programs '
           'dated before 1 January 2015 form the training period (15% held out by hash for validation) and all later '
           'programs the test set, with malware dated by its first-seen day and goodware, which has none published, by its '
           'compile timestamp. Functions, listed without their libraries, are attached to an imported library known to export them (from '
           f'MOTIF import tables and single-library BMD files); {b["api_resolved"] * 100:.1f}% are resolved and the rest attach '
           'to the root. *ClaMP* '
           '\\cite{kumar2019} gives 69 header features per file, grouped under DOS, file, optional-header and section hubs, '
           'with five stratified 70/15/15 splits. *MOTIF* \\cite{joyce2023} releases raw features in the format of EMBER '
           f'(Endgame Malware BEnchmark for Research) for 3,095 malware files; following its protocol, singleton families are '
           f'removed, leaving {m["kept"]:,} files in {m["families"]} families, with five-fold stratified cross-validation and '
           '10% of every family with at least three training files (8% of the fold) held out for validation. Header values '
           'seen fewer than twice in training back off to a logarithmic bucket token. Table 2 summarises the graphs.')
    rows = [['Dataset', 'Task', 'Malware / benign', 'Split', 'Train / val. / test', 'Mean nodes', 'Mean hubs'],
            ['BMD \\cite{ceschin2018}', 'Detection', f'{b["mal"]:,} / {b["ben"]:,}', 'Time-aware', f'{b["tr"]:,} / {b["va"]:,} / {b["te"]:,}', f'{b["nodes_mean"]:.1f}', f'{b["hubs_mean"]:.1f}'],
            ['ClaMP \\cite{kumar2019}', 'Detection', f'{c["mal"]:,} / {c["ben"]:,}', 'Stratified', f'{c["tr"]:,} / {c["va"]:,} / {c["te"]:,}', f'{c["nodes_mean"]:.1f}', f'{c["hubs_mean"]:.1f}'],
            ['MOTIF \\cite{joyce2023}', f'{m["families"]} families', f'{m["kept"]:,} / 0', '5-fold CV', f'{m["tr"]:,} / {m["va"]:,} / {m["te"]:,}', f'{m["nodes_mean"]:.1f}', f'{m["hubs_mean"]:.1f}']]
    d.section(2)
    d.table('Table 2. Datasets after preprocessing (split sizes for seed or fold 0)',
            rows, [1550, 1350, 1700, 1250, 2000, 950, 950], align=['left', 'left', 'center', 'left', 'center', 'center', 'center'])
    d.section(1)
    d.h2('6.2 Baselines and implementation')
    d.para('Seven baselines share the splits. *LightGBM* uses binary presence of hashed component tokens ($2^{14}$ '
           'buckets), log size counts and whole-file entropy, and on MOTIF the 2,381-dimensional EMBER vectors of '
           '\\cite{joyce2023}. *Mono-LightGBM* drops the entropy and constrains every feature to a non-decreasing effect '
           '\\cite{cano2019}; a multilayer perceptron (*MLP*) uses the LightGBM features. *R-GAT* is a relational graph '
           'attention network with mean pooling, representative of attention-based detectors \\cite{vuran2025}, and '
           'partition-voting R-GAT (*PV-R-GAT*) adds the same voting, the graph analogue of chunk voting \\cite{gibert2026}. A non-negative GCN '
           '(*NN-GCN*) uses mean aggregation and readout, as in Mal2GCN \\cite{kargarnovin2024}. The *unconstrained '
           'twin* is CertiProto-I without sign constraints, with mean aggregation and readout and non-monotone whole-file '
           'features (entropy; byte histograms and string statistics on MOTIF), <<so its gap to CertiProto-I bounds the cost of '
           'the insertion guarantee from above; Section 7.6 isolates that cost with a variant that removes only the sign '
           'constraints.>> *CertiProto-I* is trained on full programs and '
           '*CertiProto-IE* also on random groups; the first carries the insertion guarantee (I), the second also the edit '
           'certificate (IE). $M$ is set so that a group holds about 13 components on BMD ($M=16$; in training $M$ is drawn at '
           'random from {8, 16, 32}) and 17 on ClaMP ($M=3$; drawn from {2, 3, 4}), for CertiProto-IE and PV-R-GAT alike. Graph models '
           'use $d=64$, $L=2$, $H=32$, $K=32$ ($K=64$ on MOTIF), Adam with cosine decay (learning rate $2\\times10^{-3}$, '
           '$3\\times10^{-3}$ on MOTIF) and early stopping on validation AUC (accuracy on MOTIF), with at most 14 epochs of '
           '8,000 programs on BMD and 30 and 60 epochs on ClaMP and MOTIF. Seeds 0–4 are used on ClaMP and MOTIF and for '
           'LightGBM on BMD, and seeds 0–2 for the other BMD models; all runs used a two-core CPU and PyTorch.')
    d.h2('6.3 Metrics and attacks')
    d.para('Accuracy, precision, recall and F1 use the threshold that maximises validation F1; AUC and the true-positive '
           'rate (TPR) at 1% and 0.1% false-positive rate (FPR) are read from the test ROC curve. A malware sample is certified '
           'at budget $r$ when it is detected and $r^{\\ast}\\geq r$ (Eq. (12)) at the stated FPR; for PV-R-GAT, whose sub-models '
           'are not monotone, insertions also consume the budget. The white-box attacker greedily applies the operation of '
           'Section 3 that lowers the score most: inserting one of the 80 most benign-indicative imports, flags or signatures '
           'of the training goodware, growing the size counts by a 64 KiB section, deleting a component or replacing a header '
           'value by one of its three most common benign values. On detected test malware (1% validation FPR) it is run twice: '
           'with insertions only, and with 20 insertions plus edits; budgets are stated with the results, and the MLP, which '
           'shares the LightGBM features, is not attacked. <<Each detector is attacked on the malware it detects, which is the '
           'operationally meaningful population but a different one for each detector. For the significance test the attack '
           'is therefore repeated on one fixed set of programs, those detected by all eight detectors at 1% validation FPR, '
           'so the evasion outcomes are paired and an exact McNemar test applies; a test treating two evasion rates measured '
           'on different populations as independent samples would be mis-specified.>> Significance otherwise uses paired '
           '$t$-tests over seeds and McNemar tests on per-sample decisions.')
