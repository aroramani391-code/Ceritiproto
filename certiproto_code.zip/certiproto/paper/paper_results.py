"""Abstract, Section 7 (results and discussion), Section 8 (limitations) and Section 9 (conclusion), compact version.
Every number is read from results.json, so text, tables and figures stay consistent."""
from _root import ROOT
import json, os
import numpy as np

FIG = f'{ROOT}/figs'
NM = {'lgbm': 'LightGBM', 'lgbm-mono': 'Mono-LightGBM', 'mlp': 'MLP', 'rgat': 'R-GAT', 'gnncert@main': 'PV-R-GAT (vote)',
      'nngcn': 'NN-GCN', 'twin': 'Unconstrained twin', 'certiproto-i': 'CertiProto-I', 'certiproto-ie@main': 'CertiProto-IE (vote)',
      'gnncert': 'PV-R-GAT (vote)', 'certiproto-ie': 'CertiProto-IE (vote)',
      'lgbm-ember': 'LightGBM (EMBER)', 'mlp-ember': 'MLP (EMBER)'}
ORDER = ['lgbm', 'lgbm-mono', 'mlp', 'rgat', 'gnncert@main', 'nngcn', 'twin', 'certiproto-i', 'certiproto-ie@main']
MAIN_M = {'bmd': 16, 'clamp': 3}


def pm(v, k=100, nd=2):
    return f'{v[0] * k:.{nd}f}±{v[1] * k:.{nd}f}'


def pm2(v, k=100, nd=2):
    return f'{v[0] * k:.{nd}f}\n±{v[1] * k:.{nd}f}'


def sg(x, nd=2):
    return f'{x:+.{nd}f}'.replace('-', '\u2212')


def bold(x):
    if '^{' in x:
        a, b = x.split('^{', 1)
        return f'**{a}**^{{{b}'
    return f'**{x}**'


def p1(x, nd=1):
    return f'{x * 100:.{nd}f}'


def kappa():
    return json.load(open(f'{ROOT}/results/kappa.json'))


def abstract(R):
    cb, cc = R['clean_bmd'], R['clean_clamp']
    Ab = R.get('attack_bmd', {})
    s = ('Graph neural network detectors of Windows portable executable (PE) malware are accurate but easy to evade: inserted '
         'benign imports or sections pull a pooled embedding toward the benign class, and certified defences charge every '
         'insertion to a small budget. This paper presents '
         'CertiProto, which builds into its architecture the observation that malice is existential: a program is malicious '
         'if at least one of its components is. Each executable becomes a heterogeneous graph of PE components. Monotone '
         'message passing with non-negative weights and max aggregation, followed by a non-negative prototype '
         'multiple-instance head, makes the malice score provably non-decreasing under any insertion (CertiProto-I), and '
         'content-hash partition voting adds a deterministic certificate against unlimited insertion plus a bounded number '
         'of edits (CertiProto-IE). Prototypes are projected onto real training components, so every verdict names the '
         'imports and header fields behind it.')
    try:
        cert = R['cert_bmd']['certiproto-ie@M16@0.01']['mean']
        Ah = R.get('attack_hi_bmd', Ab)
        base = ('lgbm', 'lgbm-mono', 'rgat', 'gnncert', 'nngcn', 'twin')
        ev8 = [Ah[m]['mix_by_r'][8] for m in base if m in Ah]
        mo = R['motif']
        s += (f' On a time-aware split of the Brazilian Malware Dataset, CertiProto-IE certifies {p1(cert[0])}% of future '
              f'malware against unlimited insertion at 1% false-positive rate and {p1(cert[2])}% with two additional edits, '
              f'whereas no baseline certifies a single edit once insertion is free. A greedy attacker with 40 insertions never '
              f'evades it, and with 20 insertions and eight edits it evades {p1(Ah["certiproto-ie"]["mix_by_r"][8])}% of its '
              f'detections against {p1(min(ev8))}–{p1(max(ev8))}% for the six attacked baselines. The price is clean '
              f'accuracy: the AUC of '
              f'CertiProto-I is '
              f'{(cb["twin"]["auc"][0] - cb["certiproto-i"]["auc"][0]) * 100:.2f} points below an unconstrained twin on this '
              f'split ({(cc["twin"]["auc"][0] - cc["certiproto-i"]["auc"][0]) * 100:.2f} on the ClaMP header dataset), and the edit-certified '
              f'CertiProto-IE loses a further {(cb["certiproto-i"]["auc"][0] - cb["certiproto-ie@main"]["auc"][0]) * 100:.2f} points.')
        if 'robust' in mo.get('certiproto-i', {}):
            s += (f' On 323 MOTIF families CertiProto-I reaches {p1(mo["certiproto-i"]["acc"][0])}% accuracy, above a relational '
                  f'graph attention network ({p1(mo["rgat"]["acc"][0])}%) but below LightGBM on EMBER feature vectors '
                  f'({p1(mo["lgbm-ember"]["acc"][0])}%), and inserted components never lower its true-family score.')
    except Exception as e:
        s += f' [numbers pending: {e}]'
    return s


# ------------------------------------------------------------------ tables

def table_clean(d, R, num):
    cb, cc = R['clean_bmd'], R['clean_clamp']
    rows = [['Method', 'BMD, time-aware test', None, None, None, None, 'ClaMP', None, None, None],
            ['', 'AUC', 'Acc.', 'F1', 'TPR@\n1%', 'TPR@\n0.1%', 'AUC', 'Acc.', 'F1', 'TPR@\n1%']]
    keysb = ['auc', 'acc', 'f1', 'tpr1', 'tpr01']; keysc = ['auc', 'acc', 'f1', 'tpr1']
    ms = [m for m in ORDER if m in cb or m in cc]
    for m in ms:
        row = [NM[m]]
        for C, keys in ((cb, keysb), (cc, keysc)):
            for k in keys:
                row.append(pm2(C[m][k]) if m in C else '-')
        rows.append(row)
    for off, C, keys in ((1, cb, keysb), (6, cc, keysc)):
        for j, k in enumerate(keys):
            vals = [(C[m][k][0] if m in C else -1) for m in ms]
            bi = int(np.argmax(vals))
            rows[2 + bi][off + j] = '\n'.join('**' + x + '**' for x in rows[2 + bi][off + j].split('\n'))
    d.table(f'Table {num}. Clean detection (%, mean±std over seeds; differences in the text use unrounded means); best value of '
            'each column in bold', rows,
            [2026, 780, 780, 780, 780, 840, 780, 780, 780, 840], header_rows=2, merges=[(0, 1, 5), (0, 6, 4)],
            align=['left'] + ['center'] * 9)


def table_robust(d, R, num):
    EDIT = {'bmd': 8, 'clamp': 1}
    rows = [['Method', 'Insertion guarantee', 'BMD', None, None, None, 'ClaMP', None, None, None],
            ['', '', 'Cert. $r$=0', 'Cert. $r$=2', 'Ev. ins.', 'Ev. +8 ed.', 'Cert. $r$=0', 'Cert. $r$=1', 'Ev. ins.', 'Ev. +1 ed.']]
    guar = {'lgbm': 'No', 'lgbm-mono': 'Proven', 'rgat': 'No', 'gnncert': 'No', 'nngcn': 'No', 'twin': 'No',
            'certiproto-i': 'Proven', 'certiproto-ie': 'Proven'}
    for m in ['lgbm', 'lgbm-mono', 'rgat', 'gnncert', 'nngcn', 'twin', 'certiproto-i', 'certiproto-ie']:
        row = [NM[m], guar[m]]
        for ds, rr in (('bmd', (0, 2)), ('clamp', (0, 1))):
            C = R[f'cert_{ds}']; A = R.get(f'attack_hi_{ds}', {})
            k = f'{m}@M{MAIN_M[ds]}@0.01'
            for r in rr:
                if m == 'certiproto-ie' and k in C:
                    row.append(p1(C[k]['mean'][r]))
                elif m in ('lgbm-mono', 'certiproto-i') and r == 0:
                    row.append(p1(R[f'clean_{ds}'][m]['tpr1'][0]) + '^{a}')
                else:
                    row.append('0.0')
            row.append(p1(A[m]['ins_evasion']) if m in A else '-')
            row.append(p1(A[m]['mix_by_r'][EDIT[ds]]) if m in A else '-')
        rows.append(row)
    for j in (2, 3, 6, 7):
        vals = [float(r[j].split('^')[0]) for r in rows[2:]]
        mx = max(vals)
        for i, v in enumerate(vals):
            if v == mx: rows[2 + i][j] = bold(rows[2 + i][j])
    for j in (4, 5, 8, 9):
        vals = [float(r[j]) if r[j] != '-' else 1e9 for r in rows[2:]]
        mn = min(vals)
        for i, v in enumerate(vals):
            if v == mn: rows[2 + i][j] = bold(rows[2 + i][j])
    d.table(f'Table {num}. Certified TPR (%) at 1% FPR under unlimited insertion plus $r$ edits, and evasion rate (Ev., %) of '
            'the strongest greedy attack (40 insertions, or 20 insertions plus the stated number of edits); best values in '
            'bold. ^{a}Insertion-only certificate from monotonicity', rows,
            [1900, 1100, 840, 840, 840, 840, 840, 840, 840, 840], header_rows=2,
            merges=[(0, 2, 4), (0, 6, 4)], align=['left', 'center'] + ['center'] * 8)


def table_explain(d, R, num):
    E, Ec = R.get('explain_bmd', {}), R.get('explain_clamp', {})
    rows = [['Ranking', 'BMD', None, 'ClaMP', None], ['', 'Del. top-3', 'Keep top-10', 'Del. top-3', 'Keep top-10']]
    for m, kind, lab in (('certiproto-i', 'w', 'CertiProto-I, witness'), ('certiproto-i', 'r', 'CertiProto-I, random'),
                         ('rgat', 'w', 'R-GAT, grad.×input'), ('twin', 'w', 'Twin, grad.×input')):
        row = [lab]
        for X in (E, Ec):
            if m in X:
                row += [p1(X[m]['3'][f'del_{kind}']), p1(X[m]['10'][f'suff_{kind}'])]
            else:
                row += ['-', '-']
        rows.append(row)
    d.table(f'Table {num}. Explanation faithfulness (%): verdicts flipped by deleting the top-3 ranked components and '
            'verdicts kept by the top-10 components alone', rows, [1650, 750, 750, 750, 750], header_rows=2,
            merges=[(0, 1, 2), (0, 3, 2)], align=['left'] + ['center'] * 4)


def table_motif(d, R, num):
    Mo = R['motif']
    rows = [['Method', 'Acc.', 'Macro-F1', 'Score lowered', 'Top-1 kept']]
    for m in ['lgbm-ember', 'mlp-ember', 'rgat', 'twin', 'certiproto-i']:
        if m not in Mo: continue
        v = Mo[m]; rb = v.get('robust')
        rows.append([NM[m] if m not in ('certiproto-i', 'twin') else {'certiproto-i': 'CertiProto-I', 'twin': 'Twin'}[m],
                     pm(v['acc'], nd=1), pm(v['f1'], nd=1),
                     p1(rb['frac_true_logit_decreased']) if rb else '-', p1(rb['top1_retained']) if rb else '-'])
    rows.append(['LightGBM \\cite{joyce2023}', '72.4±2.1', '-', '-', '-'])
    rows.append(['MalConv2 \\cite{joyce2023}', '48.7±1.7', '-', '-', '-'])
    d.table(f'Table {num}. MOTIF family attribution (%, five folds) and true-family evidence after inserting the components '
            'of another family (fold 0); the last two rows are reported values', rows, [1150, 950, 950, 850, 750],
            align=['left'] + ['center'] * 4)


def table_ablation(d, R, num):
    Ab = R['ablation']
    lab = {'certiproto-i': 'Full model', 'certiproto-i-relax': '<<No sign constraints^{†}>>',
           'certiproto-i-cosine': 'Cosine similarity^{†}',
           'certiproto-i-meanagg': 'Mean aggregation^{†}', 'certiproto-i-nomil': 'No MIL loss',
           'certiproto-i-protoonly': 'No axis prototypes', 'certiproto-i-H1': 'One channel ($H$=1)',
           'certiproto-i-nongram': 'No char. n-grams', 'certiproto-i-K16': '$K$=16', 'certiproto-i-K64': '$K$=64'}
    rows = [['Variant', 'AUC', 'TPR@1%', 'Ev. ins.']]
    for v, nm in lab.items():
        if v not in Ab: continue
        a = Ab[v]
        ie_ = a.get('ins_evasion')
        rows.append([nm, pm(a['auc']), pm(a['tpr1'], nd=1), p1(ie_) if ie_ is not None and ie_ == ie_ else 'n.a.^{‡}'])
    d.table(f'Table {num}. Ablation on ClaMP (%, <<five seeds>>; evasion on seed 0); ^{{†}}not monotone; ^{{‡}}no detection '
            'at 1% FPR to attack. <<The first variant removes only the sign constraints and keeps every other component, so '
            'its distance from the full model is the cost of the insertion guarantee alone>>', rows,
            [1750, 1150, 1050, 700], align=['left'] + ['center'] * 3)


def fisher_p(R, ds, m):
    from scipy.stats import fisher_exact
    A = R.get(f'attack_hi_{ds}') or R.get(f'attack_{ds}', {})
    if m not in A or 'certiproto-i' not in A: return None
    c, a = A['certiproto-i'], A[m]
    e0, e1 = round(c['ins_evasion'] * c['n']), round(a['ins_evasion'] * a['n'])
    return float(fisher_exact([[e0, c['n'] - e0], [e1, a['n'] - e1]])[1])


def fmt_p(p):
    if p is None: return '-'
    return f'{p:.3f}' if p >= 0.001 else '<0.001'


def table_sig(d, R, num):
    rows = [['Baseline', 'Data', 'ΔAUC', '$p_{t}$', '$p_{\\mathrm{McN}}$', '<<$n_{c}$>>', '$p_{\\mathrm{ev}}$']]
    for ds in ('bmd', 'clamp'):
        S = R.get(f'sig_{ds}', {})
        E = R.get(f'evasion_test_{ds}', {})
        for m in ['lgbm', 'lgbm-mono', 'rgat', 'nngcn', 'twin']:
            if m not in S: continue
            s = S[m]
            mp = float(np.median([x[2] for x in s['mcnemar']]))
            e = E.get(m)
            rows.append([NM[m] if m != 'twin' else 'Twin', 'BMD' if ds == 'bmd' else 'ClaMP', sg(s["delta_auc"] * 100),
                         fmt_p(s['p']), fmt_p(mp),
                         f'<<{e["n_common"]}>>' if e else '<<-->>',
                         f'<<{fmt_p(e["p"])}>>' if e else '<<-->>'])
    d.table(f'Table {num}. Significance of CertiProto-I against five baselines: AUC difference (points, from unrounded '
            'means) and $p$-values of the paired $t$-test over seeds ($p_{t}$) and the median per-seed McNemar test '
            '($p_{\\mathrm{McN}}$). <<$p_{\\mathrm{ev}}$ is an exact McNemar test on insertion-only evasion over the '
            '$n_{c}$ programs detected by all eight detectors>>', rows,
            [1100, 620, 640, 640, 660, 480, 660], align=['left'] + ['center'] * 6)


# ------------------------------------------------------------------ text

def results(d, R):
    cb, cc = R['clean_bmd'], R['clean_clamp']
    Ab, Ac = R.get('attack_bmd', {}), R.get('attack_clamp', {})
    Cb, Cc = R['cert_bmd'], R['cert_clamp']
    K = kappa()
    d.h1('7. Results and discussion')
    # ---------------- clean detection
    d.h2('7.1 Clean detection and the cost of certification')
    cp, tw, lg, rg, mo, pv, ie, nn = (cb[k] for k in ('certiproto-i', 'twin', 'lgbm', 'rgat', 'lgbm-mono', 'gnncert@main',
                                                      'certiproto-ie@main', 'nngcn'))
    cpc, twc, lgc, moc = (cc[k] for k in ('certiproto-i', 'twin', 'lgbm', 'lgbm-mono'))
    sb = R.get('sig_bmd', {})
    ml = cb['mlp']; ie1, pv1 = cb['certiproto-ie@M1'], cb['gnncert@M1']
    second = (f'followed by the MLP and the twin (both {p1(tw["auc"][0], 2)}%)' if p1(ml["auc"][0], 2) == p1(tw["auc"][0], 2)
              else f'followed by the twin ({p1(tw["auc"][0], 2)}%)')
    hi01 = [cb[m]['tpr01'][0] for m in ('lgbm', 'mlp', 'nngcn', 'twin')]
    AB = R.get('ablation', {})
    has_relax = 'certiproto-i-relax' in AB
    RX = R.get('relax', {})
    dlt = lambda ds: (RX[ds]['relax_auc'][0] - RX[ds]['base_auc'][0]) * 100
    twin_gap = (f'<<The twin differs from CertiProto-I in three ways at once (no sign constraints, mean instead of max '
                f'aggregation and readout, and non-monotone whole-file features), so its margin bounds the cost of the '
                f'insertion guarantee from above rather than measuring it. A variant that removes only the sign '
                f'constraints and keeps every other component gains {abs(dlt("clamp")):.2f} AUC points on ClaMP and loses '
                f'{abs(dlt("bmd")):.2f} on BMD, against twin margins of '
                f'{(cc["twin"]["auc"][0] - cc["certiproto-i"]["auc"][0]) * 100:.2f} and '
                f'{(cb["twin"]["auc"][0] - cb["certiproto-i"]["auc"][0]) * 100:.2f}: most of what separates the twin from '
                f'CertiProto-I on BMD is its aggregation, readout and whole-file features, not monotonicity.>> '
                ) if ('bmd' in RX and 'clamp' in RX) else ''
    d.para(f'Table 3 lists clean detection. On the BMD test set, which holds only programs dated after the training '
           f'period, LightGBM attains the highest AUC ({p1(lg["auc"][0], 2)}%), {second} and R-GAT '
           f'({p1(rg["auc"][0], 2)}%). CertiProto-I reaches {p1(cp["auc"][0], 2)}% at {p1(cp["prec"][0], 2)}% precision, '
           f'{(tw["auc"][0] - cp["auc"][0]) * 100:.2f} points below the twin. Mono-LightGBM pays a similar price '
           f'({p1(mo["auc"][0], 2)}%), so most of the gap comes from ignoring benign evidence rather than from the graph '
           f'encoder, while NN-GCN, the other non-negative graph model, stays {(cp["auc"][0] - nn["auc"][0]) * 100:.2f} points '
           f'below CertiProto-I. ' + twin_gap +
           f'Training on random groups lowers the full-program AUC of CertiProto-IE to '
           f'{p1(ie1["auc"][0], 2)}%, and voting over 16 groups to {p1(ie["auc"][0], 2)}%; PV-R-GAT drops from '
           f'{p1(pv1["auc"][0], 2)}% to {p1(pv["auc"][0], 2)}%. Against the only baseline with an insertion guarantee the '
           f'comparison reverses at the strict operating point: at 0.1% FPR CertiProto-I keeps {p1(cp["tpr01"][0])}% TPR '
           f'against {p1(mo["tpr01"][0])}% for Mono-LightGBM, close to R-GAT ({p1(rg["tpr01"][0])}%) though below the '
           f'unconstrained feature-based models and the twin ({p1(min(hi01))}–{p1(max(hi01))}%). ClaMP shows the same ordering at a higher level '
           f'(CertiProto-I {p1(cpc["auc"][0], 2)}% against {p1(twc["auc"][0], 2)}% for the twin). Figs. 2–4 show the ROC '
           f'curves, confusion matrices and validation curves: CertiProto-I converges more slowly, as its non-negative layers '
           f'must first learn which components carry malicious evidence, but plateaus within the budget and on MOTIF learns '
           f'faster than R-GAT.')
    d.section(2)
    table_clean(d, R, 3)
    d.section(1)
    # ---------------- certified robustness
    d.h2('7.2 Certified robustness')
    c16, s16 = Cb['certiproto-ie@M16@0.01']['mean'], Cb['certiproto-ie@M16@0.01']['std']
    c8, c32 = Cb['certiproto-ie@M8@0.01']['mean'], Cb['certiproto-ie@M32@0.01']['mean']
    g16 = Cb['gnncert@M16@0.01']['mean']
    cc3, gc3 = Cc['certiproto-ie@M3@0.01']['mean'], Cc['gnncert@M3@0.01']['mean']
    d.para(f'Fig. 5(a, b) and Table 4 give the certified TPR at 1% FPR, with validation-selected quorums '
           f'$\\kappa={K["bmd|certiproto-ie|16"]}$ of 16 groups on BMD and $\\kappa={K["clamp|certiproto-ie|3"]}$ of 3 on '
           f'ClaMP. On BMD CertiProto-IE certifies {p1(c16[0])}±{p1(s16[0])}% of future malware against unlimited insertion, '
           f'{p1(c16[2])}% with two edits and {p1(c16[5])}% with five, so about half of the test malware keeps a guaranteed '
           f'verdict under unlimited insertion plus five edits. Larger $M$ trades detection for radius: $M=32$ '
           f'certifies {p1(c32[0])}% at $r=0$ and {p1(c32[10])}% at $r=10$, whereas $M=8$ stops at '
           f'$r={sum(1 for x in c8 if x > 0) - 1}$. PV-R-GAT reaches {p1(g16[0])}% at $r=0$ only if nothing is inserted; with '
           f'free insertion its certified TPR, like that of every non-monotone baseline, is zero, and Mono-LightGBM certifies '
           f'insertion only (Table 4). On ClaMP a group of about 17 header '
           f'fields carries little independent evidence: CertiProto-IE certifies {p1(cc3[0])}% of malware against unlimited '
           f'insertion and {p1(cc3[1])}% with one edit, against {p1(gc3[0])}% and {p1(gc3[1])}% for PV-R-GAT without free '
           f'insertion. <<One caveat belongs with these numbers: the established chunk-based smoothing defence '
           f'\\cite{{gibert2024,gibert2026}} certifies byte chunks of the file itself, and the three datasets publish parsed '
           f'metadata rather than binaries, so it cannot be run on them and its published certificates are not comparable '
           f'with the ones here. PV-R-GAT is its component-space analogue, the same partition-and-vote construction with the '
           f'same accounting, in which every modification, insertion included, consumes one budget; what the comparison '
           f'transfers is that construction, not the published numbers.>>')
    d.section(2)
    d.figure(f'{FIG}/fig2_roc.png', f'{FIG}/fig2_roc.svg', 6.75, 'Figure. 2 ROC curves on the test sets (seed or fold 0); '
             'MOTIF uses the micro-average over 323 families')
    d.figure(f'{FIG}/fig3_confusion.png', f'{FIG}/fig3_confusion.svg', 6.6, 'Figure. 3 Confusion matrices of CertiProto-I '
             '(seed 0, validation-selected threshold): (a) BMD, (b) ClaMP, (c) eight largest MOTIF families, row-normalised')
    d.figure(f'{FIG}/fig4_epochs.png', f'{FIG}/fig4_epochs.svg', 6.75, 'Figure. 4 Epoch-wise validation performance (mean '
             'and standard deviation over seeds or folds)')
    d.section(1)
    # ---------------- attacks
    d.h2('7.3 Greedy structural attacks')
    Ah, Ach = R.get('attack_hi_bmd', {}), R.get('attack_hi_clamp', {})
    A60 = R.get('attack_ins60_clamp', {})
    def ev(A, m, r=None):
        if m not in A: return '-'
        return p1(A[m]['ins_evasion']) if r is None else p1(A[m]['mix_by_r'][r])
    worst = max(float(ev(Ah, m, 8)) for m in ('lgbm', 'lgbm-mono', 'rgat', 'gnncert', 'nngcn', 'twin'))
    best_base = min(float(ev(Ah, m, 8)) for m in ('lgbm', 'lgbm-mono', 'rgat', 'gnncert', 'nngcn', 'twin'))
    d.para(f'Table 4 and Fig. 5(c, d) report the strongest attack: 40 insertions, or 20 insertions plus up to eight edits. '
           f'Insertion alone evades the unconstrained twin on {ev(Ah, "twin")}% of attacked BMD detections, R-GAT on '
           f'{ev(Ah, "rgat")}%, PV-R-GAT on {ev(Ah, "gnncert")}%, LightGBM on {ev(Ah, "lgbm")}% and NN-GCN on '
           f'{ev(Ah, "nngcn")}%, and on ClaMP every non-monotone model in '
           f'{min(float(ev(Ach, m)) for m in ("twin", "gnncert", "rgat", "lgbm", "nngcn")):.1f}'
           f'–{max(float(ev(Ach, m)) for m in ("twin", "gnncert", "rgat", "lgbm", "nngcn")):.1f}% of cases. Mono-LightGBM, '
           f'CertiProto-I and CertiProto-IE are never evaded by insertion, as monotonicity guarantees (Theorem 1 for '
           f'CertiProto), and stay at zero when the budget is raised to 60 insertions on ClaMP. The guarantee does not depend '
           f'on the budget, so no larger insertion attack can change the insertion column of these three rows.')
    G = R.get('nngcn_split', {})
    if G:
        d.para(f'<<NN-GCN deserves a separate word, because it reproduces Mal2GCN \\cite{{kargarnovin2024}} - non-negative '
               f'weights, mean aggregation and mean readout - and is nevertheless evaded. The two are consistent once the '
               f'scope of the published guarantee is read carefully: it composes monotone maps over a **fixed** graph, so it '
               f'covers features added to components that already exist, not components that did not exist before. '
               f'Separating the two kinds of insertion shows exactly this. An attacker restricted to raising size counts, '
               f'which is growth of a feature on an existing node, evades NN-GCN on {p1(G["grow"]["nngcn"])}% of attacked BMD '
               f'samples; an attacker restricted to adding new component nodes evades it on {p1(G["nodes"]["nngcn"])}%. '
               f'Degree-normalised averaging and mean readout both shrink when the node set grows, so a verdict that rests '
               f'on a few malicious components is diluted by benign ones. CertiProto is at '
               f'{p1(G["grow"]["certiproto-i"])}% and {p1(G["nodes"]["certiproto-i"])}% under the same two restrictions, '
               f'which is what Theorem 1 requires and what max aggregation with a non-negative readout buys over the mean.>>')
    others = {m: float(ev(Ah, m, 8)) for m in ('lgbm', 'lgbm-mono', 'rgat', 'gnncert', 'nngcn', 'twin')}
    bb = min(others, key=others.get)
    rest = sorted(v for k, v in others.items() if k != bb)
    d.para(f'Edits are the only remaining lever, and the certificate bounds how far they go. With eight edits on BMD, '
           f'CertiProto-IE is evaded on {ev(Ah, "certiproto-ie", 8)}% of attacked samples, the lowest rate of the eight '
           f'models: the closest baseline, {NM[bb]}, is evaded on {others[bb]:.1f}% and the rest on {rest[0]:.1f}–'
           f'{rest[-1]:.1f}%, including {ev(Ah, "lgbm-mono", 8)}% for the monotone LightGBM and {ev(Ah, "twin", 8)}% for the '
           f'twin. CertiProto-I, which carries no edit certificate, is evaded on {ev(Ah, "certiproto-i", 8)}%. The curve of '
           f'CertiProto-IE is nearly flat beyond two edits ({p1(Ah["certiproto-ie"]["mix_by_r"][2])}% to '
           f'{p1(Ah["certiproto-ie"]["mix_by_r"][8])}%, Fig. 5(d)) because the quorum absorbs them; its attacked samples have a '
           f'mean radius of {Ah["certiproto-ie"]["mean_radius"]:.1f} edits and none was evaded within its radius, an '
           f'empirical check of Theorem 2. Header-only ClaMP programs stay fragile, since one rewritten field moves a large '
           f'part of the evidence: a single edit evades {ev(Ach, "lgbm-mono", 1)}% of Mono-LightGBM and '
           f'{ev(Ach, "certiproto-i", 1)}% of CertiProto-I detections, against {ev(Ach, "certiproto-ie", 1)}% for '
           f'CertiProto-IE, again the lowest of the eight but high in absolute terms.')
    d.section(2)
    table_robust(d, R, 4)
    d.figure(f'{FIG}/fig5_robust.png', f'{FIG}/fig5_robust.svg', 6.75, 'Figure. 5 Robustness: (a, b) certified TPR at 1% FPR '
             'versus edit budget (CertiProto-IE with unlimited insertion; *PV-R-GAT with insertions charged to the budget), '
             '(c) BMD evasion versus inserted components and (d) versus edit budget')
    d.section(1)
    # ---------------- faithfulness and qualitative analysis
    d.h2('7.4 Faithfulness and qualitative analysis')
    E, Ec = R.get('explain_bmd', {}), R.get('explain_clamp', {})
    e, er, ec, erc = E['certiproto-i'], E['rgat'], Ec['certiproto-i'], Ec['rgat']
    table_explain(d, R, 5)
    d.para(f'Table 5 checks whether the components named by an explanation drive the verdict, on up to {e["n"]} detected '
           f'test programs per model and dataset ({ec["n"]} for CertiProto-I on ClaMP). Deleting the top three witnesses flips {p1(e["3"]["del_w"])}% of '
           f'CertiProto-I detections on BMD and {p1(ec["3"]["del_w"])}% on ClaMP, against {p1(e["3"]["del_r"])}% and '
           f'{p1(ec["3"]["del_r"])}% for three random components and {p1(er["3"]["del_w"])}% and {p1(erc["3"]["del_w"])}% for the '
           f'top gradient-times-input components of R-GAT. Ten witnesses keep {p1(e["10"]["suff_w"])}% and '
           f'{p1(ec["10"]["suff_w"])}% of the verdicts, ten random components {p1(e["10"]["suff_r"])}% and '
           f'{p1(ec["10"]["suff_r"])}%. The unconstrained models flag even random fragments of malware (ten random components '
           f'keep {p1(er["10"]["suff_r"])}% of R-GAT verdicts on BMD), so their sufficiency scores say little about '
           f'evidence, whereas a CertiProto score rests on the few nodes that match its prototypes.')
    Q = R.get('qual', {})
    X = json.load(open(f'{ROOT}/results/qual_extra.json')) if os.path.exists(f'{ROOT}/results/qual_extra.json') else {}
    if Q.get('bmd'):
        def nm(t):
            return t.split(':', 1)[1] if ':' in t else t
        def api(w):
            t, par, c = w
            return f'{nm(t)} ({nm(par)})' if t.startswith('api:') and par else nm(t)
        b0, b1, b2 = Q['bmd'][:3]
        az = [m for m in Q.get('motif', []) if m['family'] == 'azorult']
        au = Q.get('motif_audit', {})
        d.para(f'The witnesses are readable on the original data. For BMD samples first seen in {b0["first_seen"][:4]}, '
               f'{b1["first_seen"][:4]} and {b2["first_seen"][:4]}, the strongest are {api(b0["witnesses"][0])}, '
               f'{api(b1["witnesses"][0])} and {api(b2["witnesses"][0])}, '
               f'with {b0["votes"]}, {b1["votes"]} and {b2["votes"]} of 16 CertiProto-IE votes (radii {b0["radius"]}, '
               f'{b1["radius"]} and {b2["radius"]}). Characteristics bits 7 and 15, also among the top witnesses, and the '
               f'comctl32 image-list imports are typical of Borland Delphi binaries: the two bits occur in '
               f'{X.get("rev_mal", 0):.1f}% of BMD malware but {X.get("rev_ben", 0):.1f}% of its goodware, and Delphi is named '
               f'as compiler for {X.get("delphi_mal", 0):.1f}% of the malware against {X.get("delphi_ben", 0):.1f}% of the '
               f'goodware. Part of the evidence is thus a toolchain artefact of the dataset, which the explanation exposes '
               f'instead of hiding it in a pooled embedding.'
               + (f' On MOTIF, the top witnesses of an AZORult sample are its linker version, a section named '
                  f'"{nm(az[0]["witnesses"][1][0])}" and a section with a blank name, a layout typical of packed builds.' if az else '')
               + (f' The {au["K"]} prototypes come from components of {au["distinct_source_families"]} families, and the '
                  f'strongest prototype behind a correct attribution stems from the same family in only {p1(au["purity"])}% of '
                  f'cases, so families are recognised through combinations of shared prototypes.' if au else ''))
    # ---------------- MOTIF
    d.h2('7.5 Family attribution on MOTIF')
    table_motif(d, R, 6)
    Mo = R['motif']
    if all(k in Mo for k in ('lgbm-ember', 'mlp-ember', 'rgat', 'twin', 'certiproto-i')) and all('robust' in Mo[k] for k in ('rgat', 'twin', 'certiproto-i')):
        c, r_, t_, l_, m_ = (Mo[k]['acc'][0] for k in ('certiproto-i', 'rgat', 'twin', 'lgbm-ember', 'mlp-ember'))
        rel = lambda a, b: 'on par with' if abs(a - b) < 0.01 else ('above' if a > b else 'below')
        rb = {k: Mo[k]['robust'] for k in ('certiproto-i', 'rgat', 'twin')}
        d.para(f'Table 6 follows the protocol of \\cite{{joyce2023}}. CertiProto-I reaches {p1(c)}% accuracy and '
               f'{p1(Mo["certiproto-i"]["f1"][0])}% macro-F1 over 323 families, {rel(c, r_)} R-GAT ({p1(r_)}%) and '
               f'{rel(c, t_)} the twin ({p1(t_)}%), but {rel(c, max(l_, m_))} LightGBM ({p1(l_)}%, '
               + ('close to the 72.4% reported in \\cite{joyce2023}' if abs(l_ - 0.724) <= 0.021 else
                  'against 72.4% reported in \\cite{joyce2023}')
               + f') and the MLP ({p1(m_)}%) on the EMBER vectors, whose byte and string statistics the component graph omits. '
               f'A harder test merges into each correctly attributed sample all imports, sections, data directories and exports '
               f'of the most damaging of 20 programs from another family. The true-family score of CertiProto-I never drops '
               f'(Theorem 1), whereas it drops for '
               + ('every R-GAT and twin sample' if rb["rgat"]["frac_true_logit_decreased"] == 1 and rb["twin"]["frac_true_logit_decreased"] == 1
                  else f'{p1(rb["rgat"]["frac_true_logit_decreased"])}% of R-GAT and {p1(rb["twin"]["frac_true_logit_decreased"])}% of twin samples')
               + f', by {rb["rgat"]["mean_worst_drop"]:.1f} and {rb["twin"]["mean_worst_drop"]:.1f} logits on average. Top-1 '
               f'attribution rarely survives for any model (kept for {p1(rb["certiproto-i"]["top1_retained"])}%, '
               f'{p1(rb["rgat"]["top1_retained"])}% and {p1(rb["twin"]["top1_retained"])}% of CertiProto-I, R-GAT and twin '
               f'samples), because the merged components also raise other families: the guarantee protects per-family '
               f'evidence, not the arg max.')
    else:
        d.para('[MOTIF RESULTS PENDING]')
    # ---------------- ablation
    d.h2('7.6 Ablation study')
    table_ablation(d, R, 7)
    Ab_ = R['ablation']
    if 'certiproto-i' in Ab_:
        full = Ab_['certiproto-i']
        def da(v):
            return (Ab_[v]['auc'][0] - full['auc'][0]) * 100 if v in Ab_ else float('nan')
        def dt(v):
            return (Ab_[v]['tpr1'][0] - full['tpr1'][0]) * 100 if v in Ab_ else float('nan')
        def ev_(v):
            return p1(Ab_[v]['ins_evasion']) if v in Ab_ and 'ins_evasion' in Ab_[v] else '-'
        mono_v = ['certiproto-i-nomil', 'certiproto-i-protoonly', 'certiproto-i-H1', 'certiproto-i-nongram', 'certiproto-i-K16', 'certiproto-i-K64']
        mono_ev = [Ab_[v].get('ins_evasion') for v in mono_v if v in Ab_ and Ab_[v].get('ins_evasion') == Ab_[v].get('ins_evasion')]
        Ex = Ec.get('certiproto-i-nomil')
        d.para(f'Table 7 removes one design choice at a time on ClaMP. Cosine instead of coverage similarity and mean instead '
               f'of max aggregation (the Mal2GCN-style choice) raise the AUC by {da("certiproto-i-cosine"):.2f} and '
               f'{da("certiproto-i-meanagg"):.2f} points but break monotonicity: insertion then evades '
               f'{ev_("certiproto-i-cosine")}% and {ev_("certiproto-i-meanagg")}% of detections. Among monotone variants the '
               f'axis-aligned prototypes and the hashed channels matter most ({sg(da("certiproto-i-protoonly"))} and '
               f'{sg(da("certiproto-i-H1"))} points); without axis prototypes the TPR at 1% FPR falls to zero, because the '
               f'top-scoring goodware shares one saturated score with many malware samples. Removing the '
               f'character n-grams ({sg(da("certiproto-i-nongram"))}) or setting $K$ to 16 or 64 '
               f'({sg(da("certiproto-i-K16"))} and {sg(da("certiproto-i-K64"))}) stays within seed variation, as ClaMP has no '
               f'unseen names. '
               + (f'<<Removing only the sign constraints, which leaves the architecture otherwise untouched, raises the AUC '
                  f'by {da("certiproto-i-relax"):.2f} points and is the cleanest available measure of what the guarantee '
                  f'costs; without them the model is also numerically unstable, so for this variant alone the head-only '
                  f'fine-tuning that follows prototype projection is kept only when it does not lower validation AUC.>> ' if 'certiproto-i-relax' in Ab_ else '')
               + f'Dropping the MIL term does not lower detection '
               f'({sg(da("certiproto-i-nomil"))})'
               + (f' but blurs the explanations: ten witnesses alone then keep {p1(Ex["10"]["suff_w"])}% of the verdicts instead '
                  f'of {p1(ec["10"]["suff_w"])}%, and deleting three random components flips {p1(Ex["3"]["del_r"])}% instead of '
                  f'{p1(ec["3"]["del_r"])}%, so the term concentrates the evidence on fewer components'
                  if Ex and Ex["10"]["suff_w"] < ec["10"]["suff_w"] - 0.05 else
                  (f', and its witnesses stay as faithful, so on header-only data the term could be omitted' if Ex else ''))
               + '.'
               + (' Every monotone variant with detections to attack keeps the insertion evasion at zero, so the guarantee comes '
                  'from the architecture, not from a tuned operating point.' if mono_ev and all(x == 0 for x in mono_ev if x is not None) else ''))
    # ---------------- significance and published results
    d.h2('7.7 Statistical validation and published results')
    nsig = [f'{NM[m]} on {"BMD" if ds == "bmd" else "ClaMP"} ($p$ = {R["sig_" + ds][m]["p"]:.3f})'
            for ds in ('bmd', 'clamp') for m in ('lgbm', 'rgat', 'twin') if m in R.get('sig_' + ds, {}) and R['sig_' + ds][m]['p'] >= 0.05]
    ET = {ds: R.get(f'evasion_test_{ds}', {}) for ds in ('bmd', 'clamp')}
    SKIP = ('certiproto-i', 'certiproto-ie', 'gnncert')          # the table lists five baselines
    MONO = ('lgbm-mono',)
    comps = [(ds, m, v) for ds in ET for m, v in ET[ds].items() if m not in SKIP]
    sig = [(ds, m, v) for ds, m, v in comps if v['p'] < 0.05]
    ps = [v['p'] for _, _, v in sig]
    pw = '$p<0.001$' if ps and max(ps) < 0.001 else (f'$p\\leq{max(ps):.3f}$' if ps else '')
    nsig = sorted({NM[m] + (' on BMD' if ds == 'bmd' else ' on ClaMP') for ds, m, v in comps
                   if v['p'] >= 0.05 and m not in MONO})
    nmono = sorted({NM[m] for ds, m, v in comps if m in MONO})
    nb = {ds: v['n_common'] for ds, m, v in comps}
    d.para('Table 8 tests both sides of the trade-off. <<Because each detector is otherwise attacked on its own '
           f'detections, evasion is re-measured here on one fixed set of programs detected by all eight detectors '
           f'({nb.get("bmd", 0)} on BMD and {nb.get("clamp", 0)} on ClaMP) and compared with an exact McNemar test on the '
           f'paired outcomes. It separates CertiProto-I from the attention and unconstrained baselines in {len(sig)} of the '
           f'{len(comps)} comparisons at {pw}. The remaining comparisons carry no evidence either way rather than evidence '
           f'of equality: against ' + ' and '.join(nmono) + ', which is monotone, neither model is ever evaded by '
           'insertion, so there are no discordant pairs; against ' + ', '.join(nsig[:-1]) + ' and ' + nsig[-1] + ' this '
           'common subset is the malware every detector already finds, and almost no attack succeeds against either side.>> '
           'No test can weaken the certified columns of Table 4, which hold for every attacker rather than for the '
           'one implemented here. The clean-AUC gaps to the unconstrained LightGBM, R-GAT and twin run the other way '
           'and are also significant'
           + (' except for ' + ' and '.join(nsig) if nsig else '') + '; they are the price of guarantees that none of those '
           'models offers. Paired $t$-tests over three or five seeds have few degrees of freedom, so per-seed McNemar tests '
           'on the test decisions are reported beside them.')
    d.para(f'Published results use other protocols and are only indicative: 98.00% accuracy on BMD under random 50/50 splits '
           f'\\cite{{ceschin2018}}, where the 2015 cut used here never shows the model later data (CertiProto-I: '
           f'{p1(cp["acc"][0])}%), and 98.4% on ClaMP with ten-fold cross-validation \\cite{{kumar2019}}.')
    table_sig(d, R, 8)


def closing(d, R):
    cb = R['clean_bmd']
    c16 = R['cert_bmd']['certiproto-ie@M16@0.01']['mean']
    d.h1('8. Conclusion')
    Ah = R.get('attack_hi_bmd', {}); E = R.get('explain_bmd', {})
    base = ('lgbm', 'lgbm-mono', 'rgat', 'gnncert', 'nngcn', 'twin')
    ev8 = [Ah[m]['mix_by_r'][8] for m in base if m in Ah]
    d.para(f'CertiProto writes the existential nature of malice into a detector: monotone message passing and a non-negative '
           f'prototype MIL head make the malice score provably non-decreasing under any insertion, and content-hash partition '
           f'voting extends the guarantee to a bounded number of edits. On future malware of the Brazilian Malware Dataset, '
           f'CertiProto-IE certifies {p1(c16[0])}% of samples against unlimited insertion and {p1(c16[2])}% with two edits, and '
           f'a greedy attacker with 40 insertions never evades it. With 20 insertions and eight edits it evades '
           f'{p1(Ah["certiproto-ie"]["mix_by_r"][8])}% of its detections, against {p1(min(ev8))}–{p1(max(ev8))}% for the six '
           f'attacked baselines. The price is '
           f'{(cb["twin"]["auc"][0] - cb["certiproto-i"]["auc"][0]) * 100:.2f} AUC points for CertiProto-I and '
           f'{(cb["twin"]["auc"][0] - cb["certiproto-ie@main"]["auc"][0]) * 100:.2f} for CertiProto-IE against the '
           f'unconstrained twin. Deleting the top three witnesses of CertiProto-I flips the verdict more often than deleting '
           f'the top gradient-ranked components of R-GAT ({p1(E["certiproto-i"]["3"]["del_w"])}% against '
           f'{p1(E["rgat"]["3"]["del_w"])}% on BMD), and on the original data these witnesses expose a toolchain artefact of '
           f'the dataset.')
    d.para('The guarantee covers the parsed component graph only: packing rewrites nearly every component, and attacks on '
           'the parser are not modelled. Edit certificates need many independent components, so little can be certified on '
           'header-only data such as ClaMP, and on MOTIF the guarantee protects per-family evidence but not the top-1 '
           'family. <<The attacks are executed on parsed graphs rather than on files, and the established byte-chunk '
           'smoothing defence cannot be run on metadata-only datasets, so both comparisons are made in component space.>> '
           'Future work will extend the graph to function-level code, couple certification with drift adaptation and study '
           'attacks on the parser.')
    d.h1('Conflicts of interest')
    d.para('The authors declare no conflict of interest.')
    d.h1('Author contributions')
    d.para('Conceptualization, [Author 1] and [Author 2]; methodology, [Author 1]; software, [Author 1]; validation, [Author 1] '
           'and [Author 2]; formal analysis, [Author 1]; data curation, [Author 1]; writing\u2014original draft preparation, '
           '[Author 1]; writing\u2014review and editing, [Author 2]; supervision, [Author 2].')
    d.h1('<<Code availability>>')
    d.para('<<The implementation of the model, the attacks, the certificate computation and the scripts that produce every '
           'table and figure of this paper are released at [repository URL], together with the raw run logs and the JSON '
           'file from which the reported numbers are read. The datasets are not redistributed; the repository documents '
           'which release of each was used.>>')
    d.h1('Data availability')
    d.para('All datasets are public: the Brazilian Malware Dataset (github.com/fabriciojoc/brazilian-malware-dataset), '
           'ClaMP (github.com/urwithajit9/ClaMP) and MOTIF (github.com/boozallen/MOTIF).')
