"""Front matter and Sections 1-5 of the CertiProto paper (IJIES format, compact version)."""

TITLE = 'CertiProto: Certifiably Insertion-Robust and Self-Explaining Malware Detection via Monotone Prototype Graph Learning'


def front(d, R):
    d.para(f'**{TITLE}**', jc='center', sz=28, spacing='<w:spacing w:after="60"/>')
    d.para('[Author Name]^{1*}          [Author Name]^{2}', jc='center', sz=24)
    d.para('^{1}*[Department, Institution, City, Country]*', jc='center', sz=20)
    d.para('^{2}*[Department, Institution, City, Country]*', jc='center', sz=20)
    d.para('* Corresponding author\'s Email: [corresponding.author@institution.edu]', jc='center', sz=20)
    d.raw('<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="000000"/></w:pBdr><w:spacing w:before="60"/></w:pPr></w:p>')
    d.para('**Abstract:** ' + R['abstract'], sz=20)
    d.para('**Keywords:** Malware detection, Certified robustness, Graph neural networks, Monotone networks, '
           'Prototype learning, Multiple-instance learning, Adversarial malware.', sz=20)
    d.raw('<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="000000"/></w:pBdr><w:spacing w:before="60" w:after="60"/></w:pPr></w:p>')
    d.section(1)


def intro(d, R):
    d.h1('1. Introduction')
    d.para('Static detectors of Windows portable executable (PE) malware score a file without running it, and graphs built '
           'from control flow, function calls or imported application programming interfaces (APIs) give them structure that '
           'flat feature vectors lose \\cite{bilot2024}; recent journal detectors report accuracies above 99% '
           '\\cite{mi2025,vuran2025}. The same structure is easy to manipulate: most graph detectors summarise a program by '
           'mean, sum or attention pooling, so unused imports, extra sections or dead code added by an attacker move the '
           'summary toward the benign class while the payload stays intact. Node injection evades graph neural network (GNN) '
           'classifiers of control-flow graphs in 94.83% of cases \\cite{zapzalka2025} and opcode insertion in 93.73% of '
           'attempts \\cite{peng2025}, while practical PE attacks inject benign content or pad headers '
           '\\cite{demetrio2021a,demetrio2021b}.')
    d.para('<<Two families of defence already offer more than empirical hardening. Monotone models are an established '
           'answer to content addition: non-negative networks have a long history \\cite{daniels2010,cano2019}, and Mal2GCN '
           'trains a function-call-graph network with non-negative weights and claims theoretical robustness to appending '
           'attacks \\cite{kargarnovin2024}. Chunk-based (de)randomised smoothing is the second: it splits a file into chunks, '
           'votes over them, and yields a *deterministic* certificate that covers injected content as well as modified bytes, '
           'once the injection is aligned to chunk boundaries \\cite{gibert2024,gibert2026}; abstract interpretation certifies '
           'graph networks against bounded node perturbations \\cite{chen2026}. Neither family, however, gives an *unbounded* '
           'insertion guarantee together with an edit certificate. Smoothing certificates hold up to a fixed patch budget and '
           'lapse once more content is injected, and the monotonicity argument of Mal2GCN composes monotone maps over a '
           '**fixed** graph: degree-normalised averaging and mean readout are not monotone when new nodes appear, so the '
           'guarantee does not transfer to node insertion, and neither model certifies edits or explains its verdicts. '
           'Explanations of graph detectors are in turn computed after the fact \\cite{chen2023,mohammadian2025}, with no '
           'assurance that they reflect what the model used \\cite{rudin2019}.>>')
    d.para('CertiProto starts from an asymmetry in the attacker\'s position: a program is malicious if at least one of its '
           'components is, so adding components should never make it look less malicious; only removing or changing existing '
           'ones can. Node states therefore may only grow under insertion, the decision head may only reward evidence, and '
           'edits are absorbed by a vote over content-hash partitions. <<Monotonicity itself is not claimed as novel; the '
           'contribution is a specific combination that none of the defences above provides.>> (i) <<Monotone heterogeneous '
           'message passing (MHMP) carries the monotone argument from node features on a fixed graph to the graph itself: '
           'max aggregation within a (relation, channel) pair and summation across pairs keep the score non-decreasing when '
           'arbitrarily many nodes and edges are added, so the insertion budget is unbounded rather than capped by a patch '
           'size.>> (ii) A non-negative prototype multiple-instance learning (MIL) head with coverage similarity, projected '
           'onto real components, decomposes every score into a few witness components. (iii) Partition voting over the '
           'shared monotone model <<adds a deterministic edit certificate on top of the unbounded insertion guarantee, with a '
           'tight radius; smoothing certificates charge insertion and edits to one budget, whereas here only edits are '
           'charged.>> (iv) An evaluation on three public datasets against seven baselines covers clean and certified '
           'detection, structural attacks, faithfulness, family attribution, ablation and significance tests.')
    d.para('Section 2 reviews related work, Section 3 states the threat model, Section 4 describes CertiProto and Section 5 '
           'proves its guarantees. Section 6 gives the setup, Section 7 the results, and Section 8 concludes with the '
           'limitations.')


def related(d, R):
    d.h1('2. Related work')
    d.para('**Graph-based detection.** MalGNE embeds control-flow-graph (CFG) nodes for efficiency \\cite{peng2024}, Mi et al. '
           'add instruction streams to CFGs \\cite{mi2025}, MalHAPGNN pools call graphs with hierarchical attention '
           '\\cite{guo2025}, Vuran Sarı et al. use a graph attention network (GAT) on API and library graphs '
           '\\cite{vuran2025}, Zou et al. build feature graphs from static PE features and lose 5.884 points of area under '
           'the receiver operating characteristic curve (AUC) after a year of drift \\cite{zou2025}, and MCLPF prunes '
           'attributed flow graphs with a large language model (LLM) \\cite{tang2026}. All read a program out through mean, '
           'sum or attention pooling, and none offers a robustness guarantee.')
    d.para('**Evasion and defences.** Beyond node and opcode insertion \\cite{zapzalka2025,peng2025}, PE attacks add benign '
           'sections, imports or padding \\cite{demetrio2021a,ling2023}. Adversarial training with projected gradient descent '
           '(PGD) \\cite{abid2025} and robust updates \\cite{kozak2025} remain empirical. <<Certified defences are further '
           'advanced than the empirical ones. Chunk-based (de)randomised smoothing partitions a file, classifies each chunk '
           'and votes, which gives a deterministic certificate; with sections and headers padded to whole chunks the same '
           'certificate covers injected content, so bounded injection and bounded modification are both certified '
           '\\cite{gibert2024,gibert2026}. Abstract interpretation certifies graph convolutional networks (GCNs) against a '
           'bounded number of perturbed nodes \\cite{chen2026}. Monotone networks are the established answer to unbounded '
           'addition \\cite{daniels2010,cano2019}, with recent size and depth bounds \\cite{mikulincer2025}, and Mal2GCN '
           'applied non-negative weights to a function-call-graph GCN and claimed robustness to appending attacks '
           '\\cite{kargarnovin2024}; its argument composes monotone maps for a fixed graph, and its degree-normalised mean '
           'aggregation and average readout are not monotone under the arrival of new nodes, which Section 7.3 measures. What '
           'is missing from all of them is one model that is monotone under *unbounded* node insertion, certifies a number of '
           'edits on top of that, and names the components behind each verdict.>>')
    d.para('**Explanation and MIL.** MIL treats a program as a bag of instances \\cite{carbonneau2018,stiborek2018}, and '
           'PE-MILCon pools byte segments with attention \\cite{tuan2026}, which is not monotone. Explanations of malware '
           'detectors are mostly post hoc \\cite{saqib2024} and carry no faithfulness guarantee, although models '
           'interpretable by construction suit high-stakes decisions better \\cite{rudin2019}. Table 1 contrasts the closest '
           'works with CertiProto.')
    rows = [
        ['Method', 'Representation', 'Readout or defence', 'Insertion guarantee', 'Edit certificate', 'Explanation', 'Main drawback'],
        ['Mi et al. \\cite{mi2025}', 'Instruction-augmented CFG', 'Attention pooling', 'No', 'No', 'No', 'Pooled summary shifts under insertion'],
        ['Vuran Sarı et al. \\cite{vuran2025}', 'API and library graph', 'Node2Vec + GAT', 'No', 'No', 'No', 'No robustness evaluation'],
        ['MCLPF \\cite{tang2026}', 'Attributed flow graph', 'LLM pruning + GNN', 'No', 'No', 'Post hoc', 'Faithfulness not guaranteed'],
        ['Abid et al. \\cite{abid2025}', 'Multi-branch graph', 'PGD adversarial training', 'Empirical', 'No', 'No', 'Feature-space attacks only'],
        ['Mal2GCN \\cite{kargarnovin2024}', 'Function-call graph', 'Non-negative GCN, mean readout', '<<Claimed for appended features, fixed graph>>', 'No', 'No', '<<Mean readout is not monotone when nodes are added>>'],
        ['Gibert et al. \\cite{gibert2024,gibert2026}', 'Raw byte chunks', 'Chunk vote, (de)randomised smoothing', '<<Deterministic, bounded patch>>', '<<Deterministic, bounded chunks>>', 'No', '<<Guarantee lapses beyond the patch budget>>'],
        ['PE-MILCon \\cite{tuan2026}', 'Byte-segment bag', 'Attention MIL', 'No', 'No', 'Attention weights', 'Attention pooling is not monotone'],
        ['**CertiProto**', 'PE component graph', 'MHMP + prototype MIL + vote', '<<Deterministic, unbounded>>', 'Deterministic, components', 'Witness prototypes', 'Needs parsed components; packing out of scope'],
    ]
    d.section(2)
    d.table('Table 1. Comparison of CertiProto with the closest journal works<<; the insertion and edit columns state what '
            'each work certifies, not what it was evaluated on>>', rows,
            [1350, 1500, 1500, 1180, 1250, 1200, 1760], align=['left', 'left', 'left', 'center', 'center', 'center', 'left'])
    d.section(1)


def threat(d, R):
    d.h1('3. Threat model and problem formulation')
    d.para('A program $P$ is represented by a typed tree $G(P)=(V,E,\\tau,a)$: the root is connected to hubs (imported '
           'libraries, or header groups for header-only data) and to leaves (imported functions, header fields, flags, '
           'packer or compiler signatures, size counts, sections, data directories and exports). Node $v$ has type '
           '$\\tau(v)$ and attributes $a_v$, and a detector labels $P$ malicious when its score $S(P)$ exceeds a threshold. The '
           'attacker holds a detected sample, knows the model and its weights, and wants a benign verdict without breaking '
           'functionality. *Insertions* are free: new leaves, new hubs and larger size counts. *Edits* are budgeted: deleting '
           'a leaf, changing its content (renaming, rewriting a header value, altering a section) or shrinking a count; '
           'renaming a hub costs one edit per group in which it appears. <<Only size counts (type CNT) may grow under an '
           'insertion; the numeric attributes of a section or data directory belong to that component and changing one is an '
           'edit.>> With $\\mathcal{A}_r(P)$ the programs reachable with unlimited insertions and at most $r$ edits, the goal '
           'is a score with')
    d.eq(r'S(P^{\prime})\geq S(P)\ \ \forall P^{\prime}\in\mathcal{A}_0(P)', label='goal')
    d.para('and a radius $r^{\\ast}(P)$, computed in one pass, such that every program in $\\mathcal{A}_{r^{\\ast}}(P)$ keeps '
           'the malicious verdict. <<Each operation stands for a functionality-preserving change to the file. Adding a leaf '
           'under a library hub is an entry appended to the import address table, possibly with a new library, the standard '
           'import-injection step of practical PE attacks \\cite{demetrio2021a,ling2023}; a flag or signature leaf is a '
           'characteristics bit or a packer marker; growing a size count is a new section, appended overlay or padding, '
           'which moves the size and section-count fields without touching existing code \\cite{demetrio2021b}. Deleting a '
           'leaf removes an import or a section, renaming alters a section or library name, and rewriting a header value '
           'patches an optional-header field; these need care to keep the file runnable, which is why they are budgeted. The '
           'mapping is one-directional: every operation here is realisable on a file, but one file-level change may touch '
           'several components, and the attacks of Section 7.3 run on parsed graphs, so functionality preservation is argued '
           'from the operation set rather than verified by executing the modified samples. Packing rewrites nearly every '
           'component and is outside the certified scope.>>')


def method(d, R):
    d.h1('4. The CertiProto framework')
    d.para('Fig. 1 shows the pipeline. Static metadata becomes a component graph, the graph is split into $M$ groups by a '
           'content hash, one shared monotone model scores every group, and a vote gives the verdict, its certified radius and '
           'the witness components behind it.')
    d.section(2)
    d.figure(R['fig1_png'], R['fig1_svg'], 6.75, 'Figure. 1 Architecture of CertiProto. The shared model inside the dashed box is '
             'monotone, so Theorem 1 holds for every group; Theorem 2 follows from the vote')
    d.section(1)
    d.h2('4.1 Component graph and node encoders')
    d.para('A leaf is attached to its hub (a function to the library that exports it) or to the root. Each node is encoded '
           'from its own attributes only. <<Eqs. (2) and (3) are the two cases of a single definition of $h_v$, selected by '
           'the node type: Eq. (2) encodes every component that carries a name token $o_v$, such as "api:virtualalloc" or '
           '"hdr:FileAlignment=512", from a type embedding, a word embedding and the mean of its hashed character 3- to '
           '5-gram embeddings, so unseen names still receive informative vectors; Eq. (3) encodes a size count $x_v$ of '
           'field $f$, the only node type whose numeric value an insertion may raise:>>')
    d.eq(r'h_v=e_{\tau(v)}+E_w[o_v]+\frac{1}{|\Gamma_v|}\sum_{\gamma\in\Gamma_v}E_g[\gamma]+A_{\tau(v)}a_v,\ \ \tau(v)\neq\mathrm{CNT}', label='enc')
    d.eq(r'h_v=e_{\tau(v)}+E_w[o_v]+\tfrac{1}{25}\,\alpha_f\odot\log(1+x_v),\ \ \tau(v)=\mathrm{CNT}', label='cnt')
    d.para('where $\\Gamma_v$ is the n-gram set of the name and the constant 25 puts the logarithm of a count on the scale of '
           'the embeddings. <<The two pathways carry different constraints, and only one of them has to be monotone. The '
           'count slope obeys $\\alpha_f\\geq 0$, so Eq. (3) is non-decreasing in $x_v$. The map $A_{\\tau(v)}$ of Eq. (2), '
           'which reads the numeric attributes of a section or data directory (size, virtual size, entropy, property flags), '
           'is left unconstrained. This does not weaken Theorem 1: a node is encoded from its own attributes alone, these '
           'attributes belong to one component, and the threat model of Section 3 lets an insertion create such a component '
           'but never change the attributes of an existing one, which is an edit. The proof therefore needs monotonicity only '
           'along the count pathway.>> The initial state is $z_v^{(0)}=\\sigma_{\\tau(v)}(h_v)$, where '
           '$\\sigma_{\\tau}=\\mathrm{ReLU}\\circ\\mathrm{BN}_{\\tau}$ is a per-type batch normalisation (BN) with '
           'non-negative gain followed by a ReLU.')
    d.h2('4.2 Monotone heterogeneous message passing')
    d.para('A child $u$ belongs to relation $\\rho=\\tau(u)$ and channel $\\chi(u)=\\mathrm{hash}(o_u)\\bmod H$. Messages are maximised within a '
           '(relation, channel) pair and summed across pairs:')
    d.eq(r'm_v^{(\ell)}=\sum_{(\rho,\chi)}\max_{u\in\mathcal{N}_{\rho,\chi}(v)}W_\rho z_u^{(\ell)}', label='msg')
    d.eq(r'z_v^{(\ell+1)}=\sigma_{\tau(v)}\big(W_s z_v^{(\ell)}+m_v^{(\ell)}+W_{\downarrow}z_{\pi(v)}^{(\ell)}+b\big)', label='mhmp')
    d.para('where $\\pi(v)$ is the parent of $v$, the layer index of the weights is omitted, $W_s,W_\\rho,W_{\\downarrow}\\geq 0$ '
           'through an absolute-value parameterisation, and a maximum over an empty set is zero. The max saturates, so many '
           'copies of one component cannot inflate a state, while the sum across channels lets unrelated evidence '
           'accumulate.')
    d.h2('4.3 Prototype MIL head with coverage similarity')
    d.para('The head holds $K$ prototypes $p_k\\geq 0$ with importance vectors $q_k\\geq 0$. Coverage similarity (Eq. (6)) measures how much '
           'of a prototype a node state contains, and a program is scored through its best-matching nodes:')
    d.eq(r's_k(z)=\sum_{i}q_{k,i}\min(z_i,p_{k,i})', label='cov')
    d.eq(r'c_k(P)=\max_{v\in V(P)}s_k\big(z_v^{(L)}\big)\Big/\max\Big(\sum_{i}q_{k,i}\,p_{k,i},\,\varepsilon\Big)', label='covn')
    d.eq(r'S(P)=b_0+\sum_{k=1}^{K}w_k\,c_k(P)+\sum_{i}\beta_i\max_{v}z_{v,i}^{(L)}', label='score')
    d.para('with $w,\\beta\\geq 0$<<, and with $\\varepsilon=10^{-6}$ in Eq. (7), which keeps the normaliser positive for a '
           'prototype whose importance vector or template has collapsed to zero and leaves $c_k$ non-decreasing in every '
           '$z_i$>>. The last term adds axis-aligned prototypes, i.e. coverage of the $i$-th unit vector by an unbounded '
           'prototype, '
           'which keeps gradients dense. Each term of Eq. (8) is attained at one node $v_k^{\\ast}(P)$, so $S(P)-b_0$ decomposes '
           'exactly into contributions of witness nodes. Every five epochs and after training, each prototype is replaced by the '
           'nearest node state of a malicious training program and the head is fine-tuned for two epochs, so explanations name '
           'real components. For family attribution the head has one weight vector per family, giving a monotone score '
           '$S_y(P)$ and threshold $t_y$ for each family $y$.')
    d.h2('4.4 Content-hash partition voting and training')
    d.para('Each leaf goes to group $g(v)=\\mathrm{hash}(o_v)\\bmod M$; counts and header fields are hashed by field name, so '
           'growing or rewriting them never moves a node. The root is copied into every group, and a hub into its own hash group '
           'and every group that holds one of its leaves. The shared model scores every group $G_j(P)$:')
    d.eq(r'V_{\mathrm{mal}}(P)=\sum_{j=1}^{M}\mathbb{1}\big[S(G_j(P))>t\big]', label='vote')
    d.para('and $P$ is malicious when $V_{\\mathrm{mal}}(P)\\geq\\kappa$. Only malicious verdicts need protection, because '
           'the attacker seeks a benign one, so any quorum $\\kappa$ yields a certificate; $\\kappa$ and $t$ are chosen on '
           'validation data, and the majority $\\lfloor M/2\\rfloor+1$ is a special case. Every leaf lies in one group, so '
           'voting costs about one pass. In training each program also contributes one random group, and with '
           '$\\mu(P)=\\max_k c_k(P)$, $\\mathcal{B}_1$ and $\\mathcal{B}_0$ the malicious and benign programs of a batch and $T=0.1$, the '
           'objective is')
    d.eq(r'\mathcal{L}=\mathcal{L}_{\mathrm{BCE}}+\lambda_1\mathcal{L}_{\mathrm{MIL}}+\lambda_2\mathcal{L}_{\mathrm{div}}', label='loss')
    d.eq(r'\mathcal{L}_{\mathrm{MIL}}=-\frac{1}{|\mathcal{B}_1|}\sum_{P\in\mathcal{B}_1}\log\frac{e^{\mu(P)/T}}{e^{\mu(P)/T}+\sum_{B\in\mathcal{B}_0}e^{\mu(B)/T}}', label='mil')
    d.para('where $\\mathcal{L}_{\\mathrm{BCE}}$ is the binary cross-entropy, $\\mathcal{L}_{\\mathrm{div}}$ the mean positive '
           'cosine similarity between prototypes, $\\lambda_1=0.2$ and $\\lambda_2=0.01$. The MIL term pushes benign '
           'components away from all prototypes, which is how benign evidence '
           'shapes the model without breaking monotonicity. Algorithm 1 summarises training and certification.')
    d.algorithm([
        ('**Algorithm 1** CertiProto training and certification', 0),
        ('*Input:* labelled programs, $M$. *Output:* model, verdict, $r^{\\ast}$, witnesses', 0),
        ('1: build $G(P)$ for every program (Section 4.1)', 0),
        ('2: **for** each epoch and each batch **do**', 0),
        ('3: score full graphs and one random group per program', 1),
        ('4: update with Eq. (10), keeping $W,p,q,w,\\beta,\\alpha$ and BN gains $\\geq 0$', 1),
        ('5: every 5 epochs project each $p_k$ onto a real node state', 1),
        ('6: project once more and fine-tune the head for two epochs', 0),
        ('7: select $t$ and $\\kappa$ on validation data', 0),
        ('8: **Inference:** split $G(P)$ into $G_1,\\ldots,G_M$; $V_{\\mathrm{mal}}$ by Eq. (9)', 0),
        ('9: malicious if $V_{\\mathrm{mal}}\\geq\\kappa$; $r^{\\ast}=V_{\\mathrm{mal}}-\\kappa$; witnesses from Eq. (8)', 0),
    ])
    d.para('', sz=8)


def theory(d, R):
    d.h1('5. Theoretical analysis')
    d.para('**Theorem 1 (insertion monotonicity).** <<Assume the sign constraints of Section 4 hold: '
           '$\\alpha_f,W_s,W_\\rho,W_{\\downarrow},q_k,p_k,w,\\beta\\geq 0$ and every batch-normalisation gain is '
           'non-negative. If $P^{\\prime}$ arises from $P$ by inserting nodes, each with the edge to its parent, or by '
           'raising the value $x_v$ of one or more count nodes, and the attributes of the nodes of $P$ are left unchanged,>> '
           'then $S(G(P^{\\prime}))\\geq S(G(P))$ and $S(G_j(P^{\\prime}))\\geq S(G_j(P))$ for every group $j$.')
    d.para('*Proof.* Encodings of existing nodes are unchanged, except that a grown count raises $h_v$ through '
           '$\\alpha_f\\geq 0$; <<the unconstrained map $A_{\\tau(v)}$ of Eq. (2) is never evaluated on a changed argument, '
           'because no node of $P$ changes its attributes.>> At inference batch normalisation is an affine map with '
           'non-negative slope and ReLU is non-decreasing, so $z^{(0)}$ does not decrease on $V(P)$. If $z^{(\\ell)}(P^{\\prime})\\geq z^{(\\ell)}(P)$ on $V(P)$, every maximum in '
           'Eq. (4) runs over a superset of non-negative terms, the weights preserve order and the parent term grows, so Eq. (5) '
           'keeps the inequality at layer $\\ell+1$. In the head, $\\min$ is non-decreasing, the maxima in Eqs. (7) and (8) run '
           'over a superset and $w,\\beta\\geq 0$<<; the normaliser of Eq. (7) does not depend on $P$>>. Groups only gain nodes '
           'under insertion, so the argument applies to each $G_j$. '
           '$\\square$ Hence Eq. (1) holds: a detected sample stays detected under any number of insertions, and insertion can never remove a '
           'family flag $S_y(P)>t_y$ for any per-family threshold $t_y$.')
    d.para('**Theorem 2 (edit certificate).** With $M$ groups, threshold $t$ and quorum $\\kappa$, every '
           '$P^{\\prime}\\in\\mathcal{A}_r(P)$ satisfies $V_{\\mathrm{mal}}(P^{\\prime})\\geq V_{\\mathrm{mal}}(P)-r$, so the '
           'malicious verdict is certified whenever')
    d.eq(r'r\leq r^{\ast}(P)=V_{\mathrm{mal}}(P)-\kappa', label='radius')
    d.para('*Proof.* An edit removes a leaf from one group and may insert a new leaf into another. A group that loses no '
           'node only receives insertions, so by Theorem 1 its vote cannot drop; at most $r$ groups lose a node and each '
           'loses at most one vote. $\\square$ The bound is tight: if every malicious group holds a single witness leaf '
           'whose removal drops its score below $t$, deleting $r^{\\ast}+1$ witnesses leaves $\\kappa-1$ votes.')
    d.para('**Proposition 3 (expressivity).** Any finite disjunction of rules "some node satisfies $\\varphi$" or "some hub '
           'has children satisfying $\\varphi_1$ and $\\varphi_2$" is realised by CertiProto: the encoder emits one indicator '
           'coordinate per condition, a hub unit with non-negative weights and a negative bias fires only when both are '
           'present, and an axis-aligned prototype carries the rule into the score. Only rules requiring the *absence* of a '
           'component are out of reach, which is exactly what an inserting attacker would exploit. One pass costs '
           '$O\\big(L(|V|+|E|)d^2+|V|Kd\\big)$, and voting adds at most $M$ copies of the root and of each hub.')
