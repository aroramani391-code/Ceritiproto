"""Build an IJIES-format .docx from a block specification, reusing the CAMFusion package
(styles, header, footer, page setup). Equations are native OMML; figures are SVG with a 600-dpi PNG fallback."""
from _root import ROOT
import re, os, shutil, zipfile, html, copy
from PIL import Image
import omml

TEMPLATE_DIR = f'{ROOT}/src/cam_unz'
COLW = 4657          # column width (twips) in the two-column layout
PAGEW = 9746         # text width (twips)
EMU_PER_IN = 914400


def esc(s):
    return html.escape(s, quote=False)


BLACK = '<w:color w:val="000000"/>'
BLUE = '<w:color w:val="0000CC"/>'      # revision marking


def rpr(sz=None, b=False, i=False, sup=False, sub=False, font=None, color=None):
    x = ''
    if font:
        x += f'<w:rFonts w:ascii="{font}" w:hAnsi="{font}" w:cs="{font}"/>'
    if b: x += '<w:b/><w:bCs/>'
    if i: x += '<w:i/><w:iCs/>'
    x += (color or BLACK)
    if sz: x += f'<w:sz w:val="{sz}"/><w:szCs w:val="{sz}"/>'
    if sup: x += '<w:vertAlign w:val="superscript"/>'
    if sub: x += '<w:vertAlign w:val="subscript"/>'
    return f'<w:rPr>{x}</w:rPr>'


def run(text, **kw):
    return f'<w:r>{rpr(**kw)}<w:t xml:space="preserve">{esc(text)}</w:t></w:r>'


def style_math(xml, sz=None, color=None):
    """Add Cambria Math font (and size) to every math run so it renders identically everywhere."""
    w = '<w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math"/>' + (color or BLACK) + (f'<w:sz w:val="{sz}"/><w:szCs w:val="{sz}"/>' if sz else '') + '</w:rPr>'
    xml = re.sub(r'<m:r>(<m:rPr>.*?</m:rPr>)?', lambda m: '<m:r>' + (m.group(1) or '') + w, xml)
    return xml


class Doc:
    def __init__(self):
        self.body = []
        self.cites = {}          # key -> number (order of first appearance)
        self.math_inline = []    # collected for batch conversion
        self.media = []          # (name, src path)
        self.rels = []           # (rid, type, target)
        self.rid = 100
        self.eqn = 0
        self.docpr = 5000
        self.labels = {}

    # ---------------------------------------------------------------- inline markup
    def cite_nums(self, keys):
        nums = []
        for k in keys:
            if k not in self.cites:
                self.cites[k] = len(self.cites) + 1
            nums.append(self.cites[k])
        nums = sorted(set(nums))
        # compress ranges: 2,3,4 -> 2-4
        out, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1: j += 1
            out.append(f'{nums[i]}-{nums[j]}' if j - i >= 2 else (f'{nums[i]}, {nums[j]}' if j == i + 1 else f'{nums[i]}'))
            i = j + 1
        return '[' + ', '.join(out) + ']'

    def inline(self, text, sz=None, base_i=False, base_b=False, color=None):
        """Markup: *italic*, **bold**, $math$, \\cite{a,b}, ^{sup}, _{sub}, <<revised text>>."""
        out = []
        pat = re.compile(r'(<<.+?>>|\$[^$]+\$|\\cite\{[^}]+\}|\*\*[^*]+\*\*|\*[^*]+\*|\^\{[^}]+\}|_\{[^}]+\})', re.S)
        for tok in pat.split(text):
            if not tok:
                continue
            if not pat.fullmatch(tok):
                out.append(run(tok, sz=sz, i=base_i, b=base_b, color=color))
            elif tok.startswith('<<'):
                out.append(self.inline(tok[2:-2], sz=sz, base_i=base_i, base_b=base_b, color=BLUE))
            elif tok.startswith('$'):
                x = omml.convert([(tok[1:-1], False)])[0]
                out.append(style_math(x, sz, color))
            elif tok.startswith('\\cite{'):
                out.append(run(self.cite_nums([k.strip() for k in tok[6:-1].split(',')]), sz=sz, i=base_i, b=base_b, color=color))
            elif tok.startswith('**'):
                out.append(run(tok[2:-2], sz=sz, b=True, i=base_i, color=color))
            elif tok.startswith('*'):
                out.append(run(tok[1:-1], sz=sz, i=True, b=base_b, color=color))
            elif tok.startswith('^{'):
                out.append(run(tok[2:-1], sz=sz, sup=True, i=base_i, b=base_b, color=color))
            elif tok.startswith('_{'):
                out.append(run(tok[2:-1], sz=sz, sub=True, i=base_i, b=base_b, color=color))
            else:
                out.append(run(tok, sz=sz, i=base_i, b=base_b, color=color))
        return ''.join(out)

    # ---------------------------------------------------------------- blocks
    def para(self, text, jc='both', sz=None, ind='', spacing='', keep_next=False, italic=False, bold=False, border=None, extra_ppr=''):
        ppr = ''
        if keep_next: ppr += '<w:keepNext/>'
        if border: ppr += border
        if spacing: ppr += spacing
        if ind: ppr += ind
        ppr += f'<w:jc w:val="{jc}"/>' + extra_ppr
        self.body.append(f'<w:p><w:pPr>{ppr}</w:pPr>{self.inline(text, sz=sz, base_i=italic, base_b=bold)}</w:p>')

    def raw(self, xml):
        self.body.append(xml)

    def h1(self, text):
        self.body.append(f'<w:p><w:pPr><w:keepNext/><w:spacing w:before="160" w:after="20"/></w:pPr>'
                         f'{self.inline(text, sz=24, base_b=True)}</w:p>')

    def h2(self, text):
        self.body.append(f'<w:p><w:pPr><w:keepNext/><w:spacing w:before="80"/></w:pPr>'
                         f'{self.inline(text, sz=22, base_b=True)}</w:p>')

    def eq(self, latex, label=None, blue=False):
        self.eqn += 1
        if label: self.labels[label] = self.eqn
        col = BLUE if blue else None
        x = style_math(omml.convert([(latex, False)])[0], color=col)
        self.body.append(f'<w:p><w:pPr><w:keepLines/><w:tabs><w:tab w:val="center" w:pos="{COLW // 2}"/><w:tab w:val="right" w:pos="{COLW}"/></w:tabs><w:spacing w:before="60" w:after="60"/></w:pPr>'
                         f'<w:r><w:tab/></w:r>{x}<w:r>{rpr(color=col)}<w:tab/><w:t>({self.eqn})</w:t></w:r></w:p>')
        return self.eqn

    def section(self, cols):
        """End the current section (continuous break); cols = number of columns of the section just ended."""
        c = '<w:cols w:num="2" w:space="432"/>' if cols == 2 else '<w:cols w:space="708"/>'
        self.body.append(f'<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="120" w:lineRule="exact"/><w:sectPr><w:headerReference w:type="default" r:id="rId7"/><w:footerReference w:type="default" r:id="rId8"/>'
                         f'<w:type w:val="continuous"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1080" w:bottom="1440" w:left="1080" w:header="850" w:footer="567" w:gutter="0"/>{c}<w:docGrid w:linePitch="360"/></w:sectPr></w:pPr></w:p>')

    def figure(self, png, svg, width_in, caption, label=None):
        img = Image.open(png)
        w, h = img.size
        cx = int(width_in * EMU_PER_IN); cy = int(cx * h / w)
        rp = self._add_media(png, 'image'); rs = self._add_media(svg, 'image')
        self.docpr += 1
        drawing = (f'<w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/><wp:effectExtent l="0" t="0" r="0" b="0"/>'
                   f'<wp:docPr id="{self.docpr}" name="Figure {self.docpr}"/><wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/></wp:cNvGraphicFramePr>'
                   f'<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
                   f'<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="{self.docpr}" name="{os.path.basename(png)}"/><pic:cNvPicPr/></pic:nvPicPr>'
                   f'<pic:blipFill><a:blip r:embed="{rp}"><a:extLst><a:ext uri="{{96DAC541-7B7A-43D3-8B79-37D633B846F1}}"><asvg:svgBlip xmlns:asvg="http://schemas.microsoft.com/office/drawing/2016/SVG/main" r:embed="{rs}"/></a:ext></a:extLst></a:blip>'
                   f'<a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing>')
        self.body.append(f'<w:p><w:pPr><w:keepNext/><w:spacing w:before="80" w:after="40"/><w:jc w:val="center"/></w:pPr><w:r>{rpr()}{drawing}</w:r></w:p>')
        self.body.append(f'<w:p><w:pPr><w:spacing w:after="100"/><w:jc w:val="center"/></w:pPr>{self.inline(caption, sz=20)}</w:p>')

    def _add_media(self, path, kind):
        name = f'f{len(self.media) + 1}_{os.path.basename(path)}'
        self.media.append((name, path))
        self.rid += 1
        rid = f'rId{self.rid}'
        self.rels.append((rid, 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/image', f'media/{name}'))
        return rid

    def table(self, caption, rows, widths, header_rows=1, sz=20, align=None, bold_cells=(), merges=(), full=False, first_col_left=True, keep=True):
        """rows: list of lists of cell text (markup allowed). merges: (row, col, span) horizontal merges."""
        self.body.append(f'<w:p><w:pPr><w:keepNext/><w:spacing w:before="100" w:after="40"/><w:jc w:val="center"/></w:pPr>{self.inline(caption, sz=20)}</w:p>')
        total = sum(widths)
        b = '<w:top w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:left w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:right w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
        x = (f'<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="{total}" w:type="dxa"/><w:jc w:val="center"/><w:tblBorders>{b}</w:tblBorders>'
             f'<w:tblLayout w:type="fixed"/><w:tblCellMar><w:left w:w="57" w:type="dxa"/><w:right w:w="57" w:type="dxa"/></w:tblCellMar><w:tblLook w:val="04A0"/></w:tblPr><w:tblGrid>' + ''.join(f'<w:gridCol w:w="{w}"/>' for w in widths) + '</w:tblGrid>')
        mg = {(r, c): s for r, c, s in merges}
        for ri, row in enumerate(rows):
            trpr = '<w:cantSplit/>' + ('<w:tblHeader/>' if ri < header_rows else '') + '<w:jc w:val="center"/>'
            x += f'<w:tr><w:trPr>{trpr}</w:trPr>'
            ci = 0
            for cell in row:
                if cell is None:
                    continue
                span = mg.get((ri, ci), 1)
                w = sum(widths[ci:ci + span])
                tcpr = f'<w:tcW w:w="{w}" w:type="dxa"/>' + (f'<w:gridSpan w:val="{span}"/>' if span > 1 else '') + '<w:vAlign w:val="center"/>'
                jc = 'left' if (ci == 0 and first_col_left and ri >= header_rows) else 'center'
                if align and ri >= header_rows: jc = align[ci]
                bold = ri < header_rows or (ri, ci) in bold_cells
                paras = str(cell).split('\n')
                ps = ''.join(f'<w:p><w:pPr>{"<w:keepNext/>" if keep and ri < len(rows) - 1 else ""}<w:spacing w:before="10" w:after="10" w:line="230" w:lineRule="auto"/><w:jc w:val="{jc}"/></w:pPr>{self.inline(p, sz=sz, base_b=bold)}</w:p>' for p in paras)
                x += f'<w:tc><w:tcPr>{tcpr}</w:tcPr>{ps}</w:tc>'
                ci += span
            x += '</w:tr>'
        x += '</w:tbl>'
        self.body.append(x)
        self.body.append('<w:p><w:pPr><w:spacing w:before="0" w:after="60" w:line="120" w:lineRule="exact"/></w:pPr></w:p>')

    def algorithm(self, lines, sz=20):
        border = ('<w:pBdr><w:top w:val="single" w:sz="4" w:space="1" w:color="000000"/><w:left w:val="single" w:sz="4" w:space="4" w:color="000000"/>'
                  '<w:bottom w:val="single" w:sz="4" w:space="1" w:color="000000"/><w:right w:val="single" w:sz="4" w:space="4" w:color="000000"/></w:pBdr>')
        ind = '<w:ind w:left="57" w:right="57"/>'
        for k, (text, indent) in enumerate(lines):
            pad = run('\u2003' * indent, sz=sz) if indent else ''
            self.body.append(f'<w:p><w:pPr>{"<w:keepNext/>" if k < len(lines) - 1 else ""}<w:keepLines/>{border}<w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/>{ind}<w:jc w:val="left"/></w:pPr>{pad}{self.inline(text, sz=sz)}</w:p>')

    # ---------------------------------------------------------------- output
    def save(self, path, final_cols=2):
        out_dir = path + '_pkg'
        if os.path.exists(out_dir): shutil.rmtree(out_dir)
        shutil.copytree(TEMPLATE_DIR, out_dir)
        tpl = open(f'{TEMPLATE_DIR}/word/document.xml', encoding='utf8').read()
        head = tpl[:tpl.index('<w:body>') + len('<w:body>')]
        c = '<w:cols w:num="2" w:space="432"/>' if final_cols == 2 else '<w:cols w:space="708"/>'
        final = (f'<w:sectPr><w:headerReference w:type="default" r:id="rId7"/><w:footerReference w:type="default" r:id="rId8"/><w:type w:val="continuous"/>'
                 f'<w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1080" w:bottom="1440" w:left="1080" w:header="850" w:footer="567" w:gutter="0"/>{c}<w:docGrid w:linePitch="360"/></w:sectPr>')
        doc = head + ''.join(self.body) + final + '</w:body></w:document>'
        open(f'{out_dir}/word/document.xml', 'w', encoding='utf8').write(doc)
        # media + relationships (drop the template's own image)
        os.makedirs(f'{out_dir}/word/media', exist_ok=True)
        for f in os.listdir(f'{out_dir}/word/media'):
            os.remove(f'{out_dir}/word/media/{f}')
        for name, src in self.media:
            shutil.copy(src, f'{out_dir}/word/media/{name}')
        rels = open(f'{out_dir}/word/_rels/document.xml.rels', encoding='utf8').read()
        rels = re.sub(r'<Relationship [^>]*Target="media/[^"]*"[^>]*/>', '', rels)
        add = ''.join(f'<Relationship Id="{rid}" Type="{t}" Target="{tg}"/>' for rid, t, tg in self.rels)
        rels = rels.replace('</Relationships>', add + '</Relationships>')
        open(f'{out_dir}/word/_rels/document.xml.rels', 'w', encoding='utf8').write(rels)
        ct = open(f'{out_dir}/[Content_Types].xml', encoding='utf8').read()
        for ext, mime in (('png', 'image/png'), ('svg', 'image/svg+xml')):
            if f'Extension="{ext}"' not in ct:
                ct = ct.replace('<Default ', f'<Default Extension="{ext}" ContentType="{mime}"/><Default ', 1)
        open(f'{out_dir}/[Content_Types].xml', 'w', encoding='utf8').write(ct)
        if os.path.exists(path): os.remove(path)
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
            z.write(f'{out_dir}/[Content_Types].xml', '[Content_Types].xml')
            for root, _, files in os.walk(out_dir):
                for f in files:
                    full = os.path.join(root, f)
                    arc = os.path.relpath(full, out_dir)
                    if arc != '[Content_Types].xml':
                        z.write(full, arc)
        return path
