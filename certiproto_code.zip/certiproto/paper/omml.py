"""Convert LaTeX math to native Word OMML using pandoc (no images)."""
from _root import ROOT
import subprocess, tempfile, zipfile, re, os, hashlib, json

CACHE = f'{ROOT}/build/omml_cache.json'
_cache = json.load(open(CACHE)) if os.path.exists(CACHE) else {}


def convert(exprs):
    """exprs: list of (latex, display:bool). Returns list of OMML xml strings (m:oMath elements)."""
    todo = [(e, d) for e, d in exprs if f'{int(d)}|{e}' not in _cache]
    if todo:
        md = []
        for e, d in todo:
            md.append(('$$' + e + '$$') if d else ('$' + e + '$'))
        with tempfile.TemporaryDirectory() as td:
            src = os.path.join(td, 'm.md'); out = os.path.join(td, 'm.docx')
            open(src, 'w').write('\n\nPARASEP\n\n'.join(md))
            subprocess.run(['pandoc', src, '-f', 'markdown', '-o', out], check=True)
            xml = zipfile.ZipFile(out).read('word/document.xml').decode('utf8')
        body = xml[xml.index('<w:body>') + 8: xml.index('</w:body>')]
        paras = re.findall(r'<w:p>.*?</w:p>|<w:p .*?</w:p>', body, re.S)
        paras = [p for p in paras if 'PARASEP' not in p]
        assert len(paras) == len(todo), (len(paras), len(todo))
        for (e, d), p in zip(todo, paras):
            m = re.search(r'<m:oMath>.*</m:oMath>', p, re.S)
            assert m, (e, p[:500])
            _cache[f'{int(d)}|{e}'] = m.group(0)
        json.dump(_cache, open(CACHE, 'w'))
    # a lone '*' in a script is read as an operator by some renderers; use the asterisk operator glyph instead
    return [_cache[f'{int(d)}|{e}'].replace('<m:t>*</m:t>', '<m:t>\u2217</m:t>') for e, d in exprs]
