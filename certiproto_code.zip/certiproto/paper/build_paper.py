"""Assemble the CertiProto paper (IJIES/CAMFusion format) from results.json and the figures."""
from _root import ROOT
import json, sys, importlib
from docxbuild import Doc
import paper_front as PF, paper_setup as PS
from refs import REFS

OUT = sys.argv[1] if len(sys.argv) > 1 else f'{ROOT}/build/CertiProto_paper.docx'


def references(d):
    d.h1('References')
    inv = sorted(d.cites.items(), key=lambda t: t[1])
    for key, n in inv:
        txt = REFS[key]
        d.raw('<w:p><w:pPr><w:ind w:left="360" w:hanging="360"/><w:jc w:val="both"/></w:pPr>' + d.inline(f'[{n}] {txt}', sz=18) + '</w:p>')


def main():
    R = json.load(open(f'{ROOT}/results/results.json'))
    R['fig1_png'] = f'{ROOT}/figs/fig1_arch.png'; R['fig1_svg'] = f'{ROOT}/figs/fig1_arch.svg'
    import os
    q = f'{ROOT}/results/qualitative.json'
    R['qual'] = json.load(open(q)) if os.path.exists(q) else {}
    import paper_results as PR
    importlib.reload(PR)
    R['abstract'] = PR.abstract(R)
    d = Doc()
    PF.front(d, R)
    PF.intro(d, R)
    PF.related(d, R)
    PF.threat(d, R)
    PF.method(d, R)
    PF.theory(d, R)
    PS.setup(d, R)
    PR.results(d, R)
    PR.closing(d, R)
    references(d)
    unused = set(REFS) - set(d.cites)
    print('cited', len(d.cites), 'unused refs', sorted(unused))
    d.save(OUT)
    print('saved', OUT)


if __name__ == '__main__':
    main()
