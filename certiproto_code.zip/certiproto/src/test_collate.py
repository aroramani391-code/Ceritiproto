import torch, numpy as np, time
from cplib import *
from collate_fast import collate_fast
from data import load, splits
for ds in ['clamp', 'bmd']:
    D = load(ds); tt = D['tt']; G = D['graphs']
    tr, va, te = splits(ds, D, 0)
    vmap, V = build_vocab([G[i] for i in tr[:2000]], tt)
    torch.manual_seed(0)
    m = CertiProto(V, tt.ngrams(), d=64, K=32); m.enc.tb.copy_(torch.from_numpy(tt.buckets(OPT['H']))); m.eval()
    gs = [G[i] for i in te[:64]]
    with torch.no_grad():
        for M in (8, 16):
            t = time.time(); a, _ = m(collate(gs, M), vmap); t1 = time.time() - t
            t = time.time(); b, _ = m(collate_fast(gs, M), vmap); t2 = time.time() - t
            grp = list(np.random.randint(0, M, len(gs)))
            c, _ = m(collate(gs, M, grp), vmap); d, _ = m(collate_fast(gs, M, grp), vmap)
            print(ds, M, 'maxdiff', (a - b).abs().max().item(), (c - d).abs().max().item(), 'time', round(t1, 3), round(t2, 3))
