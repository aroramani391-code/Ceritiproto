"""Select the vote quorum kappa per dataset, model and M on validation data: maximise the mean certified TPR
(1% validation FPR) over edit budgets r = 0..5. kappa = floor(M/2)+1 recovers the majority vote."""
from _root import ROOT
import json, glob, pickle, numpy as np
import analyze as A
from sklearn.metrics import f1_score
M_LIST = {'bmd': (8, 16, 32), 'clamp': (2, 3, 4)}
MAIN_M = {'bmd': 16, 'clamp': 3}
out = {}
for ds in ('bmd', 'clamp'):
    for name in ('certiproto-ie', 'gnncert'):
        runs = A.load_runs(ds, name)
        for M in M_LIST[ds]:
            if not runs or any(f'val_M{M}' not in r for r in runs): continue
            best = None
            for k in range(1, M // 2 + 2):
                crit = np.mean([A.certified_curve(r, M, 0.01, rmax=5, kappa=k, split='val').mean() for r in runs])
                if best is None or crit > best[1] + 1e-9: best = (k, crit)
            out[f'{ds}|{name}|{M}'] = best[0]
            print(ds, name, M, 'kappa', best[0], 'val criterion', round(best[1], 4))
json.dump(out, open(f'{ROOT}/results/kappa.json', 'w'), indent=1)
# validation-selected decision thresholds for the vote scores with the chosen kappa
for ds in ('bmd', 'clamp'):
    for name in ('certiproto-ie', 'gnncert'):
        for p in sorted(glob.glob(f'{ROOT}/results/{ds}/{name}_[0-9].pkl')):
            r = pickle.load(open(p, 'rb'))
            M = MAIN_M[ds]
            if f'val_M{M}' not in r: continue
            sv = A.scores_of(r, M, 'val')
            cand = np.unique(np.quantile(sv, np.linspace(0.01, 0.99, 197)))
            f = [f1_score(r['yval'], sv > c) for c in cand]
            r['thr_main'] = float(cand[int(np.argmax(f))])
            pickle.dump(r, open(p, 'wb'))
