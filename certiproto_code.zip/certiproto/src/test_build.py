from _root import ROOT
from docxbuild import *
d = Doc()
d.para('**CertiProto: Test Title for Layout**', jc='center', sz=28)
d.para('Author One^{1*}          Author Two^{2}', jc='center', sz=24)
d.para('**Abstract:** This is the abstract text with inline math $V_{\\mathrm{mal}}(P)-r>M/2$ and a citation \\cite{a,b,c}.', sz=20)
d.section(1)
d.h1('1. Introduction')
for k in range(6):
    d.para('Body text paragraph ' + str(k) + '. ' + 'Monotone message passing keeps the score non-decreasing under insertion of nodes. ' * 6 + ' See \\cite{d}.')
d.eq(r'z_v^{(\ell+1)}=\mathrm{ReLU}\Big(W_s^{(\ell)}z_v^{(\ell)}+\sum_{\rho}\max_{u\in\mathcal{N}_\rho(v)}W_\rho^{(\ell)}z_u^{(\ell)}+b^{(\ell)}\Big)')
d.para(r'where $W\geq 0$ holds for every weight.')
d.table('Table 1. A test table', [['Model', 'AUC', 'F1'], ['LightGBM', '98.8±0.1', '95.2'], ['CertiProto', '**99.1±0.1**', '96.0']], [1700, 1400, 1400])
d.algorithm([('**Algorithm 1** CertiProto training', 0), ('1: **for** each batch **do**', 0), ('2: compute $S(P)$', 1)])
d.section(2)
d.figure(f'{ROOT}/figs/fig1_arch.png', f'{ROOT}/figs/fig1_arch.svg', 6.7, 'Figure. 1 Architecture test caption')
d.section(1)
for k in range(4):
    d.para('More text after the figure. ' * 20)
d.save(f'{ROOT}/build/test.docx')
print(d.cites)
