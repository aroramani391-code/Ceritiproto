from _root import ROOT
import json, figs
R = json.load(open(f'{ROOT}/results/results.json'))
models = ['lgbm', 'lgbm-mono', 'mlp', 'rgat', 'gnncert', 'nngcn', 'twin', 'certiproto-i', 'certiproto-ie']
figs.fig_roc(models, ['lgbm-ember', 'mlp-ember', 'rgat', 'twin', 'certiproto-i'])
figs.fig_confusion('certiproto-i', 'certiproto-i', 'certiproto-i')
figs.fig_epochs(['rgat', 'nngcn', 'twin', 'certiproto-i'], ['rgat', 'twin', 'certiproto-i'])
figs.fig_robust(R)
print('figures done')
