"""Flatten figure PNGs onto white (RGB, no alpha) and keep 600 dpi metadata."""
from _root import ROOT
import glob
from PIL import Image
for f in glob.glob(f'{ROOT}/figs/fig*_*.png'):
    if f.endswith('_preview.png'): continue
    im = Image.open(f)
    if im.mode != 'RGB':
        bg = Image.new('RGB', im.size, 'white')
        bg.paste(im, mask=im.split()[-1] if im.mode == 'RGBA' else None)
        bg.save(f, dpi=(600, 600))
        print('flattened', f)
