"""MOTIF: family evidence under insertion of components taken from programs of other families."""
from _root import ROOT
import sys, os, pickle, numpy as np, torch
from cplib import *
from cplib import OPT
import robust as RB
import train as T
from data import load, splits, motif_label_map

INS_TYPES = (NT['API'], NT['FLAG'], NT['SEC'], NT['DD'], NT['EXP'])


def merge_insert(g, donor):
    """Insert every import, flag, section, data directory and export of `donor` into `g`."""
    h = RB.clone(g)
    hub_by_tok = {int(h.tidx[i]): i for i in np.nonzero(h.ntype == NT['HUB'])[0]}
    present = set(zip(h.tidx.tolist(), h.parent.tolist()))
    nt, ti, bo, pa, hk = list(h.ntype), list(h.tidx), list(h.boff), list(h.parent), list(h.hkey)
    num_idx, num_val = list(h.num_idx), list(h.num_val)
    dmap = {}
    for j in range(1, len(donor.ntype)):
        if donor.ntype[j] == NT['HUB']:
            t = int(donor.tidx[j])
            if t in hub_by_tok:
                dmap[j] = hub_by_tok[t]
            else:
                nt.append(NT['HUB']); ti.append(t); bo.append(-1); pa.append(0); hk.append(donor.hkey[j])
                dmap[j] = len(nt) - 1; hub_by_tok[t] = dmap[j]
    dnum = {int(k): v for k, v in zip(donor.num_idx, donor.num_val)}
    for j in range(1, len(donor.ntype)):
        if donor.ntype[j] not in INS_TYPES: continue
        p = donor.parent[j]
        newp = dmap.get(p, 0) if p > 0 else 0
        if (int(donor.tidx[j]), newp) in present: continue
        nt.append(donor.ntype[j]); ti.append(donor.tidx[j]); bo.append(donor.boff[j]); pa.append(newp); hk.append(donor.hkey[j])
        if j in dnum:
            num_idx.append(len(nt) - 1); num_val.append(dnum[j])
    h.ntype, h.tidx, h.boff, h.parent, h.hkey = (np.array(x, np.int64) for x in (nt, ti, bo, pa, hk))
    h.num_idx = np.array(num_idx, np.int64); h.num_val = np.array(num_val, np.float32).reshape(-1, NUMF)
    return h


def run(name, n=300, donors=20):
    D = load('motif'); graphs = D['graphs']
    lmap = motif_label_map(D)
    tr, va, te = splits('motif', D, 0)  # split on the original labels, as in training
    for i, g in enumerate(graphs):
        g._i = i
        if not hasattr(g, '_orig'): g._orig = g.label
        g.label = lmap.get(g._orig, -1)
    OPT['head'] = 'hybrid'; OPT['H'] = 32
    m, vmap = RB.load_graph_model('motif', name, 0, D)
    glob = D['glob'] if name.startswith('twin') else None
    gte = [graphs[i] for i in te]; gtr = [graphs[i] for i in tr]
    with torch.no_grad():
        lo = T.predict(m, gte, vmap, glob)
    correct = [i for i in range(len(gte)) if lo[i].argmax() == gte[i].label]
    rng = np.random.RandomState(0)
    pick = rng.choice(correct, min(n, len(correct)), replace=False)
    dec, keep1, worst_drop, worst_rank = [], [], [], []
    for i in pick:
        g = gte[i]; y = g.label
        cand = [gtr[j] for j in rng.choice(len(gtr), donors * 2, replace=False) if gtr[j].label != y][:donors]
        gs = [merge_insert(g, dn) for dn in cand]
        for x in gs: x._i = g._i
        with torch.no_grad():
            L = T.predict(m, gs, vmap, glob)
        margins = L[:, y] - np.max(np.delete(L, y, axis=1), axis=1)
        b = int(np.argmin(margins))
        dec.append(bool((L[:, y] < lo[i, y] - 1e-4).any()))
        keep1.append(bool(margins[b] > 0))
        worst_drop.append(float(lo[i, y] - L[:, y].min()))
        worst_rank.append(int(max((L[d] > L[d, y]).sum() for d in range(len(L)))))
    res = dict(name=name, n=len(pick), frac_true_logit_decreased=float(np.mean(dec)), top1_retained=float(np.mean(keep1)),
               mean_worst_drop=float(np.mean(worst_drop)),
               top2_retained=float(np.mean(np.array(worst_rank) < 2)), top5_retained=float(np.mean(np.array(worst_rank) < 5)),
               median_worst_rank=float(np.median(worst_rank)))
    return res


if __name__ == '__main__':
    os.makedirs(f'{ROOT}/results/motif/robust', exist_ok=True)
    for nm in sys.argv[1].split(','):
        p = f'{ROOT}/results/motif/robust/{nm}.pkl'
        if os.path.exists(p): continue
        r = run(nm)
        print(r, flush=True)
        pickle.dump(r, open(p, 'wb'))
