"""Publication figures: ROC curves, confusion matrices, epoch curves, robustness. SVG (vector) + 600-dpi PNG."""
from _root import ROOT
import os, pickle, json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator
from sklearn.metrics import roc_curve, confusion_matrix, auc as sk_auc
from sklearn.preprocessing import label_binarize
import analyze as A
MAIN_M = {'bmd': 16, 'clamp': 3}
M_LIST = {'bmd': (8, 16, 32), 'clamp': (2, 3, 4)}

FIG = f'{ROOT}/figs'
plt.rcParams.update({
    'font.family': 'Liberation Serif', 'font.size': 8, 'axes.titlesize': 8.5, 'axes.labelsize': 8, 'legend.fontsize': 6.8,
    'xtick.labelsize': 7.2, 'ytick.labelsize': 7.2, 'svg.fonttype': 'path', 'axes.linewidth': 0.7, 'lines.linewidth': 1.15,
    'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white', 'mathtext.fontset': 'stix',
    'axes.grid': True, 'grid.color': '#d9d9d9', 'grid.linewidth': 0.5, 'legend.frameon': True, 'legend.framealpha': 1.0,
    'legend.edgecolor': '#bbbbbb', 'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
})
NAMES = {'lgbm': 'LightGBM', 'lgbm-mono': 'Mono-LightGBM', 'mlp': 'MLP', 'rgat': 'R-GAT', 'gnncert': 'PV-R-GAT (vote)',
         'twin': 'Unconstrained twin', 'certiproto-i': 'CertiProto-I', 'certiproto-ie': 'CertiProto-IE (vote)',
         'lgbm-ember': 'LightGBM (EMBER)', 'mlp-ember': 'MLP (EMBER)', 'nngcn': 'NN-GCN'}
STY = {
    'lgbm': dict(color='#4C72B0', ls='-'), 'lgbm-mono': dict(color='#55A868', ls='--'), 'mlp': dict(color='#8172B2', ls='-.'),
    'rgat': dict(color='#DD8452', ls=':'), 'gnncert': dict(color='#937860', ls=(0, (5, 1.5, 1, 1.5))),
    'twin': dict(color='#7f7f7f', ls=(0, (3, 1))), 'certiproto-i': dict(color='#C44E52', ls='-', lw=1.8),
    'certiproto-ie': dict(color='#000000', ls='-', lw=1.5), 'nngcn': dict(color='#2CA02C', ls=(0, (1, 1))), 'lgbm-ember': dict(color='#4C72B0', ls='-'), 'mlp-ember': dict(color='#8172B2', ls='-.'),
}


def save(fig, name):
    fig.savefig(f'{FIG}/{name}.svg')
    fig.savefig(f'{FIG}/{name}.png', dpi=600)
    fig.savefig(f'{FIG}/{name}_preview.png', dpi=150)
    plt.close(fig)


def load0(ds, name, seed=0):
    p = f'{A.RES}/{ds}/{name}_{seed}.pkl'
    return pickle.load(open(p, 'rb')) if os.path.exists(p) else None


def roc_panel(ax, ds, models, title):
    for m in models:
        r = load0(ds, m)
        if r is None: continue
        s = A.scores_of(r, MAIN_M[ds]) if m in ('certiproto-ie', 'gnncert') else r['test']
        fpr, tpr, _ = roc_curve(r['ytest'], s)
        a = sk_auc(fpr, tpr)
        ax.plot(np.maximum(fpr, 1e-4), tpr, label=NAMES[m], **STY[m])
    ax.set_xscale('log'); ax.set_xlim(1e-4, 1); ax.set_ylim(0.0, 1.01)
    ax.set_xlabel('False-positive rate (log scale)'); ax.set_ylabel('True-positive rate'); ax.set_title(title)


def roc_motif(ax, models, title):
    for m in models:
        r = load0('motif', m)
        if r is None: continue
        y, s = r['ytest'], r['test']
        C = s.shape[1]
        Y = label_binarize(y, classes=np.arange(C))
        P = np.exp(s - s.max(1, keepdims=True)); P /= P.sum(1, keepdims=True)
        fpr, tpr, _ = roc_curve(Y.ravel(), P.ravel())
        a = sk_auc(fpr, tpr)
        ax.plot(np.maximum(fpr, 1e-4), tpr, label=NAMES[m], **STY[m])
    ax.set_xscale('log'); ax.set_xlim(1e-4, 1); ax.set_ylim(0.0, 1.01)
    ax.set_xlabel('False-positive rate (log scale)'); ax.set_ylabel('True-positive rate'); ax.set_title(title)
    ax.legend(loc='lower right', handlelength=2.6, borderpad=0.4, labelspacing=0.25, fontsize=6.3)


def fig_roc(models_bin, models_motif):
    fig, axs = plt.subplots(1, 3, figsize=(6.9, 2.3))
    roc_panel(axs[0], 'bmd', models_bin, '(a) BMD, time-aware test')
    roc_panel(axs[1], 'clamp', models_bin, '(b) ClaMP')
    roc_motif(axs[2], models_motif, '(c) MOTIF, micro-average')
    h, l = axs[1].get_legend_handles_labels()
    h0, l0 = axs[0].get_legend_handles_labels()
    for hh, ll in zip(h0, l0):
        if ll not in l: h.append(hh); l.append(ll)
    fig.legend(h, l, loc='lower center', ncol=5, fontsize=6.6, handlelength=2.6, columnspacing=1.2, borderpad=0.35, bbox_to_anchor=(0.36, 0.0))
    fig.tight_layout(pad=0.3, w_pad=0.6, rect=(0, 0.13, 1, 1))
    save(fig, 'fig2_roc')


def cm_panel(ax, cm, labels, title, fmt='d', norm=False, fs=7.5, ylabels=None):
    ylabels = ylabels or labels
    disp = cm.astype(float)
    if norm:
        disp = disp / np.maximum(disp.sum(1, keepdims=True), 1)
    im = ax.imshow(disp, cmap='Greys', vmin=0, vmax=disp.max(), aspect='auto' if len(labels) != len(ylabels) else 'equal')
    ax.set_xticks(range(len(labels))); ax.set_yticks(range(len(ylabels)))
    ax.set_xticklabels(labels, rotation=0 if len(labels) <= 2 else 90); ax.set_yticklabels(ylabels)
    ax.grid(False)
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            v = disp[i, j]
            txt = f'{cm[i, j]:,}' if not norm else (f'{v:.2f}' if v > 0 else '0')
            ax.text(j, i, txt, ha='center', va='center', fontsize=fs, color='white' if v > 0.55 * disp.max() else 'black')
    ax.set_xlabel('Predicted'); ax.set_ylabel('True'); ax.set_title(title)
    for s in ax.spines.values(): s.set_visible(True)


def motif_names():
    from data import load, motif_label_map
    D = load('motif'); lmap = motif_label_map(D)
    raw = json.load(open(f'{ROOT}/prep/motif_famnames.json'))
    return {v: raw[str(k)] for k, v in lmap.items()}


def fig_confusion(model_bmd, model_clamp, model_motif, famnames=None):
    famnames = famnames or motif_names()
    fig = plt.figure(figsize=(6.9, 2.1))
    gs = fig.add_gridspec(1, 3, width_ratios=[1, 1, 1.35])
    for k, (ds, m, title) in enumerate([('bmd', model_bmd, '(a) BMD test'), ('clamp', model_clamp, '(b) ClaMP test')]):
        ax = fig.add_subplot(gs[0, k])
        r = load0(ds, m)
        s = A.scores_of(r, MAIN_M[ds]) if m in ('certiproto-ie', 'gnncert') else r['test']
        thr = r.get('thr_main', 0.0) if m in ('certiproto-ie', 'gnncert') else r.get('thr', 0.0)
        cm = confusion_matrix(r['ytest'], (s > thr).astype(int))
        cm_panel(ax, cm, ['Benign', 'Malware'], title, fs=8)
    ax = fig.add_subplot(gs[0, 2])
    r = load0('motif', model_motif)
    y, p = r['ytest'], r['test'].argmax(1)
    top = [c for c, _ in sorted(((c, (y == c).sum()) for c in np.unique(y)), key=lambda t: -t[1])[:8]]
    mask = np.isin(y, top)
    yy = y[mask]; pp = np.where(np.isin(p[mask], top), p[mask], -1)
    labs = top + [-1]
    cm = confusion_matrix(yy, pp, labels=labs)[:len(top)]
    cm_panel(ax, cm[:, :len(top) + 1], [famnames[c] for c in top] + ['other'], '(c) MOTIF, 8 largest families', norm=True, fs=5.6,
             ylabels=[famnames[c] for c in top])
    ax.set_xlabel('Predicted family'); ax.set_ylabel('True family')
    fig.tight_layout(pad=0.3, w_pad=0.8)
    save(fig, 'fig3_confusion')


def epoch_panel(ax, ds, models, key, title, ylabel):
    for m in models:
        H = []
        for s in range(5):
            r = load0(ds, m, s)
            if r is not None and r['hist'] and key in r['hist'][0]:
                H.append([h[key] for h in r['hist']])
        if not H: continue
        L = max(len(h) for h in H)
        arr = np.full((len(H), L), np.nan)
        for i, h in enumerate(H): arr[i, :len(h)] = h
        mu = np.nanmean(arr, 0); sd = np.nanstd(arr, 0)
        x = np.arange(1, L + 1)
        st = dict(STY[m]); st.pop('lw', None)
        ax.plot(x, mu * (100 if key != 'val_loss' and key != 'train_loss' else 1), label=NAMES[m], lw=1.3 if not m.startswith('certi') else 1.7, **st)
        mul = 100 if key not in ('val_loss', 'train_loss') else 1
        ax.fill_between(x, (mu - sd) * mul, (mu + sd) * mul, color=st['color'], alpha=0.15, lw=0)
    ax.set_xlabel('Epoch'); ax.set_ylabel(ylabel); ax.set_title(title)
    lo = []
    for line in ax.get_lines():
        y = np.asarray(line.get_ydata()); lo.append(np.nanmin(y[1:]) if len(y) > 1 else np.nanmin(y))
    if lo:
        ax.set_ylim(max(0, min(lo) - 0.6), 100.2 if key != 'val_acc' else max(l.get_ydata().max() for l in ax.get_lines()) + 2)
    ax.xaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True))


def fig_epochs(models_bin, models_motif):
    fig, axs = plt.subplots(1, 3, figsize=(6.9, 1.95))
    epoch_panel(axs[0], 'bmd', models_bin, 'val_auc', '(a) BMD validation', 'ROC-AUC (%)')
    epoch_panel(axs[1], 'clamp', models_bin, 'val_auc', '(b) ClaMP validation', 'ROC-AUC (%)')
    epoch_panel(axs[2], 'motif', models_motif, 'val_acc', '(c) MOTIF validation', 'Accuracy (%)')
    for ax in axs: ax.legend(loc='lower right', handlelength=2.4, borderpad=0.35, labelspacing=0.2)
    fig.tight_layout(pad=0.3, w_pad=0.6)
    save(fig, 'fig4_epochs')


def fig_robust(R):
    fig, axs = plt.subplots(1, 4, figsize=(6.9, 2.25))
    for ax, ds, title, xmax in ((axs[0], 'bmd', '(a) BMD certified TPR', 12), (axs[1], 'clamp', '(b) ClaMP certified TPR', 4)):
        C = R[f'cert_{ds}']
        rr = np.arange(0, 13)
        sts = (dict(color='#C44E52', ls='-', marker='o'), dict(color='#000000', ls='-', marker='s'), dict(color='#4C72B0', ls='-', marker='^'))
        for M, st in zip(M_LIST[ds], sts):
            k = f'certiproto-ie@M{M}@0.01'
            if k in C:
                mu = np.array(C[k]['mean']) * 100; sd = np.array(C[k]['std']) * 100
                ax.plot(rr, mu, ms=2.8, lw=1.3, label=f'CertiProto-IE, $M$={M}', **st)
                ax.fill_between(rr, mu - sd, mu + sd, color=st['color'], alpha=0.12, lw=0)
        k = f'gnncert@M{MAIN_M[ds]}@0.01'
        if k in C:
            mu = np.array(C[k]['mean']) * 100
            ax.plot(rr, mu, color='#937860', ls='--', marker='x', ms=3, lw=1.1, label=f'PV-R-GAT, $M$={MAIN_M[ds]}*')
        ax.set_xlabel('Edit budget $r$'); ax.set_ylabel('Certified TPR (%)'); ax.set_title(title)
        ax.set_xlim(0, xmax); ax.set_ylim(0, 100)
        ax.legend(loc='upper right', fontsize=5.8, handlelength=2.0, borderpad=0.3, labelspacing=0.2)
    A_ = R.get('attack_hi_bmd') or R['attack_bmd']
    order = ['lgbm', 'rgat', 'twin', 'nngcn', 'gnncert', 'lgbm-mono', 'certiproto-i', 'certiproto-ie']
    for m in order:
        if m in A_:
            st = dict(STY.get(m, dict(color='k'))); st.pop('lw', None)
            yi = np.array(A_[m]['ins_by_k']) * 100
            ym = np.array(A_[m]['mix_by_r']) * 100
            axs[2].plot(np.arange(len(yi)), yi, label=NAMES.get(m, m), lw=1.6 if m.startswith('certi') else 1.15, **st)
            axs[3].plot(np.arange(len(ym)), ym, marker='o', ms=2.5, label=NAMES.get(m, m), lw=1.6 if m.startswith('certi') else 1.15, **st)
    axs[2].set_xlabel('Inserted components'); axs[2].set_ylabel('Evasion rate (%)'); axs[2].set_title('(c) BMD, insertion only')
    axs[3].set_xlabel('Edit budget $r$'); axs[3].set_ylabel('Evasion rate (%)'); axs[3].set_title('(d) BMD, insertion + edits')
    axs[2].set_xlim(0, 40); axs[3].set_xticks(range(0, 9, 2))
    for ax in axs[2:]: ax.set_ylim(-2, 102)
    h, l = axs[2].get_legend_handles_labels()
    fig.legend(h, l, loc='lower center', ncol=4, fontsize=6.6, handlelength=2.6, columnspacing=1.6, borderpad=0.3, bbox_to_anchor=(0.5, 0.0))
    fig.tight_layout(pad=0.3, w_pad=0.5, rect=(0, 0.16, 1, 1))
    save(fig, 'fig5_robust')
