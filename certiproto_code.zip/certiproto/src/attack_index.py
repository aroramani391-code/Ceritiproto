"""Recover, for every attacked model, which test samples the attack was run on.

run_attacks.py draws its sample list from a freshly seeded RandomState before any
attack step, so the draw is reproducible from the model and its validation
threshold alone. Saving the indices lets the evasion outcomes of two models be
compared on the samples they were both attacked on (a paired test) instead of on
two different draws.
"""
from _root import ROOT
import os, sys, pickle, numpy as np, torch
from cplib import OPT
import robust as RB
from data import load, splits

RES = f'{ROOT}/results'
MAIN_M = {'bmd': 16, 'clamp': 3}
MODELS = ['lgbm', 'lgbm-mono', 'rgat', 'gnncert', 'nngcn', 'twin', 'certiproto-i', 'certiproto-ie']


def run(ds, sub, N=None):
    D = load(ds)
    graphs = D['graphs']
    for i, g in enumerate(graphs):
        g._i = i
    tr, va, te = splits(ds, D, 0)
    gva = [graphs[i] for i in va]
    gte = [graphs[i] for i in te]
    yva = np.array([g.label for g in gva])
    out = {}
    for name in MODELS:
        p = f'{RES}/{ds}/{sub}/{name}.pkl'
        if not os.path.exists(p):
            continue
        M = MAIN_M[ds] if name in ('certiproto-ie', 'gnncert') else 1
        if name.startswith('lgbm'):
            scorer = RB.FlatScorer(ds, name, 0, D)
        else:
            OPT['head'] = 'meanlin' if name.startswith('nngcn') else 'hybrid'
            OPT['H'] = 32
            m, vmap = RB.load_graph_model(ds, name, 0, D)
            import analyze as AN
            kappa = AN.kappa_for(ds, name, M) if M > 1 else None
            scorer = RB.GraphScorer(m, vmap, D['glob'] if name.startswith('twin') else None, M=M, kappa=kappa)
        sv = scorer(gva)
        neg = np.sort(sv[yva == 0])
        tau = neg[int(np.ceil(0.99 * len(neg))) - 1]
        st = scorer(gte)
        det = [i for i, g in enumerate(gte) if g.label == 1 and st[i] > tau]
        saved = pickle.load(open(p, 'rb'))
        # the attack drew min(n, |det|) samples from a freshly seeded RNG before any attack step,
        # so redrawing that many reproduces the list exactly (sample counts differ per model)
        rng = np.random.RandomState(0)
        pick = rng.choice(det, len(saved['ins']), replace=False)
        assert abs(float(tau) - saved['tau']) < 1e-6, (name, tau, saved['tau'])
        out[name] = dict(pick=[int(x) for x in pick], ins=[int(r[0]) for r in saved['ins']],
                         mix=[(int(r[0]), int(r[2])) for r in saved['mix']])
        print(ds, sub, name, 'n', len(pick), flush=True)
    pickle.dump(out, open(f'{RES}/{ds}/{sub}_index.pkl', 'wb'))


if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2])
