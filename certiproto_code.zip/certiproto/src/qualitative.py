"""Qualitative witnesses on the original public data: BMD test malware and MOTIF families."""
from _root import ROOT
import json, pickle, numpy as np, torch
import explain as E, robust as RB, train as T
from data import load, splits, motif_label_map
from cplib import OPT
from analyze import vote_score

out = {}
# ---------------- BMD: three detected future malware samples from different years
D = load('bmd'); G = D['graphs']; tt = D['tt']
for i, g in enumerate(G): g._i = i
tr, va, te = splits('bmd', D, 0)
r = pickle.load(open(f'{ROOT}/results/bmd/certiproto-i_0.pkl', 'rb'))
s, y = r['test'], r['ytest']
years = np.array([G[i].meta['time'][:4] for i in te])
picks = []
rng = np.random.RandomState(3)
for yr in ('2015', '2017', '2019'):
    cand = [k for k in range(len(te)) if y[k] == 1 and years[k] == yr and s[k] > r['thr']]
    picks.append(te[rng.choice(cand)])
wit = E.witnesses('bmd', 'certiproto-i', picks, top=5)
OPT['head'] = 'hybrid'; OPT['H'] = 32
mie, vmie = RB.load_graph_model('bmd', 'certiproto-ie', 0, D)
rie = pickle.load(open(f'{ROOT}/results/bmd/certiproto-ie_0.pkl', 'rb'))
tie = rie.get('thr_main', 0.0)
bmd = []
for gi, w in zip(picks, wit):
    with torch.no_grad():
        gl, _ = T.forward(mie, [G[gi]], vmie, None, 16)
    votes = int((gl.numpy() > tie).sum())
    import analyze as AN
    kap = AN.kappa_for('bmd', 'certiproto-ie', 16)
    bmd.append(dict(sha1=G[gi].gid, first_seen=G[gi].meta['time'], score=w[1], votes=votes, radius=votes - kap, kappa=kap,
                    witnesses=[(a, b, c) for a, b, c in w[2]]))
out['bmd'] = bmd
# ---------------- MOTIF: witnesses for well-known families (fold 0, correctly classified)
D2 = load('motif'); G2 = D2['graphs']; lmap = motif_label_map(D2)
tr2, va2, te2 = splits('motif', D2, 0)  # split on the original labels, as in training
for i, g in enumerate(G2):
    g._i = i
    if not hasattr(g, '_orig'): g._orig = g.label
    g.label = lmap.get(g._orig, -1)
r2 = pickle.load(open(f'{ROOT}/results/motif/certiproto-i_0.pkl', 'rb'))
pred = r2['test'].argmax(1)
fam = {}
for k, i in enumerate(te2):
    if pred[k] == G2[i].label:
        fam.setdefault(G2[i].meta['family'], []).append(i)
big = sorted(fam, key=lambda f: -len(fam[f]))[:3]
mot = []
for f in big:
    gi = fam[f][0]
    w = E.witnesses('motif', 'certiproto-i', [gi], top=5)[0]
    mot.append(dict(family=f, sha256=G2[gi].gid, witnesses=[(a, b, c) for a, b, c in w[2]]))
out['motif'] = mot
out['motif_audit'] = E.motif_audit('certiproto-i')
json.dump(out, open(f'{ROOT}/results/qualitative.json', 'w'), indent=1, default=float)
print(json.dumps(out, indent=1, default=float)[:3000])
