import torch, numpy as np, copy, time
from cplib import *
from data import load, splits
D = load('bmd'); tt = D['tt']; G = D['graphs']
tr, va, te = splits('bmd', D, 0)
vmap, V = build_vocab([G[i] for i in tr[:3000]], tt)
ngt = tt.ngrams()
torch.manual_seed(0)
m = CertiProto(V, ngt, d=64, K=32)
# random training steps to move weights away from init
opt = torch.optim.Adam(m.parameters(), 2e-3)
for it in range(5):
    gs = [G[i] for i in np.random.choice(tr, 64)]
    b = collate(gs); y = torch.tensor([g.label for g in gs], dtype=torch.float)
    lo, _ = m(b, vmap); loss = F.binary_cross_entropy_with_logits(lo, y); opt.zero_grad(); loss.backward(); opt.step()
m.eval()
def insert(g, k, rng):
    g2 = copy.copy(g)
    nt, ti, bo, pa, hk = list(g.ntype), list(g.tidx), list(g.boff), list(g.parent), list(g.hkey)
    hubs = [i for i, t in enumerate(nt) if t == NT['HUB']] + [0]
    for _ in range(k):
        donor = G[rng.randint(len(G))]; j = rng.randint(1, len(donor.ntype))
        if donor.ntype[j] in (NT['HUB'], NT['CNT']): continue
        nt.append(donor.ntype[j]); ti.append(donor.tidx[j]); bo.append(donor.boff[j]); pa.append(hubs[rng.randint(len(hubs))]); hk.append(donor.hkey[j])
    g2.ntype, g2.tidx, g2.boff, g2.parent, g2.hkey = map(lambda a: np.array(a, np.int64), (nt, ti, bo, pa, hk))
    g2.num_idx, g2.num_val = g.num_idx.copy(), g.num_val.copy()
    # also increase count values
    cnt = np.nonzero(g2.ntype[g2.num_idx] == NT['CNT'])[0]
    g2.num_val = g2.num_val.copy(); g2.num_val[cnt, 0] += rng.rand(len(cnt)) * 0.1
    return g2
rng = np.random.RandomState(0)
viol = 0; tot = 0
with torch.no_grad():
    for i in te[:200]:
        g = G[i]; g2 = insert(g, 30, rng)
        for M in (1, 8):
            s1, _ = m(collate([g], M), vmap); s2, _ = m(collate([g2], M), vmap)
            tot += s1.numel(); viol += int((s2 < s1 - 1e-5).sum())
print('monotonicity violations', viol, 'of', tot)
t = time.time()
gs = [G[i] for i in tr[:640]]
for k in range(0, 640, 64):
    b = collate(gs[k:k+64]); y = torch.tensor([g.label for g in gs[k:k+64]], dtype=torch.float)
    m.train(); lo, _ = m(b, vmap); loss = F.binary_cross_entropy_with_logits(lo, y); opt.zero_grad(); loss.backward(); opt.step()
print('sec per 640 graphs (train)', time.time() - t)
t = time.time()
with torch.no_grad():
    for k in range(0, 640, 64):
        b = collate(gs[k:k+64], 16); lo, _ = m(b, vmap)
print('sec per 640 graphs M=16 eval', time.time() - t)
rng = np.random.RandomState(0)
with torch.no_grad():
    for i in te[:200]:
        g = G[i]; g2 = insert(g, 30, rng)
        for M in (1, 8):
            s1, _ = m(collate([g], M), vmap); s2, _ = m(collate([g2], M), vmap)
            d = (s2 - s1)
            if (d < -1e-5).any(): print(M, d.min().item(), s1.abs().max().item())
