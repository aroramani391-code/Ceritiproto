"""Collect every number used in the paper into results.json (single source of truth)."""
import os, json, pickle, numpy as np
from scipy.stats import ttest_rel
from sklearn.metrics import roc_auc_score
import analyze as A

RES = A.RES
MAIN_M = {'bmd': 16, 'clamp': 3}
M_LIST = {'bmd': (8, 16, 32), 'clamp': (2, 3, 4)}
BIN_MODELS = ['lgbm', 'lgbm-mono', 'mlp', 'rgat', 'gnncert', 'nngcn', 'twin', 'certiproto-i', 'certiproto-ie']
MOTIF_MODELS = ['lgbm-ember', 'mlp-ember', 'rgat', 'twin', 'certiproto-i']


def mstd(vals):
    return [float(np.mean(vals)), float(np.std(vals))]


def clean(ds):
    out = {}
    for m in BIN_MODELS:
        Ms = [MAIN_M[ds], 1] if m in ('gnncert', 'certiproto-ie') else [1]
        for M in Ms:
            s = A.summarize(ds, m, M)
            if s is None: continue
            key = m if M == 1 or m != 'certiproto-ie' else m
            key = (f'{m}@main' if M == MAIN_M[ds] else f'{m}@M1') if m in ('gnncert', 'certiproto-ie') else m
            out[key] = {k: [float(v[0]), float(v[1])] for k, v in s.items() if k not in ('n', 'per_seed')}
            out[key]['n'] = s['n']
            out[key]['per_seed'] = s['per_seed']
    return out


def certified(ds):
    out = {}
    for m in ('certiproto-ie', 'gnncert', 'certiproto-i'):
        runs = A.load_runs(ds, m)
        for M in M_LIST[ds]:
            for fpr in (0.01, 0.001):
                curves = [A.certified_curve(r, M, fpr, rmax=12) for r in runs if f'test_M{M}' in r]
                if not curves: continue
                c = np.array(curves)
                out[f'{m}@M{M}@{fpr}'] = dict(mean=c.mean(0).tolist(), std=c.std(0).tolist(), n=len(curves))
    return out


def attacks(ds, sub='attacks'):
    out = {}
    d = f'{RES}/{ds}/{sub}'
    if not os.path.isdir(d): return out
    for f in os.listdir(d):
        r = pickle.load(open(f'{d}/{f}', 'rb'))
        ins = np.array(r['ins'], dtype=float); mix = np.array(r['mix'], dtype=float)
        o = dict(n=len(ins), tau=r['tau'], n_detected=r['n_detected'], n_mal=r['n_mal'])
        o['ins_evasion'] = float(ins[:, 0].mean())
        kmax = int(r.get('K_ins', 25)) + 1
        o['ins_by_k'] = [float(np.mean((ins[:, 0] == 1) & (ins[:, 1] <= k))) for k in range(kmax)]
        # strongest of the two attacks within <= r edits (the insertion-only run uses 0 edits)
        rmax = int(r.get('R_edit', 4)) + 1
        o['mix_by_r'] = [float(np.mean((ins[:, 0] == 1) | ((mix[:, 0] == 1) & (mix[:, 2] <= rr)))) for rr in range(rmax)]
        o['mix_evasion'] = float(np.mean((ins[:, 0] == 1) | (mix[:, 0] == 1)))
        o['median_ins_to_evade'] = float(np.median(ins[ins[:, 0] == 1, 1])) if (ins[:, 0] == 1).any() else None
        # detection rate at the validation 1%-FPR threshold, before and after each attack
        pre = r['n_detected'] / max(r['n_mal'], 1)
        o['tpr_pre'] = float(pre)
        o['tpr_post_ins'] = float(pre * (1 - o['ins_evasion']))
        o['tpr_post_mix'] = [float(pre * (1 - x)) for x in o['mix_by_r']]
        o['K_ins'] = int(r.get('K_ins', 25)); o['R_edit'] = int(r.get('R_edit', 4))
        if r.get('radius'):
            rad = np.array(r['radius'])
            o['mean_radius'] = float(rad.mean())
            o['cert_violations'] = int(np.sum((mix[:, 0] == 1) & (mix[:, 2] <= rad)) + np.sum((ins[:, 0] == 1) & (rad >= 0)))
            o['frac_radius_ge4'] = float(np.mean(rad >= 4))
        out[r['name']] = o
    return out


def motif():
    out = {}
    for m in MOTIF_MODELS:
        s = A.family_metrics('motif', m)
        if s is None: continue
        out[m] = {k: [float(v[0]), float(v[1])] for k, v in s.items() if k not in ('n', 'per_seed')}
        out[m]['n'] = s['n']
        p = f'{RES}/motif/robust/{m}.pkl'
        if os.path.exists(p):
            out[m]['robust'] = pickle.load(open(p, 'rb'))
    return out


def paired_evasion(ds, sub='attacks_paired', ours='certiproto-i'):
    """Exact McNemar test on insertion-only evasion, restricted to the programs that both
    detectors were attacked on. The attacked set differs per detector (each is attacked on the
    malware it detects), so an unpaired test on the two rates would be mis-specified."""
    from scipy.stats import binomtest
    d = f'{RES}/{ds}/{sub}'
    if not os.path.isdir(d):
        return {}
    idx = {}
    for f in os.listdir(d):
        r = pickle.load(open(f'{d}/{f}', 'rb'))
        idx[r['name']] = dict(pick=r['pick'], ins=[int(x[0]) for x in r['ins']],
                              mix=[(int(x[0]), int(x[2])) for x in r['mix']])
    if ours not in idx:
        return {}
    a = dict(zip(idx[ours]['pick'], idx[ours]['ins']))
    out = {}
    for m, v in idx.items():
        if m == ours:
            continue
        b = dict(zip(v['pick'], v['ins']))
        common = sorted(set(a) & set(b))
        if len(common) < 10:
            continue
        n01 = sum(1 for i in common if a[i] == 0 and b[i] == 1)   # only the baseline is evaded
        n10 = sum(1 for i in common if a[i] == 1 and b[i] == 0)   # only ours is evaded
        pv = 1.0 if n01 + n10 == 0 else float(binomtest(min(n01, n10), n01 + n10, 0.5).pvalue)
        out[m] = dict(n_common=len(common), ours_only=n10, other_only=n01, p=pv,
                      ours_rate=float(np.mean([a[i] for i in common])),
                      other_rate=float(np.mean([b[i] for i in common])))
    return out


def significance(ds, ours='certiproto-i', others=None):
    out = {}
    ro = A.load_runs(ds, ours)
    if not ro: return out
    for m in others or BIN_MODELS:
        if m == ours: continue
        rb = A.load_runs(ds, m)
        n = min(len(ro), len(rb))
        if n < 2: continue
        a1 = [roc_auc_score(r['ytest'], A.scores_of(r, MAIN_M[ds]) if ours == 'certiproto-ie' else r['test']) for r in ro[:n]]
        a2 = [roc_auc_score(r['ytest'], A.scores_of(r, MAIN_M[ds]) if m in ('gnncert', 'certiproto-ie') else r['test']) for r in rb[:n]]
        t, p = ttest_rel(a1, a2)
        s1 = [A.scores_of(r, MAIN_M[ds]) if ours == 'certiproto-ie' else r['test'] for r in ro[:n]]
        t1 = [r.get('thr_main' if ours == 'certiproto-ie' else 'thr', 0.0) for r in ro[:n]]
        t2 = [r.get('thr_main' if m in ('gnncert', 'certiproto-ie') else 'thr', 0.0) for r in rb[:n]]
        mc = [A.mcnemar(ro[i]['ytest'], s1[i], A.scores_of(rb[i], MAIN_M[ds]) if m in ('gnncert', 'certiproto-ie') else rb[i]['test'], t1[i], t2[i]) for i in range(n)]
        out[m] = dict(delta_auc=float(np.mean(a1) - np.mean(a2)), t=float(t), p=float(p), n=n,
                      mcnemar=[(int(a), int(b), float(c)) for a, b, c in mc])
    return out


def explain(ds):
    out = {}
    d = f'{RES}/{ds}/explain'
    if not os.path.isdir(d): return out
    for f in os.listdir(d):
        out[f[:-4]] = pickle.load(open(f'{d}/{f}', 'rb'))
    return out


def ablation(ds='clamp'):
    out = {}
    for v in ['certiproto-i', 'certiproto-i-relax', 'certiproto-i-cosine', 'certiproto-i-meanagg', 'certiproto-i-nomil',
              'certiproto-i-protoonly', 'certiproto-i-H1', 'certiproto-i-nongram', 'certiproto-i-K16', 'certiproto-i-K64']:
        runs = [pickle.load(open(f'{RES}/{ds}/{v}_{s}.pkl', 'rb')) for s in range(5) if os.path.exists(f'{RES}/{ds}/{v}_{s}.pkl')]
        if not runs: continue
        ms = [A.binary_metrics(r['ytest'], r['test']) for r in runs]
        out[v] = {k: mstd([m[k] for m in ms]) for k in ms[0]}
        out[v]['n'] = len(runs)
        out[v]['infer_ms'] = mstd([r['infer_ms'] for r in runs])
        a = f'{RES}/{ds}/attacks_abl/{v}.pkl'
        if os.path.exists(a):
            rr = pickle.load(open(a, 'rb'))
            out[v]['ins_evasion'] = float(np.mean([x[0] for x in rr['ins']]))
    return out


def timing(ds):
    out = {}
    for m in BIN_MODELS:
        runs = A.load_runs(ds, m)
        if runs:
            out[m] = dict(train_s=mstd([r['train_time'] for r in runs]), infer_ms=mstd([r['infer_ms'] for r in runs]))
    return out


if __name__ == '__main__':
    R = dict(stats=json.load(open(f'{RES}/dataset_stats.json')))
    for ds in ('bmd', 'clamp'):
        R[f'clean_{ds}'] = clean(ds)
        R[f'cert_{ds}'] = certified(ds)
        R[f'attack_{ds}'] = attacks(ds)
        R[f'attack_hi_{ds}'] = attacks(ds, 'attacks_hi' if ds == 'bmd' else 'attacks_hi2')
        if ds == 'clamp':
            R['attack_ins60_clamp'] = attacks(ds, 'attacks_hi')
        R[f'sig_{ds}'] = significance(ds)
        R[f'sig_ie_{ds}'] = significance(ds, ours='certiproto-ie')
        R[f'evasion_test_{ds}'] = paired_evasion(ds)
        R[f'explain_{ds}'] = explain(ds)
        R[f'time_{ds}'] = timing(ds)
    # insertion split: growth of a count on an existing node vs arrival of a new component node
    R['nngcn_split'] = {k: {m: v['ins_evasion'] for m, v in attacks('bmd', f'attacks_{k}').items()}
                        for k in ('grow', 'nodes') if os.path.isdir(f'{RES}/bmd/attacks_{k}')}
    # cost of the sign constraints alone: identical architecture, constraints removed
    R['relax'] = {}
    for ds in ('bmd', 'clamp'):
        base, rel = A.load_runs(ds, 'certiproto-i'), A.load_runs(ds, 'certiproto-i-relax')
        if not rel:
            continue
        n = min(len(base), len(rel))
        f = lambda rs: mstd([roc_auc_score(r['ytest'], r['test']) for r in rs[:n]])
        R['relax'][ds] = dict(n=n, base_auc=f(base), relax_auc=f(rel))
    R['motif'] = motif()
    R['ablation'] = ablation('clamp')
    json.dump(R, open(f'{RES}/results.json', 'w'), indent=1, default=float)
    print('saved')
