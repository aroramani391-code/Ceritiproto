"""Build PE component records for the Brazilian Malware Dataset (feature CSVs only)."""
from _root import ROOT
import json, ast, collections, datetime, math, pickle
raw = json.load(open(f'{ROOT}/prep/bmd_raw.json'))

def lit(s):
    if not s: return []
    try: return ast.literal_eval(s)
    except Exception: return None

def flat_sigs(s):
    v = lit(s)
    if not v: return []
    out = []
    def rec(x):
        if isinstance(x, (list, tuple)):
            for y in x: rec(y)
        elif isinstance(x, str) and x.strip():
            out.append(x.strip())
    rec(v)
    return sorted(set(out))

def to_int(x):
    try: return int(float(x))
    except Exception: return None

# --- deduplicate: keep earliest occurrence per SHA1; drop hashes labelled both ways
lab_by_hash = collections.defaultdict(set)
for r in raw: lab_by_hash[r['SHA1']].add(r['label'])
conflict = {h for h, s in lab_by_hash.items() if len(s) > 1}
seen = {}
for r in raw:
    h = r['SHA1']
    if h in conflict or not h: continue
    if r['label'] == 1:
        if h not in seen or r['day'] < seen[h]['day']: seen[h] = r
    else:
        seen.setdefault(h, r)
rows = list(seen.values())
print('unique rows', len(rows), 'conflicts dropped', len(conflict))

# --- API->DLL export dictionary: exact (library, function) pairs from the MOTIF import tables
#     plus single-library import tables of this dataset. Functions are attached only when the
#     file imports a library known to export them; otherwise they attach to the root.
api2dll = collections.defaultdict(set)
for line in open(f'{ROOT}/data/MOTIF/dataset/motif_dataset.jsonl'):
    r = json.loads(line)
    for dl, al in r['imports'].items():
        for a in al:
            api2dll[a.lower()].add(dl.lower())
parsed = []
single = 0
for r in rows:
    dlls = lit(r['ImportedDlls']); apis = lit(r['ImportedSymbols'])
    if dlls is None or apis is None: continue
    dlls = [str(x).lower() for x in dlls if x]
    apis = [str(x) if x not in (None, '') else '' for x in apis]
    parsed.append((r, dlls, apis))
    if len(set(dlls)) == 1:
        single += 1
        for a in apis:
            if a: api2dll[a.lower()].add(dlls[0])
print('parsed', len(parsed), 'single-library files', single, 'dictionary APIs', len(api2dll))


def align(dlls, apis, dic):
    out = []
    for a in apis:
        cand = [j for j, d in enumerate(dlls) if d in dic.get(a.lower(), ())]
        out.append(cand[0] if cand else -1)
    return out


HDR_CAT = ['Machine', 'Magic', 'FileAlignment', 'ImageBase', 'BaseOfCode', 'BaseOfData', 'SizeOfHeaders',
           'SizeOfOptionalHeader', 'NumberOfRvaAndSizes']
COUNTS = ['NumberOfSections', 'Size', 'SizeOfImage', 'SizeOfCode', 'SizeOfInitializedData', 'SizeOfUninitializedData']
recs = []
for r, dlls, apis in parsed:
    idx = align(dlls, apis, api2dll) if dlls else [-1] * len(apis)
    api_nodes = []
    seen_api = set()
    for a, j in zip(apis, idx):
        if not a: a = '#ordinal'
        key = (a.lower(), j)
        if key in seen_api: continue
        seen_api.add(key); api_nodes.append((a.lower(), j))
    hdr = []
    for f in HDR_CAT:
        v = to_int(r[f]);
        if v is not None: hdr.append((f, v))
    pts = to_int(r['PointerToSymbolTable']); nsym = to_int(r['NumberOfSymbols'])
    hdr.append(('PointerToSymbolTable', 0 if not pts else 1))
    hdr.append(('NumberOfSymbols', 0 if not nsym else 1))
    flags = []
    ch = to_int(r['Characteristics']) or 0; dc = to_int(r['DllCharacteristics']) or 0
    flags += ['chr_b%d' % b for b in range(16) if ch >> b & 1]
    flags += ['dllchr_b%d' % b for b in range(16) if dc >> b & 1]
    counts = {f: max(0, to_int(r[f]) or 0) for f in COUNTS}
    try: ent = float(r['Entropy'])
    except Exception: ent = 0.0
    if r['label'] == 1:
        t = r['day']
    else:
        t = (r['FormatedTimeDateStamp'] or '1970-01-01')[:10]
    recs.append(dict(id=r['SHA1'], label=r['label'], time=t, dlls=sorted(set(dlls), key=dlls.index), dll_list=dlls,
                     apis=api_nodes, hdr=hdr, flags=flags, sigs=flat_sigs(r['Identify']), counts=counts,
                     glob={'Entropy': ent}))
# remap api dll index to index in unique dll list
for rec in recs:
    uniq = rec['dlls']; full = rec.pop('dll_list')
    rec['apis'] = sorted({(a, uniq.index(full[j]) if (full and j >= 0) else -1) for a, j in rec['apis']})
    rec['dlls'] = uniq
c = collections.Counter(r['label'] for r in recs)
print('records', len(recs), c)
pickle.dump(recs, open(f'{ROOT}/prep/bmd_recs.pkl', 'wb'))
# split by time
def split(t):
    if t < '2015-01-01': return 'train'
    if t < '2015-07-01': return 'val'
    return 'test'
sc = collections.Counter((split(r['time']), r['label']) for r in recs)
print(sorted(sc.items()))
import numpy as np
print('nodes/graph', np.mean([len(r['apis']) + len(r['dlls']) + len(r['hdr']) + len(r['flags']) + len(r['sigs']) + 6 for r in recs]))
