"""Per-year detection on the BMD time-aware test set (drift)."""
from _root import ROOT
import pickle, numpy as np, json
from sklearn.metrics import roc_auc_score
from data import load, splits
import analyze as A

D = load('bmd'); G = D['graphs']
tr, va, te = splits('bmd', D, 0)
years = np.array([G[i].meta['time'][:4] for i in te])
out = {}
for m in ('lgbm', 'lgbm-mono', 'rgat', 'nngcn', 'twin', 'certiproto-i', 'certiproto-ie'):
    runs = A.load_runs('bmd', m)
    if not runs: continue
    per = {}
    for yr in sorted(set(years)):
        sel = years == yr
        aucs, tprs = [], []
        for r in runs:
            s = A.scores_of(r, 16) if m == 'certiproto-ie' else r['test']
            y = r['ytest']
            if sel.sum() < 20 or len(set(y[sel])) < 2: continue
            aucs.append(roc_auc_score(y[sel], s[sel]))
            thr = r.get('thr_main' if m == 'certiproto-ie' else 'thr', 0.0)
            tprs.append(float(((s[sel] > thr) & (y[sel] == 1)).sum() / max((y[sel] == 1).sum(), 1)))
        if aucs:
            per[yr] = dict(n=int(sel.sum()), n_mal=int((runs[0]['ytest'][sel] == 1).sum()),
                           auc=[float(np.mean(aucs)), float(np.std(aucs))], tpr=[float(np.mean(tprs)), float(np.std(tprs))])
    out[m] = per
json.dump(out, open(f'{ROOT}/results/drift_bmd.json', 'w'), indent=1)
for m, per in out.items():
    print(m, {y: round(v['auc'][0] * 100, 1) for y, v in per.items()})
