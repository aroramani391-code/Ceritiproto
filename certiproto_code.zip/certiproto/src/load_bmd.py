from _root import ROOT
import csv, glob, os, sys, ast, json, collections
csv.field_size_limit(sys.maxsize)
ROOT=f'{ROOT}/data/brazilian-malware-dataset/goodware-malware'
KEEP=['BaseOfCode','BaseOfData','Characteristics','DllCharacteristics','Entropy','FileAlignment','Identify','ImageBase','ImportedDlls','ImportedSymbols','Machine','Magic','NumberOfRvaAndSizes','NumberOfSections','NumberOfSymbols','PE_TYPE','PointerToSymbolTable','SHA1','MD5','Size','SizeOfCode','SizeOfHeaders','SizeOfImage','SizeOfInitializedData','SizeOfOptionalHeader','SizeOfUninitializedData','TimeDateStamp','FormatedTimeDateStamp']
def rows(path):
    with open(path, newline='', encoding='utf-8', errors='replace') as f:
        r=csv.DictReader(f)
        for row in r:
            yield {k:row.get(k) for k in KEEP}
out=[]
for row in rows(f'{ROOT}/goodware.csv'):
    row['label']=0; row['day']=None; out.append(row)
ng=len(out)
for p in sorted(glob.glob(f'{ROOT}/malware-by-day/*.csv')):
    day=os.path.basename(p)[:-4]
    try:
        for row in rows(p):
            row['label']=1; row['day']=day; out.append(row)
    except Exception as e:
        print('ERR',p,e)
print('goodware',ng,'malware',len(out)-ng)
json.dump(out, open(f'{ROOT}/prep/bmd_raw.json','w'))
