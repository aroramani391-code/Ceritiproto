"""Programs detected by every model at 1% validation FPR: the common set for a paired attack."""
from _root import ROOT
import sys, os, pickle, numpy as np
from cplib import OPT
import robust as RB
from data import load, splits

RES = f'{ROOT}/results'
MAIN_M = {'bmd': 16, 'clamp': 3}
MODELS = ['lgbm', 'lgbm-mono', 'rgat', 'gnncert', 'nngcn', 'twin', 'certiproto-i', 'certiproto-ie']
ds, N = sys.argv[1], int(sys.argv[2])
D = load(ds); graphs = D['graphs']
for i, g in enumerate(graphs): g._i = i
tr, va, te = splits(ds, D, 0)
gva = [graphs[i] for i in va]; gte = [graphs[i] for i in te]
yva = np.array([g.label for g in gva])
sets = []
for name in MODELS:
    M = MAIN_M[ds] if name in ('certiproto-ie', 'gnncert') else 1
    if name.startswith('lgbm'):
        sc = RB.FlatScorer(ds, name, 0, D)
    else:
        OPT['head'] = 'meanlin' if name.startswith('nngcn') else 'hybrid'; OPT['H'] = 32
        m, vmap = RB.load_graph_model(ds, name, 0, D)
        import analyze as AN
        kappa = AN.kappa_for(ds, name, M) if M > 1 else None
        sc = RB.GraphScorer(m, vmap, D['glob'] if name.startswith('twin') else None, M=M, kappa=kappa)
    sv = sc(gva); neg = np.sort(sv[yva == 0]); tau = neg[int(np.ceil(0.99 * len(neg))) - 1]
    st = sc(gte)
    d = {i for i, g in enumerate(gte) if g.label == 1 and st[i] > tau}
    print(name, 'detected', len(d), flush=True)
    sets.append(d)
common = sorted(set.intersection(*sets))
print('common', len(common))
pick = sorted(np.random.RandomState(1).choice(common, min(N, len(common)), replace=False).tolist())
pickle.dump(pick, open(f'{RES}/{ds}/common_pick.pkl', 'wb'))
print('saved', len(pick))
