"""Component records for ClaMP (integrated CSV) and MOTIF (EMBER-format raw features)."""
from _root import ROOT
import csv, json, pickle, collections, math, numpy as np

# ---------------- ClaMP ----------------
rows = [x for x in csv.reader(open(f'{ROOT}/data/ClaMP/dataset/ClaMP_Integrated-5184.csv')) if x]
H = rows[0]; rows = rows[1:]
G = {
 'DOS': ['e_cblp','e_cp','e_cparhdr','e_maxalloc','e_sp','e_lfanew'],
 'FILE': ['CreationYear'],
 'OPT': ['MajorLinkerVersion','MinorLinkerVersion','AddressOfEntryPoint','BaseOfCode','BaseOfData','ImageBase',
         'SectionAlignment','FileAlignment','MajorOperatingSystemVersion','MinorOperatingSystemVersion',
         'MajorImageVersion','MinorImageVersion','MajorSubsystemVersion','MinorSubsystemVersion','SizeOfHeaders',
         'CheckSum','Subsystem','SizeOfStackReserve','SizeOfStackCommit','SizeOfHeapReserve','SizeOfHeapCommit','LoaderFlags'],
 'SEC': ['packer','fileinfo'],
}
COUNTS = {'FILE': ['NumberOfSections'], 'OPT': ['SizeOfCode','SizeOfInitializedData','SizeOfUninitializedData','SizeOfImage'],
          'SEC': ['sus_sections','non_sus_sections','filesize']}
FLAGS = {'FILE': ['FH_char%d' % i for i in range(15)], 'OPT': ['OH_DLLchar%d' % i for i in range(11)]}
recs = []
for k, x in enumerate(rows):
    d = dict(zip(H, x))
    hdr = []
    for g, fs in G.items():
        for f in fs:
            v = d[f]
            if f == 'CheckSum': v = '0' if float(v) == 0 else 'nz'
            elif f == 'AddressOfEntryPoint': v = 'b%d' % int(math.log2(float(v) + 1))
            hdr.append((g, f, v))
    flags = [(g, f) for g, fs in FLAGS.items() for f in fs if d[f] == '1']
    counts = [(g, f, max(0.0, float(d[f]))) for g, fs in COUNTS.items() for f in fs]
    secs = [('SEC', '.text', float(d['E_text'])), ('SEC', '.data', float(d['E_data']))]
    sig = d['packer_type']
    recs.append(dict(id='clamp%05d' % k, label=int(d['class']), hdr=hdr, flags=flags, counts=counts, secs=secs,
                     sigs=[sig] if sig and sig != 'NoPacker' else [], glob={'E_file': float(d['E_file'])}))
print('ClaMP', len(recs), collections.Counter(r['label'] for r in recs))
pickle.dump(recs, open(f'{ROOT}/prep/clamp_recs.pkl', 'wb'))

# ---------------- MOTIF ----------------
PROPS = ['CNT_CODE','CNT_INITIALIZED_DATA','CNT_UNINITIALIZED_DATA','MEM_EXECUTE','MEM_READ','MEM_WRITE','MEM_SHARED',
         'MEM_DISCARDABLE','MEM_NOT_CACHED','MEM_NOT_PAGED','LNK_INFO','LNK_REMOVE']
mrecs = []
fam_name = {}
for line in open(f'{ROOT}/data/MOTIF/dataset/motif_dataset.jsonl'):
    r = json.loads(line)
    fam_name[r['label']] = r['reported_family']
    dlls = sorted({k.lower() for k in r['imports']})
    apis = sorted({(a.lower(), dlls.index(dl.lower())) for dl, al in r['imports'].items() for a in al})
    hdr = []
    coff = r['header']['coff']; opt = r['header']['optional']
    hdr.append(('ROOT', 'machine', coff['machine']))
    for f in ['subsystem','magic','major_image_version','minor_image_version','major_linker_version','minor_linker_version',
              'major_operating_system_version','minor_operating_system_version','major_subsystem_version',
              'minor_subsystem_version','sizeof_headers','sizeof_heap_commit']:
        hdr.append(('ROOT', f, str(opt.get(f))))
    hdr.append(('ROOT', 'entry', r['section']['entry'] or '<none>'))
    flags = [('ROOT', 'coff_' + c) for c in coff['characteristics']] + [('ROOT', 'dll_' + c) for c in opt['dll_characteristics']]
    gen = r['general']
    flags += [('ROOT', f) for f in ['has_debug','has_relocations','has_resources','has_signature','has_tls'] if gen[f]]
    counts = [('ROOT', f, float(gen[f])) for f in ['size','vsize','imports','exports','symbols']]
    counts.append(('ROOT', 'sizeof_code', float(opt.get('sizeof_code', 0))))
    counts.append(('ROOT', 'n_sections', float(len(r['section']['sections']))))
    secs = []
    for s in r['section']['sections']:
        props = [1.0 if p in s['props'] else 0.0 for p in PROPS]
        secs.append(('ROOT', s['name'] or '<noname>', [math.log1p(s['size']) / 20, math.log1p(s['vsize']) / 20, s['entropy'] / 8] + props))
    dds = [('ROOT', dd['name'], math.log1p(dd['size']) / 20) for dd in r.get('datadirectories', []) if dd['size'] > 0]
    exps = sorted({e.lower() for e in r['exports']})
    be = np.array(r['byteentropy'], dtype=np.float32); hi = np.array(r['histogram'], dtype=np.float32)
    st = r['strings']
    glob = np.concatenate([be / max(be.sum(), 1), hi / max(hi.sum(), 1),
                           np.array([math.log1p(st['numstrings']) / 10, st['avlength'] / 50, st['entropy'] / 8,
                                     math.log1p(st['paths']), math.log1p(st['urls']), math.log1p(st['registry']), math.log1p(st['MZ'])], dtype=np.float32)])
    mrecs.append(dict(id=r['sha256'], label=r['label'], family=r['reported_family'], appeared=r['appeared'],
                      dlls=dlls, apis=apis, hdr=hdr, flags=flags, counts=counts, secs=secs, dds=dds, exports=exps,
                      sigs=[], glob=glob.tolist()))
print('MOTIF', len(mrecs))
pickle.dump(mrecs, open(f'{ROOT}/prep/motif_recs.pkl', 'wb'))
json.dump({int(k): v for k, v in fam_name.items()}, open(f'{ROOT}/prep/motif_famnames.json', 'w'))
