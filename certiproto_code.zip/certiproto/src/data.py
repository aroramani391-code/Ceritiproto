"""Load records, build graphs and splits for the three datasets."""
from _root import ROOT
import pickle, os, collections, numpy as np, zlib
from cplib import TokenTable, build_graph

PREP = f'{ROOT}/prep'


def stable_u(s, salt=''):
    return (zlib.crc32((salt + s).encode()) % 100000) / 100000.0


def load(ds):
    cache = f'{PREP}/{ds}_graphs2.pkl'
    if os.path.exists(cache):
        return pickle.load(open(cache, 'rb'))
    recs = pickle.load(open(f'{PREP}/{ds}_recs.pkl', 'rb'))
    tt = TokenTable()
    graphs = [build_graph(r, tt, ds) for r in recs]
    for G, r in zip(graphs, recs):
        G.meta = {k: r[k] for k in ('time', 'family', 'appeared') if k in r}
    glob = None
    if ds == 'bmd':
        glob = np.array([[r['glob']['Entropy'] / 8.0] for r in recs], np.float32)
    elif ds == 'clamp':
        glob = np.array([[r['glob']['E_file'] / 8.0] for r in recs], np.float32)
    else:
        glob = np.array([r['glob'] for r in recs], np.float32)
    out = dict(graphs=graphs, tt=tt, glob=glob)
    del recs
    pickle.dump(out, open(cache, 'wb'))
    return out


def splits(ds, D, seed):
    """Return index arrays (train, val, test)."""
    graphs = D['graphs']
    n = len(graphs)
    y = np.array([G.label for G in graphs])
    if ds == 'bmd':
        t = np.array([G.meta['time'] for G in graphs])
        past = np.nonzero(t < '2015-01-01')[0]
        fut = np.nonzero(t >= '2015-01-01')[0]
        u = np.array([stable_u(graphs[i].gid, 'val') for i in past])
        return past[u >= 0.15], past[u < 0.15], fut
    rng = np.random.RandomState(1000 + seed)
    if ds == 'clamp':
        tr, va, te = [], [], []
        for c in (0, 1):
            idx = np.nonzero(y == c)[0]; rng.shuffle(idx)
            a, b = int(0.70 * len(idx)), int(0.85 * len(idx))
            tr += list(idx[:a]); va += list(idx[a:b]); te += list(idx[b:])
        return np.array(tr), np.array(va), np.array(te)
    # motif: drop singleton families, 5-fold stratified CV, fold = seed
    cnt = collections.Counter(y)
    keep = np.array([i for i in range(n) if cnt[y[i]] > 1])
    from sklearn.model_selection import StratifiedKFold
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
    folds = list(skf.split(keep, y[keep]))
    trk, tek = folds[seed]
    tr, te = keep[trk], keep[tek]
    # validation: 10% of the training fold (families with >=3 training samples contribute)
    r2 = np.random.RandomState(7 + seed)
    va = []
    byc = collections.defaultdict(list)
    for i in tr: byc[y[i]].append(i)
    for c, idx in byc.items():
        r2.shuffle(idx)
        k = int(round(0.1 * len(idx))) if len(idx) >= 3 else 0
        va += idx[:k]
    va = np.array(sorted(va)); tr = np.array(sorted(set(tr) - set(va)))
    return tr, va, te


def motif_label_map(D):
    y = np.array([G.label for G in D['graphs']])
    cnt = collections.Counter(y)
    fams = sorted(c for c in cnt if cnt[c] > 1)
    return {c: i for i, c in enumerate(fams)}
