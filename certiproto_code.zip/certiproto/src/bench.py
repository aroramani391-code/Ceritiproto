import torch, numpy as np, time
from cplib import *
from data import load, splits
D = load('bmd'); tt = D['tt']; G = D['graphs']
tr, va, te = splits('bmd', D, 0)
vmap, V = build_vocab([G[i] for i in tr[:3000]], tt)
for d, bs in [(64, 64), (64, 128), (48, 128)]:
    m = CertiProto(V, tt.ngrams(), d=d, K=32); opt = torch.optim.Adam(m.parameters(), 1e-3)
    gs = [G[i] for i in tr[:1280]]
    t = time.time()
    for k in range(0, 1280, bs):
        b = collate(gs[k:k+bs]); y = torch.tensor([g.label for g in gs[k:k+bs]], dtype=torch.float)
        lo, _ = m(b, vmap); loss = F.binary_cross_entropy_with_logits(lo, y); opt.zero_grad(); loss.backward(); opt.step()
    print(d, bs, 'sec/1000 graphs', (time.time() - t) / 1.28)
