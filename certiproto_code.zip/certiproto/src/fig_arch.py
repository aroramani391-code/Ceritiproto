from _root import ROOT
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, RegularPolygon, Rectangle
plt.rcParams.update({'font.family': 'Liberation Serif', 'font.size': 7.6, 'svg.fonttype': 'path', 'mathtext.fontset': 'stix'})
W, H = 7.0, 3.05
fig = plt.figure(figsize=(W, H))
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, W); ax.set_ylim(0, H); ax.axis('off')
LW = 0.8
TOP, BOT = 2.97, 0.08

def frame(x, y, w, h, ls='-', lw=LW, z=1):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.0,rounding_size=0.05', fc='white', ec='black', lw=lw, ls=ls, zorder=z))

def title(x, y, s):
    ax.text(x, y, s, ha='center', va='top', fontsize=7.8, fontweight='bold', zorder=5, linespacing=1.1)

def body(x, y, s, fs=6.9, va='top', ha='center'):
    ax.text(x, y, s, ha=ha, va=va, fontsize=fs, zorder=5, linespacing=1.3)

def arrow(x0, y0, x1, y1):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle='-|>', mutation_scale=7, lw=LW, color='black', zorder=6, shrinkA=0, shrinkB=0))

# (a) input metadata
frame(0.06, 2.12, 1.36, TOP - 2.12)
title(0.74, TOP - 0.06, '(a) PE file metadata')
body(0.74, 2.42, 'header fields, flags\nimport table (DLL → API)\nsections, signatures, sizes', va='center')
arrow(0.74, 2.12, 0.74, 1.96)
# (b) component graph
frame(0.06, BOT, 1.36, 1.88)
title(0.74, 1.90, '(b) Component graph')
def node(x, y, kind):
    kw = dict(fc='white', ec='black', zorder=7)
    if kind == 'root': ax.add_patch(Circle((x, y), 0.07, lw=1.1, **kw))
    elif kind == 'hub': ax.add_patch(Rectangle((x - 0.06, y - 0.06), 0.12, 0.12, lw=0.9, **kw))
    elif kind == 'api': ax.add_patch(Circle((x, y), 0.042, lw=0.8, **kw))
    elif kind == 'hdr': ax.add_patch(RegularPolygon((x, y), 4, radius=0.058, lw=0.8, **kw))
    elif kind == 'cnt': ax.add_patch(RegularPolygon((x, y), 3, radius=0.062, lw=0.8, **kw))
def edge(a, b): ax.plot([a[0], b[0]], [a[1], b[1]], color='black', lw=0.6, zorder=6)
root = (0.74, 1.55); h1 = (0.38, 1.22); h2 = (0.74, 1.22)
L1 = [(0.20, 0.93), (0.38, 0.93), (0.56, 0.93)]; L2 = [(0.70, 0.93), (0.86, 0.93)]
hd = [(1.04, 1.22), (1.24, 1.22)]; ct = (1.14, 0.93)
for h in (h1, h2): edge(root, h)
for l in L1: edge(h1, l)
for l in L2: edge(h2, l)
for l in hd: edge(root, l)
edge(root, ct)
node(*root, 'root'); node(*h1, 'hub'); node(*h2, 'hub')
for l in L1 + L2: node(*l, 'api')
for l in hd: node(*l, 'hdr')
node(*ct, 'cnt')
leg = [('root', 'root', 0.18, 0.62), ('hub', 'DLL hub', 0.18, 0.43), ('api', 'API leaf', 0.18, 0.24),
       ('hdr', 'header / flag', 0.76, 0.62), ('cnt', 'size count', 0.76, 0.43)]
for k, lab, x, y in leg:
    node(x, y, k); ax.text(x + 0.11, y, lab, va='center', fontsize=6.7, zorder=8)
arrow(1.42, 1.05, 1.58, 1.05)
# (c) partition
frame(1.58, BOT, 1.25, TOP - BOT)
title(2.205, TOP - 0.06, '(c) Content-hash\npartition')
body(2.205, TOP - 0.45, r'$g(v)=\mathrm{hash}(o_v)\ \mathrm{mod}\ M$' + '\nroot replicated in all groups;\nhub kept where its leaves fall', fs=6.7)
for lab, y in [(r'$G_1$ subgraph', 1.70), (r'$G_2$ subgraph', 1.27), (r'$G_M$ subgraph', 0.45)]:
    frame(1.80, y - 0.16, 0.81, 0.32, z=3); body(2.205, y, lab, va='center', fs=7.0)
body(2.205, 0.86, r'$\vdots$', va='center', fs=10)
arrow(2.83, 1.40, 3.00, 1.40)
# (d) shared monotone model
frame(3.00, BOT, 2.22, TOP - BOT, ls=(0, (4, 2)), lw=0.9, z=0)
title(4.11, TOP - 0.06, '(d) Shared monotone model')
body(4.11, TOP - 0.24, '(Theorem 1 holds inside the dashed box)', fs=6.6)
frame(3.12, 1.95, 1.98, 0.62, z=3)
body(4.11, 2.26, 'Node encoder ' + r'$\mathrm{Enc}_{\tau(v)}$' + ' (own attributes only)\nword + char n-gram embedding, OOV-free\ncount path: slope ' + r'$\alpha_f\geq 0$' + ' on ' + r'$\log(1+x)$', fs=6.7, va='center')
arrow(4.11, 1.95, 4.11, 1.80)
frame(3.12, 1.08, 1.98, 0.72, z=3)
body(4.11, 1.44, 'MHMP layer ' + r'$\times L$' + ': ' + r'$W_s,W_\rho,W_\downarrow\geq 0$' + '\nmax within (relation, channel),\nsum across channels; monotone\nbatch-norm (gain ' + r'$\geq 0$' + '); ReLU', fs=6.7, va='center')
arrow(4.11, 1.08, 4.11, 0.93)
frame(3.12, 0.17, 1.98, 0.76, z=3)
body(4.11, 0.55, 'Prototype MIL head\n' + r'$s_k(z)=\Sigma_i\, q_{k,i}\,\min(z_i,p_{k,i})$' + '\n' + r'$c_k=\mathrm{max}_v\, s_k(z_v)\,/\,\Sigma_i q_{k,i}p_{k,i}$' + '\n' + r'$S=b_0+\Sigma_k\, w_k c_k$' + ' (+ axis prototypes)\n' + r'$p,q,w,\beta\geq 0$', fs=6.7, va='center')
arrow(5.22, 2.55, 5.40, 2.55)
# (e)(f)(g)
frame(5.40, 2.12, 1.55, TOP - 2.12)
title(6.175, TOP - 0.06, '(e) Quorum vote')
body(6.175, 2.40, 'vote ' + r'$=\mathbb{1}[S(G_j)>t]$' + '\n' + r'$V_{mal}=\Sigma_j\,$' + 'votes, ' + r'$j=1,\ldots,M$', fs=6.8, va='center')
arrow(6.175, 2.12, 6.175, 1.97)
frame(5.40, 1.12, 1.55, 0.85)
title(6.175, 1.91, '(f) Verdict + certificate')
body(6.175, 1.45, 'malicious if ' + r'$V_{mal}\geq\kappa$' + ' (quorum)\nedit radius under unlimited\ninsertion: ' + r'$r^{*}=V_{mal}-\kappa$', fs=6.7, va='center')
arrow(6.175, 1.12, 6.175, 0.97)
frame(5.40, BOT, 1.55, 0.89)
title(6.175, 0.91, '(g) Explanation')
body(6.175, 0.42, 'witness nodes of the winning\nprototypes: real imports,\nsections and header fields', fs=6.7, va='center')
for ext, dpi in (('svg', None), ('png', 600)):
    fig.savefig(f'{ROOT}/figs/fig1_arch.{ext}', dpi=dpi, facecolor='white')
fig.savefig(f'{ROOT}/figs/fig1_arch_preview.png', dpi=170, facecolor='white')
