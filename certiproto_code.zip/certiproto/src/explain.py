"""Explanation analysis: witness attribution, sufficiency/deletion tests, prototype audit and qualitative examples."""
from _root import ROOT
import sys, os, pickle, collections, numpy as np, torch
from cplib import *
from cplib import OPT
import robust as RB
import train as T
from data import load, splits, motif_label_map


def node_attrib(model, g, vmap, glob=None, cls=None):
    """Gradient x input on the initial node states. For CertiProto the gradient only flows along
    max-selected paths, so the attribution concentrates on witness components."""
    model.eval()
    b = collate([g])
    b['ch'] = model.enc.tb[b['tidx']]
    z0 = model.enc(b, vmap).detach().requires_grad_(True)
    z = z0
    if isinstance(model, CertiProto):
        for l in model.layers: z = l(z, b)
        logits, cov, hs = model.head(z, b['gidx'], b['nvirt'])
        if OPT['head'] == 'hybrid':
            logits = logits + graph_max(z, b['gidx'], b['nvirt']) @ posw(model.ulin)
    else:
        for l, layer in enumerate(model.layers):
            z = model.norms[l](model.gat_layer(l, z, b) if model.kind == 'gat' else layer(z, b))
        gi, nv = b['gidx'], b['nvirt']
        if model.kind in ('mean', 'gat'):
            h = scatter_mean(z, gi, nv)
        else:
            h = torch.cat([scatter_max(z, gi, nv), scatter_mean(z, gi, nv)], 1)
            if model.nglob: h = torch.cat([h, torch.tensor(glob[None, :])], 1)
        logits = model.mlp(h)
    s = logits.reshape(-1)[0] if cls is None else logits.reshape(-1)[cls]
    s.backward()
    a = (z0.grad * z0).sum(1).detach().numpy()
    a[g.ntype == NT['ROOT']] = -np.inf  # rank leaf components only (root and hubs are structural)
    a[g.ntype == NT['HUB']] = -np.inf
    return a, s.item()


def keep_only(g, idx_keep):
    """Sub-program with the kept components (their hubs and the root are kept as well)."""
    keep = np.zeros(len(g.ntype), bool); keep[0] = True
    for i in idx_keep:
        keep[i] = True
        p = g.parent[i]
        if p > 0: keep[p] = True
    rem = [i for i in range(len(g.ntype) - 1, 0, -1) if not keep[i]]
    h = g
    for i in rem:
        h = RB.remove_node(h, i)
    return h


def remove_set(g, idx):
    h = g
    for i in sorted(idx, reverse=True):
        h = RB.remove_node(h, i)
    return h


def faithfulness(ds, name, n=300, ks=(1, 3, 5, 10)):
    D = load(ds); graphs = D['graphs']
    for i, g in enumerate(graphs): g._i = i
    tr, va, te = splits(ds, D, 0)
    OPT['head'] = 'hybrid'; OPT['H'] = 32
    m, vmap = RB.load_graph_model(ds, name, 0, D)
    glob = D['glob'] if name.startswith('twin') else None
    scorer = RB.GraphScorer(m, vmap, glob)
    gva = [graphs[i] for i in va]; gte = [graphs[i] for i in te]
    yva = np.array([g.label for g in gva]); sv = scorer(gva)
    neg = np.sort(sv[yva == 0]); tau = neg[int(np.ceil(0.99 * len(neg))) - 1]
    st = scorer(gte)
    det = [i for i, g in enumerate(gte) if g.label == 1 and st[i] > tau]
    rng = np.random.RandomState(0)
    pick = rng.choice(det, min(n, len(det)), replace=False)
    out = {k: dict(suff_w=[], suff_r=[], del_w=[], del_r=[]) for k in ks}
    nleaves = []
    for i in pick:
        g = gte[i]
        a, s = node_attrib(m, g, vmap, glob[g._i] if glob is not None else None)
        order = [int(j) for j in np.argsort(-a) if np.isfinite(a[j])]
        nleaves.append(len(order))
        for k in ks:
            top = order[:k]
            rnd = list(rng.choice(order, min(k, len(order)), replace=False))
            sk, sr = scorer([keep_only(g, top), keep_only(g, rnd)])
            dk, dr = scorer([remove_set(g, top), remove_set(g, rnd)])
            out[k]['suff_w'].append(sk > tau); out[k]['suff_r'].append(sr > tau)
            out[k]['del_w'].append(dk <= tau); out[k]['del_r'].append(dr <= tau)
    res = {k: {kk: float(np.mean(v)) for kk, v in d.items()} for k, d in out.items()}
    res['n'] = len(pick); res['median_nodes'] = float(np.median(nleaves))
    return res


def witnesses(ds, name, gids, top=6):
    """Top witness components (tokens) of selected programs."""
    D = load(ds); graphs = D['graphs']; tt = D['tt']
    for i, g in enumerate(graphs): g._i = i
    OPT['head'] = 'hybrid'; OPT['H'] = 32
    m, vmap = RB.load_graph_model(ds, name, 0, D)
    out = []
    for gi in gids:
        g = graphs[gi]
        cls = None
        if getattr(m, 'C', 1) > 1:
            with torch.no_grad():
                lo, _ = m(collate([g]), vmap)
            cls = int(lo.reshape(-1).argmax())
        a, s = node_attrib(m, g, vmap, cls=cls)
        order = [int(j) for j in np.argsort(-a) if np.isfinite(a[j])][:top]
        toks = []
        for j in order:
            t = tt.toks[g.tidx[j]]; p = g.parent[j]
            toks.append((t, tt.toks[g.tidx[p]] if p > 0 else None, float(a[j])))
        out.append((g.gid, s, toks))
    return out


if __name__ == '__main__':
    ds = sys.argv[1]; names = sys.argv[2].split(',')
    os.makedirs(f'{ROOT}/results/{ds}/explain', exist_ok=True)
    for nm in names:
        p = f'{ROOT}/results/{ds}/explain/{nm}.pkl'
        if os.path.exists(p): continue
        r = faithfulness(ds, nm)
        print(ds, nm, r, flush=True)
        pickle.dump(r, open(p, 'wb'))


def motif_audit(name='certiproto-i'):
    """Prototype audit on MOTIF fold 0: source families of projected prototypes and their purity on test programs."""
    import pickle as pk
    D = load('motif'); graphs = D['graphs']; tt = D['tt']
    lmap = motif_label_map(D)
    tr, va, te = splits('motif', D, 0)  # split on the original labels, as in training
    fam_of_gid = {}
    for i, g in enumerate(graphs):
        g._i = i
        if not hasattr(g, '_orig'): g._orig = g.label
        g.label = lmap.get(g._orig, -1)
        fam_of_gid[g.gid] = g.label
    res = pk.load(open(f'{ROOT}/results/motif/{name}_0.pkl', 'rb'))
    src = res['proto_src']
    OPT['head'] = 'hybrid'; OPT['H'] = 32
    m, vmap = RB.load_graph_model('motif', name, 0, D)
    W = posw(m.head.Wout).detach().numpy()  # [K, C]
    gte = [graphs[i] for i in te]
    hits, tot = 0, 0
    with torch.no_grad():
        for k0 in range(0, len(gte), 64):
            sub = gte[k0:k0 + 64]
            b = collate(sub)
            lo, aux = m(b, vmap)
            cov = aux['cov'].numpy()
            pred = lo.argmax(1).numpy()
            for j, g in enumerate(sub):
                if pred[j] != g.label: continue
                contrib = cov[j] * W[:, pred[j]]
                kbest = int(np.argmax(contrib))
                if src[kbest] is None: continue
                tot += 1; hits += int(fam_of_gid.get(src[kbest][0], -2) == g.label)
    fams = {fam_of_gid.get(s[0]) for s in src if s is not None}
    kinds = collections.Counter((s[2].split(':')[0] if s else 'none') for s in src)
    return dict(purity=hits / max(tot, 1), n=tot, distinct_source_families=len(fams), K=len(src), kinds=dict(kinds))
