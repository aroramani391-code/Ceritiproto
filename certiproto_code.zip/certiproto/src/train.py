"""Train and evaluate CertiProto variants and graph baselines; saves predictions per run."""
from _root import ROOT
import sys, os, time, pickle, math, random, argparse, copy
import numpy as np, torch, torch.nn.functional as F
from sklearn.metrics import roc_auc_score, accuracy_score, f1_score
from cplib import *
from cplib import OPT
from data import load, splits, motif_label_map
from collate_fast import collate_fast

OUT = os.environ.get('RES_OUT', f'{ROOT}/results')

CFG = {
    'bmd': dict(epoch_size=8000, max_epochs=14, patience=4, bs=64, lr=2e-3, d=64, K=32, M_list=[8, 16, 32]),
    'clamp': dict(epoch_size=None, max_epochs=30, patience=6, bs=64, lr=2e-3, d=64, K=32, M_list=[2, 3, 4]),
    'motif': dict(epoch_size=None, max_epochs=60, patience=10, bs=32, lr=3e-3, d=64, K=64),
}
EVAL_M = [8, 16, 32]


def make_model(name, V, ngt, cfg, C, nglob):
    d, K = cfg['d'], cfg['K']
    if name.startswith('nngcn'):
        return CertiProto(V, ngt, d=d, K=K, C=C, mono=True, agg='mean', sim='coverage')
    if name.startswith('certiproto'):
        kw = dict(mono=True, agg='max', sim='coverage')
        if 'cosine' in name: kw['sim'] = 'cosine'
        if 'meanagg' in name: kw['agg'] = 'mean'
        if 'K' in name.split('-')[-1] and name.split('-')[-1][1:].isdigit():
            K = int(name.split('-')[-1][1:])
        m = CertiProto(V, ngt, d=d, K=K, C=C, **kw)
        if 'nongram' in name: m.enc.use_ngram = False
        if '-relax' in name:
            # identical model at initialisation, with the sign constraints removed: map every
            # parameter that was read through softplus onto the value that softplus produced.
            with torch.no_grad():
                m.head.Q.copy_(F.softplus(m.head.Q))
                m.enc.cnt_a.weight.copy_(F.softplus(m.enc.cnt_a.weight))
                for mod in m.modules():
                    if isinstance(mod, TypeBN):
                        mod.g.copy_(F.softplus(mod.g))
        return m
    kind = {'rgat': 'gat', 'gnncert': 'gat', 'twin': 'twin', 'rgcn': 'mean'}[name.split('-')[0]]
    return GNNBase(V, ngt, d=d, C=C, kind=kind, nglob=nglob if kind == 'twin' else 0)


def is_partition_trained(name):
    return name.startswith('certiproto-ie') or name.startswith('gnncert')


def forward(model, gs, vmap, glob_all, M=1, groups=None):
    b = collate_fast(gs, M, groups) if M > 1 else collate(gs)
    glob = None
    if glob_all is not None:
        gl = torch.tensor(np.stack([glob_all[g._i] for g in gs]))
        glob = gl.repeat_interleave(M if groups is None else 1, 0) if M > 1 else gl
    return model(b, vmap, glob)


def predict(model, gs, vmap, glob_all, M=1, bs=128):
    model.eval(); outs = []
    with torch.no_grad():
        for k in range(0, len(gs), bs):
            lo, _ = forward(model, gs[k:k + bs], vmap, glob_all, M)
            if M > 1:
                lo = lo.view(len(gs[k:k + bs]), M, *lo.shape[1:])
            outs.append(lo.double())
    return torch.cat(outs).numpy()


def mil_contrastive(cov, y, T=0.1):
    m = cov.max(1).values
    pos_, neg = m[y == 1], m[y == 0]
    if len(pos_) == 0 or len(neg) == 0:
        return torch.zeros(())
    neg_lse = torch.logsumexp(neg / T, 0)
    return (-(pos_ / T) + torch.logaddexp(pos_ / T, neg_lse.expand_as(pos_))).mean()


def diversity(P):
    Pn = F.normalize(P + 1e-6, dim=1); S = Pn @ Pn.t()
    K = len(P)
    return F.relu(S - torch.eye(K)).sum() / (K * (K - 1))


@torch.no_grad()
def project_prototypes(model, gs, vmap, glob_all, tt, mal_only=True, max_graphs=1500):
    model.eval()
    cand = [g for g in gs if (g.label == 1 or not mal_only)][:max_graphs]
    P = model.head.protos()
    best = torch.full((len(P),), float('inf')); src = [None] * len(P); newP = P.clone()
    for k in range(0, len(cand), 128):
        sub = cand[k:k + 128]
        b = collate(sub)
        z = model.node_states(b, vmap)
        dist = torch.cdist(P, z)  # [K, N]
        dmin, arg = dist.min(1)
        for j in torch.nonzero(dmin < best).squeeze(1).tolist():
            best[j] = dmin[j]; v = arg[j].item(); newP[j] = z[v]
            gi = b['gidx'][v].item(); g = sub[gi]
            local = v - (b['gidx'] < gi).sum().item()
            par = g.parent[local]
            src[j] = (g.gid, int(local), tt.toks[g.tidx[local]], tt.toks[g.tidx[par]] if par >= 0 else None)
    model.head.P.data.copy_(newP)
    model.head.proto_src = src


@torch.no_grad()
def init_head(model, gtr, vmap, glob_all, C, n=256):
    """Data-driven initialisation: prototypes start at real node states, bias centres the logits."""
    rng = np.random.RandomState(0)
    pool = [g for g in gtr if (C > 1 or g.label == 1)]
    sub = [pool[i] for i in rng.choice(len(pool), min(n, len(pool)), replace=False)]
    b = collate(sub); z = model.node_states(b, vmap)
    leaf = (b['ntype'] >= 2).nonzero().squeeze(1)
    pick = leaf[torch.from_numpy(rng.choice(len(leaf), model.head.K, replace=len(leaf) < model.head.K))]
    model.head.P.data.copy_(z[pick])
    allg = [gtr[i] for i in rng.choice(len(gtr), min(n, len(gtr)), replace=False)]
    lo, _ = model(collate(allg), vmap)
    if C == 1:
        model.head.bias.data.fill_(-lo.median().item())
    else:
        model.head.bias.data -= lo.mean(0)


def evaluate(model, gs, vmap, glob_all, C, partition):
    lo = predict(model, gs, vmap, glob_all)
    y = np.array([g.label for g in gs])
    if C == 1:
        auc = roc_auc_score(y, lo)
        if partition:
            # quick check on random single groups as well
            rng = np.random.RandomState(0)
            M = EVAL_M[1]; grp = rng.randint(0, M, len(gs))
            outs = []
            model.eval()
            with torch.no_grad():
                for k in range(0, len(gs), 128):
                    o, _ = forward(model, gs[k:k + 128], vmap, glob_all, M, list(grp[k:k + 128]))
                    outs.append(o.numpy())
            auc = 0.5 * auc + 0.5 * roc_auc_score(y, np.concatenate(outs))
        loss = F.binary_cross_entropy_with_logits(torch.tensor(lo), torch.tensor(y, dtype=torch.double)).item()
        return dict(auc=auc, loss=loss, acc=accuracy_score(y, lo > 0)), lo
    pred = lo.argmax(1)
    loss = F.cross_entropy(torch.tensor(lo), torch.tensor(y)).item()
    return dict(acc=accuracy_score(y, pred), f1=f1_score(y, pred, average='macro'), loss=loss, auc=accuracy_score(y, pred)), lo


def run(ds, name, seed, extra_epochs_head=2):
    t0 = time.time()
    cfg = dict(CFG[ds])
    for k, cast in (('epoch_size', int), ('max_epochs', int), ('patience', int), ('lr', float), ('d', int), ('K', int)):
        v = os.environ.get('CFG_' + k.upper())
        if v:
            cfg[k] = cast(v)
    global EVAL_M
    EVAL_M = cfg.get('M_list', [8, 16, 32])
    D = load(ds); tt = D['tt']; graphs = D['graphs']
    for i, g in enumerate(graphs): g._i = i
    tr, va, te = splits(ds, D, seed)
    C = 1
    if ds == 'motif':
        lmap = motif_label_map(D)
        for g in graphs:
            if not hasattr(g, '_orig'): g._orig = g.label
            g.label = lmap.get(g._orig, -1)
        C = len(lmap)
    glob_all = D['glob'] if name.startswith('twin') else None
    torch.manual_seed(seed); np.random.seed(seed); random.seed(seed)
    gtr = [graphs[i] for i in tr]; gva = [graphs[i] for i in va]; gte = [graphs[i] for i in te]
    vmap, V = build_vocab(gtr, tt)
    OPT['relax'] = '-relax' in name
    if '-protoonly' in name: OPT['head'] = 'proto'
    if name.startswith('nngcn'): OPT['head'] = 'meanlin'
    if '-H1' in name: OPT['H'] = 1
    model = make_model(name, V, tt.ngrams(), cfg, C, D['glob'].shape[1])
    model.enc.tb.copy_(torch.from_numpy(tt.buckets(OPT['H'])))
    is_cp = name.startswith('certiproto')
    if is_cp:
        init_head(model, gtr, vmap, glob_all, C)
    opt = torch.optim.Adam(model.parameters(), lr=cfg['lr'])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=cfg['max_epochs'], eta_min=cfg['lr'] * 0.05)
    lam_mil = 0.0 if 'nomil' in name else (0.2 if is_cp and C == 1 else 0.0)
    lam_div = 0.01 if is_cp else 0.0
    part = is_partition_trained(name)
    hist = []
    best, best_state, bad = -1, None, 0
    ytr = np.array([g.label for g in gtr])
    for ep in range(cfg['max_epochs']):
        model.train()
        order = np.random.permutation(len(gtr))
        if cfg['epoch_size']:
            order = order[:cfg['epoch_size']]
        tl, tn, tc = 0.0, 0, 0
        for k in range(0, len(order), cfg['bs']):
            gs = [gtr[i] for i in order[k:k + cfg['bs']]]
            y = torch.tensor([g.label for g in gs])
            lo, aux = forward(model, gs, vmap, glob_all)
            if C == 1:
                loss = F.binary_cross_entropy_with_logits(lo, y.float())
                tc += int(((lo > 0).long() == y).sum())
            else:
                loss = F.cross_entropy(lo, y)
                tc += int((lo.argmax(1) == y).sum())
            if lam_mil:
                loss = loss + lam_mil * mil_contrastive(aux['cov'], y)
            if lam_div:
                loss = loss + lam_div * diversity(model.head.protos())
            if part:
                M = random.choice(EVAL_M)
                grp = list(np.random.randint(0, M, len(gs)))
                lo2, _ = forward(model, gs, vmap, glob_all, M, grp)
                loss = loss + (F.binary_cross_entropy_with_logits(lo2, y.float()) if C == 1 else F.cross_entropy(lo2, y))
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            tl += loss.item() * len(gs); tn += len(gs)
        sched.step()
        if is_cp and (ep + 1) % 5 == 0:
            project_prototypes(model, gtr, vmap, glob_all, tt, mal_only=(C == 1))
        ev, _ = evaluate(model, gva, vmap, glob_all, C, part)
        hist.append(dict(epoch=ep + 1, train_loss=tl / tn, train_acc=tc / tn, val_loss=ev['loss'], val_auc=ev['auc'], val_acc=ev['acc']))
        print(ds, name, seed, hist[-1], f'{time.time() - t0:.0f}s', flush=True)
        if ev['auc'] > best + 1e-5:
            best, bad = ev['auc'], 0; best_state = copy.deepcopy(model.state_dict())
        else:
            bad += 1
            if bad >= cfg['patience']:
                break
    model.load_state_dict(best_state)
    if is_cp:
        # final projection onto real training components, then head-only fine-tuning
        project_prototypes(model, gtr, vmap, glob_all, tt, mal_only=(C == 1))
        proj_state = copy.deepcopy(model.state_dict())
        proj_auc = evaluate(model, gva, vmap, glob_all, C, part)[0]['auc']
        head_params = [model.head.Wout, model.head.bias, model.head.Q]
        hopt = torch.optim.Adam(head_params, lr=cfg['lr'])
        for p in model.parameters(): p.requires_grad_(False)
        for p in head_params: p.requires_grad_(True)
        for ep in range(extra_epochs_head):
            model.train()
            order = np.random.permutation(len(gtr))[: (cfg['epoch_size'] or len(gtr))]
            for k in range(0, len(order), cfg['bs']):
                gs = [gtr[i] for i in order[k:k + cfg['bs']]]
                y = torch.tensor([g.label for g in gs])
                lo, aux = forward(model, gs, vmap, glob_all)
                loss = F.binary_cross_entropy_with_logits(lo, y.float()) if C == 1 else F.cross_entropy(lo, y)
                if part:
                    M = random.choice(EVAL_M); grp = list(np.random.randint(0, M, len(gs)))
                    lo2, _ = forward(model, gs, vmap, glob_all, M, grp)
                    loss = loss + (F.binary_cross_entropy_with_logits(lo2, y.float()) if C == 1 else F.cross_entropy(lo2, y))
                hopt.zero_grad(); loss.backward(); hopt.step()
        for p in model.parameters(): p.requires_grad_(True)
        # The '-relax' ablation keeps the fine-tuned head only if it does not hurt validation:
        # head-only fine-tuning diverges once the sign constraints are removed. The projection onto
        # real components is always kept, since the explanations depend on it.
        ev_ft, _ = evaluate(model, gva, vmap, glob_all, C, part)
        if '-relax' in name and ev_ft['auc'] < proj_auc - 1e-4:
            model.load_state_dict(proj_state)
            print(ds, name, seed, f'head fine-tune rejected ({ev_ft["auc"]:.4f} < {proj_auc:.4f})', flush=True)
    res = dict(ds=ds, name=name, seed=seed, hist=hist, tr=tr, va=va, te=te, cfg=cfg, train_time=time.time() - t0)
    t1 = time.time()
    res['val'] = predict(model, gva, vmap, glob_all)
    res['test'] = predict(model, gte, vmap, glob_all)
    res['infer_ms'] = (time.time() - t1) / (len(gva) + len(gte)) * 1000
    res['yval'] = np.array([g.label for g in gva]); res['ytest'] = np.array([g.label for g in gte])
    if C == 1 and (part or (name.startswith('certiproto') and seed == 0)):
        for M in EVAL_M:
            res[f'test_M{M}'] = predict(model, gte, vmap, glob_all, M)
    if is_cp:
        res['proto_src'] = model.head.proto_src
    os.makedirs(f'{OUT}/{ds}', exist_ok=True)
    pickle.dump(res, open(f'{OUT}/{ds}/{name}_{seed}.pkl', 'wb'))
    torch.save(dict(state=model.state_dict(), vmap=vmap, V=V, name=name, C=C), f'{OUT}/{ds}/{name}_{seed}.pt')
    ev = evaluate(model, gte, vmap, glob_all, C, False)[0]
    print('DONE', ds, name, seed, 'test', ev, f'{time.time() - t0:.0f}s', flush=True)
    return res


if __name__ == '__main__':
    ds, name = sys.argv[1], sys.argv[2]
    seeds = [int(s) for s in sys.argv[3].split(',')] if len(sys.argv) > 3 else [0, 1, 2, 3, 4]
    for s in seeds:
        if os.path.exists(f'{OUT}/{ds}/{name}_{s}.pkl'):
            print('skip', ds, name, s); continue
        run(ds, name, s)
