"""Aggregate saved predictions into metrics, ROC data, confusion matrices and significance tests."""
from _root import ROOT
import os, glob, pickle, json, numpy as np, collections
from sklearn.metrics import roc_auc_score, roc_curve, accuracy_score, f1_score, precision_score, recall_score, confusion_matrix
from scipy.stats import ttest_rel, binomtest

RES = f'{ROOT}/results'


import json as _json, os as _os
_KAPPA = f'{ROOT}/results/kappa.json'


def kappa_for(ds, name, M):
    if _os.path.exists(_KAPPA):
        K = _json.load(open(_KAPPA))
        k = K.get(f'{ds}|{name}|{M}')
        if k: return int(k)
    return M // 2 + 1


def vote_score(gl, M, kappa=None):
    k = kappa or (M // 2 + 1)
    return np.sort(gl, axis=-1)[..., ::-1][..., k - 1]


def tpr_at(y, s, fpr_t):
    fpr, tpr, thr = roc_curve(y, s)
    i = np.searchsorted(fpr, fpr_t, side='right') - 1
    return tpr[max(i, 0)], thr[max(i, 0)]


def load_runs(ds, name):
    out = []
    for s in range(5):
        p = f'{RES}/{ds}/{name}_{s}.pkl'
        if os.path.exists(p):
            out.append(pickle.load(open(p, 'rb')))
    return out


def scores_of(r, M=1, split='test'):
    if M == 1:
        return r[split]
    return vote_score(r[f'{split}_M{M}'], M, kappa_for(r['ds'], r['name'], M))


def binary_metrics(y, s, thr=0.0):
    pred = (s > thr).astype(int)
    return dict(acc=accuracy_score(y, pred), prec=precision_score(y, pred, zero_division=0), rec=recall_score(y, pred),
                f1=f1_score(y, pred), auc=roc_auc_score(y, s), tpr1=tpr_at(y, s, 0.01)[0], tpr01=tpr_at(y, s, 0.001)[0])


def summarize(ds, name, M=1):
    runs = load_runs(ds, name)
    if not runs:
        return None
    ms = []
    for r in runs:
        if M > 1 and f'test_M{M}' not in r:
            return None
        thr = r.get('thr_main', 0.0) if M > 1 else r.get('thr', 0.0)
        ms.append(binary_metrics(r['ytest'], scores_of(r, M), thr))
    keys = ms[0].keys()
    return {k: (np.mean([m[k] for m in ms]), np.std([m[k] for m in ms])) for k in keys} | {'n': len(ms), 'per_seed': ms}


def family_metrics(ds, name):
    runs = load_runs(ds, name)
    if not runs:
        return None
    ms = []
    for r in runs:
        y, s = r['ytest'], r['test']
        p = s.argmax(1)
        top5 = np.mean([y[i] in np.argsort(-s[i])[:5] for i in range(len(y))])
        ms.append(dict(acc=accuracy_score(y, p), f1=f1_score(y, p, average='macro'), wf1=f1_score(y, p, average='weighted'), top5=top5))
    return {k: (np.mean([m[k] for m in ms]), np.std([m[k] for m in ms])) for k in ms[0]} | {'n': len(ms), 'per_seed': ms}


def mcnemar(y, s1, s2, thr=0.0, thr2=None):
    thr2 = thr if thr2 is None else thr2
    a = (s1 > thr) == y; b = (s2 > thr2) == y
    n01 = int(np.sum(a & ~b)); n10 = int(np.sum(~a & b))
    n = n01 + n10
    p = binomtest(min(n01, n10), n, 0.5).pvalue if n > 0 else 1.0
    return n01, n10, p


def certified_curve(r, M, fpr_t=0.01, rmax=10, kappa=None, split='test'):
    """Certified TPR(r): detected at the FPR threshold and radius V - kappa >= r (Theorem 2)."""
    gl = r[f'{split}_M{M}']; y = r['ytest'] if split == 'test' else r['yval']
    kappa = kappa or kappa_for(r['ds'], r['name'], M)
    s = vote_score(gl, M, kappa)
    _, thr = tpr_at(y, s, fpr_t)
    votes = (gl >= thr).sum(1)  # groups with score >= thr (roc thresholds are inclusive)
    radius = votes - kappa
    mal = y == 1
    return np.array([np.mean((radius[mal] >= rr)) for rr in range(rmax + 1)])
