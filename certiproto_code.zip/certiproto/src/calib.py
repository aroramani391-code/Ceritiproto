"""Validation-based decision thresholds (max F1 on the validation split) for every run; vote models also get
validation vote scores at their main partition count."""
from _root import ROOT
import os, sys, glob, pickle, numpy as np, torch
from sklearn.metrics import f1_score
import robust as RB, train as T
from data import load, splits
from cplib import OPT
from analyze import vote_score

MAIN_M = {'bmd': 16, 'clamp': 3}
M_LIST = {'bmd': (8, 16, 32), 'clamp': (2, 3, 4)}


def best_thr(y, s):
    cand = np.unique(np.quantile(s, np.linspace(0.01, 0.99, 197)))
    f = [f1_score(y, s > c) for c in cand]
    return float(cand[int(np.argmax(f))])


def run(ds):
    D = None
    import time
    for p in sorted(glob.glob(f'{ROOT}/results/{ds}/*_[0-9].pkl')):
        if time.time() - os.path.getmtime(p) < 90: continue
        r = pickle.load(open(p, 'rb'))
        changed = False
        name = r['name']
        if r['val'].ndim > 1: continue
        if 'thr' not in r:
            r['thr'] = best_thr(r['yval'], r['val']); changed = True
        M = MAIN_M[ds]
        if name in ('certiproto-ie', 'gnncert') and any(f'val_M{MM}' not in r for MM in M_LIST[ds]):
            if D is None:
                D = load(ds)
                for i, g in enumerate(D['graphs']): g._i = i
            tr, va, te = splits(ds, D, r['seed'])
            OPT['head'] = 'hybrid'; OPT['H'] = 32
            m, vmap = RB.load_graph_model(ds, name, r['seed'], D)
            gva = [D['graphs'][i] for i in va]
            for MM in M_LIST[ds]:
                if f'val_M{MM}' not in r:
                    r[f'val_M{MM}'] = T.predict(m, gva, vmap, None, MM)
            changed = True
        if changed:
            pickle.dump(r, open(p, 'wb'))
            print('calibrated', p, r['thr'], r.get('thr_main'))


if __name__ == '__main__':
    for ds in sys.argv[1].split(','):
        run(ds)
