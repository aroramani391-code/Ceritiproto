from _root import ROOT
import sys, os, train
ds, name = sys.argv[1], sys.argv[2]
train.CFG[ds].update(max_epochs=1, patience=5)
if ds == 'bmd': train.CFG[ds].update(epoch_size=300)
train.OUT = f'{ROOT}/dbg_smoke'
os.makedirs(train.OUT + '/' + ds, exist_ok=True)
for f in os.listdir(train.OUT + '/' + ds): os.remove(train.OUT + '/' + ds + '/' + f)
train.run(ds, name, 0, extra_epochs_head=0)
