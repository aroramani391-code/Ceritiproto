import numpy as np, torch
from cplib import NT, NUMF


def collate_fast(graphs, M=1, groups=None):
    """Vectorised hash-partitioned batching (equivalent to cplib.collate)."""
    from cplib import collate as slow
    if M == 1:
        return slow(graphs, 1)
    nt, ti, bo, par, gidx, numrows, numvals = [], [], [], [], [], [], []
    off = 0
    nvirt = 0
    owner = []
    ROOT, HUB = NT['ROOT'], NT['HUB']
    for b, G in enumerate(graphs):
        n = len(G.ntype)
        is_hub = G.ntype == HUB
        is_leaf = (G.ntype != ROOT) & ~is_hub
        grp = np.where(G.hkey != 0, G.hkey % M, -1)
        Lidx = np.nonzero(is_leaf)[0]; gl = grp[Lidx]
        lp = G.parent[Lidx]
        hubs = np.nonzero(is_hub)[0]
        own = hubs[G.hkey[hubs] != 0]
        hp = lp >= 0
        hub_child = hp & (G.ntype[np.maximum(lp, 0)] == HUB)
        keys = np.concatenate([own * M + grp[own], lp[hub_child] * M + gl[hub_child]])
        if groups is not None:
            g0 = groups[b]
            keep_leaf = gl == g0
            Lidx, gl, lp, hub_child = Lidx[keep_leaf], gl[keep_leaf], lp[keep_leaf], hub_child[keep_leaf]
            keys = keys[keys % M == g0]
            gset = np.array([g0]); vbase = nvirt
            root_of_g = lambda g: np.zeros_like(g)
            nroot = 1
        else:
            gset = np.arange(M); vbase = nvirt
            root_of_g = lambda g: g
            nroot = M
        uk = np.unique(keys)
        hh, hg = uk // M, uk % M
        root_base = off; hub_base = off + nroot; leaf_base = hub_base + len(uk)
        # roots
        nt.append(np.full(nroot, ROOT)); ti.append(np.full(nroot, G.tidx[0])); bo.append(np.full(nroot, G.boff[0]))
        par.append(np.full(nroot, -1)); gidx.append(vbase + np.arange(nroot))
        # hub copies (parent is the root copy of the same group)
        nt.append(G.ntype[hh]); ti.append(G.tidx[hh]); bo.append(G.boff[hh])
        par.append(root_base + root_of_g(hg)); gidx.append(vbase + root_of_g(hg))
        # leaves
        lpar = np.where(hub_child, hub_base + np.searchsorted(uk, np.maximum(lp, 0) * M + gl), root_base + root_of_g(gl))
        nt.append(G.ntype[Lidx]); ti.append(G.tidx[Lidx]); bo.append(G.boff[Lidx])
        par.append(lpar); gidx.append(vbase + root_of_g(gl))
        if len(G.num_idx):
            pos_in_leaf = -np.ones(n, np.int64); pos_in_leaf[Lidx] = np.arange(len(Lidx))
            m = pos_in_leaf[G.num_idx]; ok = m >= 0
            if ok.any():
                numrows.append(leaf_base + m[ok]); numvals.append(G.num_val[ok])
        for g in gset: owner.append((b, int(g)))
        nvirt += nroot
        off = leaf_base + len(Lidx)
    batch = dict(ntype=torch.from_numpy(np.concatenate(nt).astype(np.int64)), tidx=torch.from_numpy(np.concatenate(ti).astype(np.int64)),
                 boff=torch.from_numpy(np.concatenate(bo).astype(np.int64)), parent=torch.from_numpy(np.concatenate(par).astype(np.int64)),
                 gidx=torch.from_numpy(np.concatenate(gidx).astype(np.int64)), nvirt=nvirt, owner=owner)
    num = torch.zeros(off, NUMF)
    if numrows:
        num[torch.from_numpy(np.concatenate(numrows))] = torch.from_numpy(np.concatenate(numvals))
    batch['num'] = num
    return batch
