"""Structural perturbation attacks on parsed component graphs (insertion and edit operations of the
threat model) and helpers to reload trained models. Attacks act on parsed metadata only."""
from _root import ROOT
import os, sys, copy, math, pickle, collections, random, time
import numpy as np, torch, scipy.sparse as sp, lightgbm as lgb, zlib
from cplib import *
from cplib import OPT
from data import load, splits
import train as T
import flat as FL

RES = f'{ROOT}/results'


def load_graph_model(ds, name, seed, D):
    ck = torch.load(f'{RES}/{ds}/{name}_{seed}.pt', weights_only=False)
    cfg = T.CFG[ds]
    tt = D['tt']
    OPT['relax'] = '-relax' in name
    if '-protoonly' in name: OPT['head'] = 'proto'
    if name.startswith('nngcn'): OPT['head'] = 'meanlin'
    if '-H1' in name: OPT['H'] = 1
    m = T.make_model(name, ck['V'], tt.ngrams(), cfg, ck['C'], D['glob'].shape[1])
    m.load_state_dict(ck['state']); m.eval()
    m.enc.tb.copy_(torch.from_numpy(tt.buckets(OPT['H'])))
    return m, ck['vmap']


def vote_score(group_logits, M, kappa=None):
    k = kappa or (M // 2 + 1)
    return np.sort(group_logits, axis=-1)[..., ::-1][..., k - 1]


class GraphScorer:
    def __init__(self, model, vmap, glob_all=None, M=1, kappa=None):
        self.m, self.vmap, self.glob, self.M, self.kappa = model, vmap, glob_all, M, kappa

    @torch.no_grad()
    def __call__(self, gs, bs=256):
        out = []
        bs = max(8, bs // self.M) if self.M > 1 else bs
        for k in range(0, len(gs), bs):
            sub = gs[k:k + bs]
            lo, _ = T.forward(self.m, sub, self.vmap, self.glob, self.M)
            lo = lo.double().numpy()
            if self.M > 1:
                lo = vote_score(lo.reshape(len(sub), self.M), self.M, self.kappa)
            out.append(lo)
        return np.concatenate(out)


class FlatScorer:
    def __init__(self, ds, name, seed, D):
        self.D = D; self.tt = D['tt']
        self.h = np.array([zlib.crc32(t.encode('utf-8', 'replace')) % FL.NH for t in self.tt.toks], np.int64)
        graphs = D['graphs']
        self.cnt_fields = sorted({self.tt.toks[t] for g in graphs for t, ty in zip(g.tidx, g.ntype) if ty == NT['CNT']})
        self.cidx = {f: i for i, f in enumerate(self.cnt_fields)}
        self.mono = name == 'lgbm-mono'
        self.kind = 'mlp' if name.startswith('mlp') else 'lgb'
        if self.kind == 'lgb':
            self.bst = lgb.Booster(model_file=f'{RES}/{ds}/{name}_{seed}.lgb')
        else:
            raise NotImplementedError

    def featurize(self, gs):
        rows, cols = [], []
        C = np.zeros((len(gs), len(self.cnt_fields)), np.float32)
        for i, g in enumerate(gs):
            nonc = (g.ntype != NT['ROOT']) & (g.ntype != NT['CNT'])
            c = np.unique(self.h[g.tidx[nonc]])
            rows.append(np.full(len(c), i)); cols.append(c)
            for j, v in zip(g.num_idx, g.num_val):
                if g.ntype[j] == NT['CNT']:
                    C[i, self.cidx[self.tt.toks[g.tidx[j]]]] = v[0]
        X = sp.csr_matrix((np.ones(sum(len(c) for c in cols), np.float32), (np.concatenate(rows), np.concatenate(cols))), shape=(len(gs), FL.NH))
        blocks = [X, sp.csr_matrix(C)]
        if not self.mono:
            blocks.append(sp.csr_matrix(np.stack([self.D['glob'][g._i] for g in gs])))
        return sp.hstack(blocks).tocsr()

    def __call__(self, gs):
        return self.bst.predict(self.featurize(gs), raw_score=True)


# ------------------------------------------------------------------ graph edits

def clone(g):
    h = Graph()
    for k in ('ntype', 'tidx', 'boff', 'parent', 'hkey', 'num_idx', 'num_val'):
        setattr(h, k, getattr(g, k).copy())
    h.label, h.gid, h.meta, h._i = g.label, g.gid, g.meta, g._i
    return h


def add_node(g, ntype, tidx, parent, hkey, boff=-1, num=None):
    h = clone(g)
    h.ntype = np.append(h.ntype, ntype); h.tidx = np.append(h.tidx, tidx); h.boff = np.append(h.boff, boff)
    h.parent = np.append(h.parent, parent); h.hkey = np.append(h.hkey, hkey)
    if num is not None:
        h.num_idx = np.append(h.num_idx, len(h.ntype) - 1)
        v = np.zeros((1, NUMF), np.float32); v[0, :len(num)] = num
        h.num_val = np.vstack([h.num_val, v])
    return h


def remove_node(g, idx):
    keep = np.ones(len(g.ntype), bool); keep[idx] = False
    remap = -np.ones(len(g.ntype), np.int64); remap[keep] = np.arange(keep.sum())
    h = clone(g)
    for k in ('ntype', 'tidx', 'boff', 'hkey'):
        setattr(h, k, getattr(g, k)[keep])
    p = g.parent[keep]; h.parent = np.where(p >= 0, remap[np.maximum(p, 0)], -1)
    ok = keep[g.num_idx] if len(g.num_idx) else np.zeros(0, bool)
    h.num_idx = remap[g.num_idx[ok]] if len(g.num_idx) else g.num_idx
    h.num_val = g.num_val[ok] if len(g.num_idx) else g.num_val
    return h


def replace_token(g, idx, tidx, hkey=None):
    h = clone(g); h.tidx[idx] = tidx; h.boff[idx] = -1
    if hkey is not None: h.hkey[idx] = hkey
    return h


def set_num(g, idx, vals):
    h = clone(g)
    j = np.nonzero(h.num_idx == idx)[0]
    if len(j):
        h.num_val[j[0], :len(vals)] = vals
    return h


class Ops:
    """Insertion and edit operations allowed by the threat model, with candidate pools from training data."""

    def __init__(self, ds, D, tr):
        self.ds, self.D, self.tt = ds, D, D['tt']
        tt = self.tt; graphs = D['graphs']
        gtr = [graphs[i] for i in tr]
        ben = [g for g in gtr if g.label == 0]; mal = [g for g in gtr if g.label == 1]
        def freq(gs, types):
            c = collections.Counter()
            for g in gs:
                sel = np.isin(g.ntype, types)
                c.update(set(g.tidx[sel].tolist()))
            return c
        ins_types = [NT['API'], NT['FLAG'], NT['SIG']]
        cb, cm = freq(ben, ins_types), freq(mal, ins_types)
        score = {t: math.log((cb[t] + 1) / len(ben)) - math.log((cm[t] + 1) / len(mal)) for t in cb if cb[t] >= max(20, 0.005 * len(ben))}
        self.ins = sorted(score, key=lambda t: -score[t])[:80]
        # DLL of each API candidate (most common in goodware)
        self.api_dll = {}
        dll_c = collections.defaultdict(collections.Counter)
        for g in ben:
            for j in np.nonzero(g.ntype == NT['API'])[0]:
                p = g.parent[j]
                if p > 0 and g.ntype[p] == NT['HUB'] and g.tidx[j] in score:
                    dll_c[g.tidx[j]][g.tidx[p]] += 1
        for t, c in dll_c.items():
            self.api_dll[t] = c.most_common(1)[0][0]
        # benign-typical header values per field
        self.hdr_vals = collections.defaultdict(collections.Counter)
        for g in ben:
            for j in np.nonzero(g.ntype == NT['HDR'])[0]:
                f = tt.toks[g.tidx[j]].split('=')[0]
                self.hdr_vals[f][g.tidx[j]] += 1
        self.hdr_top = {f: [t for t, _ in c.most_common(3)] for f, c in self.hdr_vals.items()}
        # benign section-entropy medians (ClaMP .text/.data attributes)
        self.sec_med = {}
        for g in ben:
            for j, v in zip(g.num_idx, g.num_val):
                if g.ntype[j] == NT['SEC']:
                    self.sec_med.setdefault(tt.toks[g.tidx[j]], []).append(v.copy())
        self.sec_med = {k: np.median(np.stack(v), 0) for k, v in self.sec_med.items()}

    def insertions(self, g):
        tt = self.tt; present = set(g.tidx.tolist()); out = []
        for t in self.ins:
            if t in present: continue
            tok = tt.toks[t]
            ty = NT['API'] if tok.startswith('api:') else NT['FLAG'] if tok.startswith('flag:') else NT['SIG']
            if ty == NT['API']:
                dll = self.api_dll.get(t)
                if dll is None: continue
                hubs = np.nonzero((g.ntype == NT['HUB']) & (g.tidx == dll))[0]
                dname = tt.toks[dll][4:]
                if len(hubs):
                    out.append(('ins', lambda g, t=t, p=int(hubs[0]), d=dname: add_node(g, ty, t, p, h64(tt.toks[t] + '@' + d))))
                else:
                    def f(g, t=t, dll=dll, d=dname):
                        g2 = add_node(g, NT['HUB'], dll, 0, h64(tt.toks[dll]))
                        return add_node(g2, NT['API'], t, len(g2.ntype) - 1, h64(tt.toks[t] + '@' + d))
                    out.append(('ins', f))
            else:
                par = 0
                if self.ds == 'clamp':
                    grp = 'grp:FILE' if 'FH_' in tok else 'grp:OPT' if 'OH_' in tok else 'grp:SEC'
                    hubs = np.nonzero(g.tidx == tt.idx[grp])[0]; par = int(hubs[0]) if len(hubs) else 0
                out.append(('ins', lambda g, t=t, ty=ty, par=par: add_node(g, ty, t, par, h64(tt.toks[t]))))
        mode = os.environ.get('ATK_INS', 'all')
        if mode == 'grow':
            return [('ins', self.grow)]      # only grow monotone size counts: no new nodes
        if mode == 'nodes':
            return out                        # only add components: counts untouched
        out.append(('ins', self.grow))
        return out

    def grow(self, g):
        """A new section: section count +1 and size-type counts grow by 64 KiB (monotone fields only)."""
        h = clone(g)
        for k, j in enumerate(h.num_idx):
            if h.ntype[j] != NT['CNT']: continue
            f = self.tt.toks[h.tidx[j]][4:]
            v = math.expm1(h.num_val[k, 0] * LOGSCALE)
            if f in ('NumberOfSections', 'n_sections', 'non_sus_sections'):
                v += 1
            elif f in ('Size', 'SizeOfImage', 'SizeOfInitializedData', 'filesize', 'size', 'vsize'):
                v += 65536
            else:
                continue
            h.num_val[k, 0] = math.log1p(v) / LOGSCALE
        return h

    def edits(self, g, rng, max_del=40):
        tt = self.tt; out = []
        dels = [j for j in range(len(g.ntype)) if g.ntype[j] in (NT['API'], NT['FLAG'], NT['SIG'])]
        if len(dels) > max_del:
            dels = list(rng.choice(dels, max_del, replace=False))
        for j in dels:
            out.append(('edit', lambda g, j=int(j): remove_node(g, j)))
        for j in np.nonzero(g.ntype == NT['HDR'])[0]:
            f = tt.toks[g.tidx[j]].split('=')[0]
            for t in self.hdr_top.get(f, []):
                if t != g.tidx[j]:
                    out.append(('edit', lambda g, j=int(j), t=t: replace_token(g, j, t)))
        for k, j in enumerate(g.num_idx):
            if g.ntype[j] == NT['SEC'] and tt.toks[g.tidx[j]] in self.sec_med:
                med = self.sec_med[tt.toks[g.tidx[j]]]
                out.append(('edit', lambda g, j=int(j), med=med: set_num(g, j, med)))
        return out


def greedy_attack(g, scorer, tau, ops, K_ins, R_edit, rng):
    """White-box greedy search over threat-model operations; returns (evaded, insertions, edits)."""
    cur = g; s = scorer([cur])[0]
    ni = ne = 0
    while s > tau and (ni < K_ins or ne < R_edit):
        cands = []
        if ni < K_ins: cands += ops.insertions(cur)
        if ne < R_edit: cands += ops.edits(cur, rng)
        if not cands: break
        gs = [f(cur) for _, f in cands]
        sc = scorer(gs)
        b = int(np.argmin(sc))
        if sc[b] >= s - 1e-9: break
        cur, s = gs[b], sc[b]
        if cands[b][0] == 'ins': ni += 1
        else: ne += 1
    return bool(s <= tau), ni, ne
