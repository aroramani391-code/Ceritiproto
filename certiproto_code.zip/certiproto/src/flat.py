"""Flat-feature baselines: LightGBM, monotone LightGBM (Incer-style) and an MLP on hashed component tokens."""
from _root import ROOT
import sys, os, time, pickle, zlib, numpy as np, scipy.sparse as sp, torch, torch.nn as nn, torch.nn.functional as F
import lightgbm as lgb
from sklearn.metrics import roc_auc_score, accuracy_score, f1_score
from cplib import NT
from data import load, splits, motif_label_map

OUT = f'{ROOT}/results'
NH = 1 << 14


def flat_matrix(D, mono_only=False):
    """Binary presence of hashed component tokens + log counts (+ non-monotone global features)."""
    tt = D['tt']; graphs = D['graphs']
    h = np.array([zlib.crc32(t.encode('utf-8', 'replace')) % NH for t in tt.toks], np.int64)
    rows, cols = [], []
    cnt_fields = sorted({tt.toks[t] for g in graphs for t, ty in zip(g.tidx, g.ntype) if ty == NT['CNT']})
    cidx = {f: i for i, f in enumerate(cnt_fields)}
    C = np.zeros((len(graphs), len(cnt_fields)), np.float32)
    for i, g in enumerate(graphs):
        leaf = g.ntype != NT['ROOT']
        nonc = leaf & (g.ntype != NT['CNT'])
        c = np.unique(h[g.tidx[nonc]])
        rows.append(np.full(len(c), i)); cols.append(c)
        for j, v in zip(g.num_idx, g.num_val):
            if g.ntype[j] == NT['CNT']:
                C[i, cidx[tt.toks[g.tidx[j]]]] = v[0]
    X = sp.csr_matrix((np.ones(sum(len(c) for c in cols), np.float32), (np.concatenate(rows), np.concatenate(cols))), shape=(len(graphs), NH))
    blocks = [X, sp.csr_matrix(C)]
    nmono = NH + C.shape[1]
    if not mono_only:
        blocks.append(sp.csr_matrix(D['glob']))
    return sp.hstack(blocks).tocsr(), nmono


def run_lgb(ds, name, seed):
    D = load(ds); graphs = D['graphs']
    tr, va, te = splits(ds, D, seed)
    y = np.array([g.label for g in graphs])
    mono = name == 'lgbm-mono'
    if ds == 'motif':
        lmap = motif_label_map(D); y = np.array([lmap.get(v, -1) for v in y])
        X = np.fromfile(f'{ROOT}/data/MOTIF/dataset/X_train.dat', dtype=np.float32).reshape(-1, 2381)
        params = dict(objective='multiclass', num_class=len(lmap), learning_rate=0.3, num_leaves=15, min_data_in_leaf=1,
                      min_sum_hessian_in_leaf=1e-3, feature_fraction=0.2, max_bin=63, lambda_l2=1.0, metric='multi_error',
                      verbose=-1, seed=seed, num_threads=1)
        if not name.startswith('lgbm-ember'):
            return
    else:
        X, nmono = flat_matrix(D, mono_only=mono)
        params = dict(objective='binary', learning_rate=0.05, num_leaves=64, min_data_in_leaf=20, feature_fraction=0.5,
                      bagging_fraction=0.8, bagging_freq=1, verbose=-1, seed=seed, num_threads=2)
        if mono:
            params['monotone_constraints'] = [1] * X.shape[1]
            params['monotone_constraints_method'] = 'intermediate'
    t0 = time.time()
    dtr = lgb.Dataset(X[tr], y[tr]); dva = lgb.Dataset(X[va], y[va])
    rec = {}
    bst = lgb.train(params, dtr, num_boost_round=2000 if ds != 'motif' else 150, valid_sets=[dva],
                    callbacks=[lgb.early_stopping(50 if ds != 'motif' else 30, verbose=False), lgb.record_evaluation(rec)])
    t1 = time.time()
    pv = bst.predict(X[va], num_iteration=bst.best_iteration); pt = bst.predict(X[te], num_iteration=bst.best_iteration)
    infer = (time.time() - t1) / (len(va) + len(te)) * 1000
    if ds != 'motif':
        pv, pt = np.log(pv / (1 - pv + 1e-12) + 1e-12), np.log(pt / (1 - pt + 1e-12) + 1e-12)
        print(ds, name, seed, 'test AUC', roc_auc_score(y[te], pt), 'iters', bst.best_iteration)
    else:
        pv, pt = np.log(pv + 1e-12), np.log(pt + 1e-12)
        print(ds, name, seed, 'acc', accuracy_score(y[te], pt.argmax(1)), 'f1', f1_score(y[te], pt.argmax(1), average='macro'))
    metric = list(rec['valid_0'].keys())[0]
    hist = [dict(epoch=i + 1, val_loss=v) for i, v in enumerate(rec['valid_0'][metric])]
    res = dict(ds=ds, name=name, seed=seed, tr=tr, va=va, te=te, val=pv, test=pt, yval=y[va], ytest=y[te], hist=hist,
               train_time=t1 - t0, infer_ms=infer, model_str=None)
    os.makedirs(f'{OUT}/{ds}', exist_ok=True)
    pickle.dump(res, open(f'{OUT}/{ds}/{name}_{seed}.pkl', 'wb'))
    bst.save_model(f'{OUT}/{ds}/{name}_{seed}.lgb')


class MLP(nn.Module):
    def __init__(self, nin, C, d=256):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(nin, d), nn.ReLU(), nn.Dropout(0.2), nn.Linear(d, 128), nn.ReLU(), nn.Dropout(0.2), nn.Linear(128, C))

    def forward(self, x):
        return self.net(x)


def run_mlp(ds, name, seed):
    torch.manual_seed(seed); np.random.seed(seed)
    D = load(ds); graphs = D['graphs']
    tr, va, te = splits(ds, D, seed)
    y = np.array([g.label for g in graphs])
    if ds == 'motif':
        lmap = motif_label_map(D); y = np.array([lmap.get(v, -1) for v in y]); C = len(lmap)
        X = np.fromfile(f'{ROOT}/data/MOTIF/dataset/X_train.dat', dtype=np.float32).reshape(-1, 2381)
        X = np.sign(X) * np.log1p(np.abs(X))
        mu, sd = X[tr].mean(0), X[tr].std(0) + 1e-6; X = (X - mu) / sd
        Xd = torch.tensor(X)
    else:
        C = 1
        Xs, _ = flat_matrix(D)
        Xs = Xs.tocsr().astype(np.float32)

        class SparseRows:
            shape = Xs.shape
            def __getitem__(self, idx):
                sub = Xs[idx].tocoo()
                return torch.sparse_coo_tensor(np.vstack([sub.row, sub.col]), sub.data, sub.shape).to_dense()
        Xd = SparseRows()
    yt = torch.tensor(y)
    model = MLP(Xd.shape[1], C); opt = torch.optim.Adam(model.parameters(), 1e-3, weight_decay=1e-5)
    best, bstate, bad, hist = -1, None, 0, []
    t0 = time.time()
    for ep in range(60):
        model.train(); perm = np.random.permutation(tr); tl = 0
        for k in range(0, len(perm), 128):
            idx = perm[k:k + 128]
            out = model(Xd[idx])
            loss = F.binary_cross_entropy_with_logits(out.squeeze(1), yt[idx].float()) if C == 1 else F.cross_entropy(out, yt[idx])
            opt.zero_grad(); loss.backward(); opt.step(); tl += loss.item() * len(idx)
        model.eval()
        with torch.no_grad():
            ov = model(Xd[va])
        if C == 1:
            vl = F.binary_cross_entropy_with_logits(ov.squeeze(1), yt[va].float()).item(); score = roc_auc_score(y[va], ov.squeeze(1).numpy())
            vacc = accuracy_score(y[va], ov.squeeze(1).numpy() > 0)
        else:
            vl = F.cross_entropy(ov, yt[va]).item(); score = accuracy_score(y[va], ov.argmax(1).numpy()); vacc = score
        hist.append(dict(epoch=ep + 1, train_loss=tl / len(tr), val_loss=vl, val_auc=score, val_acc=vacc))
        if score > best + 1e-5:
            best, bad = score, 0; bstate = {k: v.clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
            if bad >= 8: break
    model.load_state_dict(bstate); model.eval()
    t1 = time.time()
    with torch.no_grad():
        pv = model(Xd[va]).squeeze(1).double().numpy() if C == 1 else model(Xd[va]).double().numpy()
        pt = model(Xd[te]).squeeze(1).double().numpy() if C == 1 else model(Xd[te]).double().numpy()
    infer = (time.time() - t1) / (len(va) + len(te)) * 1000
    print(ds, name, seed, 'test', roc_auc_score(y[te], pt) if C == 1 else accuracy_score(y[te], pt.argmax(1)))
    res = dict(ds=ds, name=name, seed=seed, tr=tr, va=va, te=te, val=pv, test=pt, yval=y[va], ytest=y[te], hist=hist,
               train_time=t1 - t0, infer_ms=infer)
    os.makedirs(f'{OUT}/{ds}', exist_ok=True)
    pickle.dump(res, open(f'{OUT}/{ds}/{name}_{seed}.pkl', 'wb'))


if __name__ == '__main__':
    ds, name = sys.argv[1], sys.argv[2]
    seeds = [int(s) for s in sys.argv[3].split(',')] if len(sys.argv) > 3 else [0, 1, 2, 3, 4]
    for s in seeds:
        if os.path.exists(f'{OUT}/{ds}/{name}_{s}.pkl'):
            continue
        (run_mlp if name.startswith('mlp') else run_lgb)(ds, name, s)
