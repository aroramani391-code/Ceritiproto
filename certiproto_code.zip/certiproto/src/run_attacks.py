"""Greedy structural attacks (insertion-only and insertion + edits) against seed-0 models."""
from _root import ROOT
import sys, os, pickle, time, numpy as np, torch
from cplib import OPT
import robust as RB
from data import load, splits
import train as T

ds = sys.argv[1]
models = sys.argv[2].split(',')
N = int(sys.argv[3]) if len(sys.argv) > 3 else 200
OUTD = os.environ.get('ATK_OUT', f'{ROOT}/results/{ds}/attacks')
KINS = int(os.environ.get('ATK_KINS', 25))
PICK = None
if os.environ.get('ATK_PICK'):
    PICK = pickle.load(open(os.environ['ATK_PICK'], 'rb'))
DOMIX = os.environ.get('ATK_NOMIX', '') == ''
REDIT = int(os.environ.get('ATK_REDIT', 4))
MIXINS = int(os.environ.get('ATK_MIXINS', 15))
os.makedirs(OUTD, exist_ok=True)
D = load(ds)
graphs = D['graphs']
for i, g in enumerate(graphs): g._i = i
tr, va, te = splits(ds, D, 0)
ops = RB.Ops(ds, D, tr)
gva = [graphs[i] for i in va]; gte = [graphs[i] for i in te]
yva = np.array([g.label for g in gva])

for name in models:
    out = f'{OUTD}/{name}.pkl'
    if os.path.exists(out):
        print('skip', name); continue
    t0 = time.time()
    M = {'bmd': 16, 'clamp': 3}[ds] if name in ('certiproto-ie', 'gnncert') else 1
    if name.startswith('lgbm'):
        scorer = RB.FlatScorer(ds, name, 0, D)
    else:
        OPT['head'] = 'meanlin' if name.startswith('nngcn') else 'hybrid'; OPT['H'] = 32
        m, vmap = RB.load_graph_model(ds, name, 0, D)
        import analyze as AN
        kappa = AN.kappa_for(ds, name, M) if M > 1 else None
        scorer = RB.GraphScorer(m, vmap, D['glob'] if name.startswith('twin') else None, M=M, kappa=kappa)
    sv = scorer(gva)
    neg = np.sort(sv[yva == 0])
    tau = neg[int(np.ceil(0.99 * len(neg))) - 1]  # 1% FPR on validation goodware
    st = scorer(gte)
    det = [i for i, g in enumerate(gte) if g.label == 1 and st[i] > tau]
    rng = np.random.RandomState(0)
    if PICK is not None:
        # paired evaluation: every model is attacked on the same programs
        pick = [i for i in PICK if i in set(det)]
    else:
        n = N if M == 1 else N // 2
        pick = rng.choice(det, min(n, len(det)), replace=False)
    res = dict(name=name, pick=[int(x) for x in pick], K_ins=KINS, R_edit=REDIT, mix_ins=MIXINS, tau=float(tau), n_detected=len(det), n_mal=int(sum(g.label for g in gte)), ins=[], mix=[], radius=[], kappa=kappa if M > 1 else None)
    for k, i in enumerate(pick):
        g = gte[i]
        if M > 1:
            with torch.no_grad():
                gl, _ = T.forward(scorer.m, [g], scorer.vmap, None, M)
            res['radius'].append(int((gl.double().numpy() > tau).sum()) - kappa)
        ev, ni, ne = RB.greedy_attack(g, scorer, tau, ops, K_ins=KINS, R_edit=0, rng=rng)
        res['ins'].append((ev, ni, ne))
        if DOMIX:
            ev2, ni2, ne2 = RB.greedy_attack(g, scorer, tau, ops, K_ins=MIXINS, R_edit=REDIT, rng=rng)
            res['mix'].append((ev2, ni2, ne2))
        else:
            res['mix'].append((0, 0, 0))
        if k % 20 == 0:
            print(name, k, np.mean([r[0] for r in res['ins']]), np.mean([r[0] for r in res['mix']]), f'{time.time() - t0:.0f}s', flush=True)
    res['time'] = time.time() - t0
    pickle.dump(res, open(out, 'wb'))
    print('DONE', name, 'ins evasion', np.mean([r[0] for r in res['ins']]), 'mix evasion', np.mean([r[0] for r in res['mix']]), f'{res["time"]:.0f}s', flush=True)
