"""CertiProto library: component graphs, partitioning, monotone and baseline models."""
import math, zlib, pickle, collections, random, time, os
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F

import os
torch.set_num_threads(int(os.environ.get('NTHREADS', '1')))
NT = dict(ROOT=0, HUB=1, API=2, HDR=3, FLAG=4, SIG=5, CNT=6, SEC=7, DD=8, EXP=9)
R = len(NT)
NUMF = 16
LOGSCALE = 25.0
NGRAM_BUCKETS = 1 << 16
OPT = dict(relax=os.environ.get('CP_RELAX', '0') == '1', cnt_knots=int(os.environ.get('CP_KNOTS', '0')), head=os.environ.get('CP_HEAD', 'hybrid'), H=int(os.environ.get('CP_H', '32')), bn=os.environ.get('CP_BN', '1') == '1', eps=float(os.environ.get('CP_EPS', '1e-2')), relscale=float(os.environ.get('CP_RELSCALE', '1.0')), L=int(os.environ.get('CP_L', '2')), act=os.environ.get('CP_ACT', 'relu'))


def h64(s):
    return zlib.crc32(s.encode('utf-8', 'replace')) * 2654435761 % (1 << 61) + zlib.adler32(s.encode('utf-8', 'replace'))


def bucket(v):
    try:
        return 'b%d' % int(math.log2(float(v) + 1))
    except Exception:
        return 'bx'


class TokenTable:
    """Global table of token strings; n-grams are computed once per token."""

    def __init__(self):
        self.idx = {}
        self.toks = []
        self.names = []

    def get(self, tok, name=None):
        i = self.idx.get(tok)
        if i is None:
            i = len(self.toks)
            self.idx[tok] = i
            self.toks.append(tok)
            self.names.append(name)
        return i

    def buckets(self, H):
        return np.array([zlib.crc32(t.encode('utf-8', 'replace')) % H for t in self.toks], np.int64)

    def ngrams(self, maxg=32):
        out = np.full((len(self.toks), maxg), -1, dtype=np.int64)
        for i, nm in enumerate(self.names):
            if not nm:
                continue
            s = '<' + nm.lower() + '>'
            gs = []
            for n in (3, 4, 5):
                for j in range(len(s) - n + 1):
                    gs.append(zlib.crc32(s[j:j + n].encode('utf-8', 'replace')) % NGRAM_BUCKETS)
            gs = list(dict.fromkeys(gs))[:maxg]
            out[i, :len(gs)] = gs
        return out


class Graph:
    __slots__ = ('ntype', 'tidx', 'boff', 'parent', 'hkey', 'num_idx', 'num_val', 'label', 'gid', 'meta', '_i', '_orig')


def build_graph(rec, tt, ds):
    """Convert a component record into a typed tree graph (root - hubs - leaves)."""
    ntype, tidx, boff, parent, hkey, num_idx, num_val = [], [], [], [], [], [], []

    def add(t, tok, par, key, name=None, backoff=None, num=None):
        ntype.append(NT[t]); tidx.append(tt.get(tok, name)); boff.append(tt.get(backoff) if backoff else -1)
        parent.append(par); hkey.append(h64(key) if key else 0)
        if num is not None:
            num_idx.append(len(ntype) - 1); v = np.zeros(NUMF, np.float32); v[:len(num)] = num; num_val.append(v)
        return len(ntype) - 1

    add('ROOT', 'ROOT', -1, None)
    hub_of = {}
    if ds == 'clamp':
        for g in ['DOS', 'FILE', 'OPT', 'SEC']:
            hub_of[g] = add('HUB', 'grp:' + g, 0, None, name=None)
        hub_of['ROOT'] = 0
    else:
        hub_of['ROOT'] = 0
    dll_idx = []
    for d in rec.get('dlls', []):
        dll_idx.append(add('HUB', 'dll:' + d, 0, 'dll:' + d, name=d))
    for a, j in rec.get('apis', []):
        par = dll_idx[j] if (j is not None and 0 <= j < len(dll_idx)) else 0
        dn = rec['dlls'][j] if par else ''
        add('API', 'api:' + a, par, 'api:' + a + '@' + dn, name=a)
    for item in rec.get('hdr', []):
        if ds == 'bmd':
            f, v = item; g = 'ROOT'
        else:
            g, f, v = item
        add('HDR', 'hdr:%s=%s' % (f, v), hub_of[g], 'hdr:' + f, backoff='hdr:%s~%s' % (f, bucket(v) if str(v).replace('.', '').isdigit() else 'x'))
    for item in rec.get('flags', []):
        if ds == 'bmd':
            g, f = 'ROOT', item
        else:
            g, f = item
        add('FLAG', 'flag:' + f, hub_of[g], 'flag:' + f)
    for s in rec.get('sigs', []):
        add('SIG', 'sig:' + s, hub_of['SEC'] if ds == 'clamp' else 0, 'sig:' + s, name=s)
    cnts = rec.get('counts', {})
    items = cnts.items() if isinstance(cnts, dict) else [((g, f), v) for g, f, v in cnts]
    for key, v in items:
        if isinstance(key, tuple):
            g, f = key
        else:
            g, f = 'ROOT', key
        add('CNT', 'cnt:' + f, hub_of[g], 'cnt:' + f, num=[math.log1p(max(v, 0.0)) / LOGSCALE])
    seen = collections.Counter()
    for g, name, attrs in rec.get('secs', []):
        k = seen[name]; seen[name] += 1
        attrs = attrs if isinstance(attrs, list) else [attrs / 8.0]
        add('SEC', 'sec:' + name, hub_of[g], 'sec:%s#%d' % (name, k), name=name, num=attrs)
    for g, name, sz in rec.get('dds', []):
        add('DD', 'dd:' + name, 0, 'dd:' + name, num=[sz])
    for e in rec.get('exports', []):
        add('EXP', 'exp:' + e, 0, 'exp:' + e, name=e)
    G = Graph()
    G.ntype = np.array(ntype, np.int64); G.tidx = np.array(tidx, np.int64); G.boff = np.array(boff, np.int64)
    G.parent = np.array(parent, np.int64); G.hkey = np.array(hkey, np.int64)
    G.num_idx = np.array(num_idx, np.int64); G.num_val = np.array(num_val, np.float32).reshape(-1, NUMF)
    G.label = rec['label']; G.gid = rec['id']; G.meta = None
    return G


def graph_tokens(G, tt):
    return [tt.toks[i] for i in G.tidx]


# ------------------------------------------------------------------ batching

def collate(graphs, M=1, groups=None):
    """Batch graphs. With M>1 every graph is split into M hash-partitioned subgraphs.
    groups: optional list of per-graph group index to keep (training on random groups)."""
    nt, ti, bo, par, gidx, numrows, numvals = [], [], [], [], [], [], []
    off = 0
    nvirt = 0
    owner = []  # virtual graph -> (batch index, group)
    for b, G in enumerate(graphs):
        n = len(G.ntype)
        if M == 1:
            nt.append(G.ntype); ti.append(G.tidx); bo.append(G.boff)
            p = G.parent.copy(); p[p >= 0] += off; par.append(p)
            gidx.append(np.full(n, nvirt, np.int64))
            if len(G.num_idx):
                numrows.append(G.num_idx + off); numvals.append(G.num_val)
            owner.append((b, 0)); nvirt += 1; off += n
            continue
        is_leaf = (G.ntype != NT['ROOT']) & ~((G.ntype == NT['HUB']))
        grp = np.where(G.hkey != 0, G.hkey % M, -1)
        hub = G.ntype == NT['HUB']
        keep_groups = range(M) if groups is None else [groups[b]]
        for g in keep_groups:
            leaf_sel = is_leaf & (grp == g)
            # hubs present if own identity hashes to g or a child leaf is in g
            child_par = G.parent[leaf_sel]
            hub_sel = hub & ((grp == g) | np.isin(np.arange(n), child_par))
            sel = leaf_sel | hub_sel
            sel[0] = True
            idx = np.nonzero(sel)[0]
            remap = -np.ones(n, np.int64); remap[idx] = np.arange(len(idx))
            p = G.parent[idx]
            p = np.where(p >= 0, remap[np.maximum(p, 0)], -1)
            # a leaf whose hub was not selected cannot happen (hub selected when child in g)
            p[p >= 0] += off
            nt.append(G.ntype[idx]); ti.append(G.tidx[idx]); bo.append(G.boff[idx]); par.append(p)
            gidx.append(np.full(len(idx), nvirt, np.int64))
            if len(G.num_idx):
                m = remap[G.num_idx]; ok = m >= 0
                if ok.any():
                    numrows.append(m[ok] + off); numvals.append(G.num_val[ok])
            owner.append((b, g)); nvirt += 1; off += len(idx)
    batch = dict(ntype=torch.from_numpy(np.concatenate(nt)), tidx=torch.from_numpy(np.concatenate(ti)),
                 boff=torch.from_numpy(np.concatenate(bo)), parent=torch.from_numpy(np.concatenate(par)),
                 gidx=torch.from_numpy(np.concatenate(gidx)), nvirt=nvirt, owner=owner)
    num = torch.zeros(off, NUMF)
    if numrows:
        num[torch.from_numpy(np.concatenate(numrows))] = torch.from_numpy(np.concatenate(numvals))
    batch['num'] = num
    return batch


# ------------------------------------------------------------------ models

def relaxed():
    """True in the 'relax' ablation: identical architecture with the sign constraints removed."""
    return bool(OPT.get('relax', False))


def pos(w):
    return w if relaxed() else F.softplus(w)


def posw(w):
    """Non-negative weight via absolute value (gradient-friendly reparameterisation)."""
    return w if relaxed() else w.abs()


def inv_softplus(x):
    return torch.log(torch.expm1(x.clamp_min(1e-6)))


class Encoder(nn.Module):
    """Per-node encoder of the node's own attributes. Count nodes use a monotone path when mono=True."""

    def __init__(self, vocab_size, ngram_table, d, mono):
        super().__init__()
        self.word = nn.Embedding(vocab_size, d)
        nn.init.normal_(self.word.weight, 0, 0.1)
        self.ngram = nn.EmbeddingBag(NGRAM_BUCKETS, d, mode='mean')
        nn.init.normal_(self.ngram.weight, 0, 0.1)
        self.register_buffer('ngt', torch.from_numpy(ngram_table))
        self.register_buffer('tb', torch.zeros(len(ngram_table), dtype=torch.long))
        self.type_emb = nn.Embedding(R, d)
        self.num_lin = nn.ModuleList([nn.Linear(NUMF, d) for _ in range(R)])
        self.cnt_a = nn.Embedding(vocab_size, d)  # per-field slope (made >=0 in mono mode)
        nn.init.normal_(self.cnt_a.weight, 0.5, 0.1)
        # monotone piecewise-linear count encoder: shared non-negative ramps at fixed knots
        self.nknots = OPT.get('cnt_knots', 0)
        if self.nknots:
            self.register_buffer('knots', torch.linspace(0.0, 0.9, self.nknots))
            self.cnt_ramp = nn.Parameter(torch.full((self.nknots, d), 1.0 / self.nknots))
        self.mono = mono
        self.bn = TypeBN(d) if (mono and OPT['bn']) else None
        self.use_ngram = True
        self.use_word = True

    def forward(self, b, vocab_map):
        tidx = b['tidx']
        wid = vocab_map[tidx]
        bid = torch.where(b['boff'] >= 0, vocab_map[b['boff'].clamp_min(0)], torch.zeros_like(wid))
        wid = torch.where((wid == 0) & (bid > 0), bid, wid)
        h = self.type_emb(b['ntype'])
        if self.use_word:
            h = h + self.word(wid)
        if self.use_ngram:
            ut, inv = torch.unique(tidx, return_inverse=True)
            g = self.ngt[ut]
            mask = g >= 0
            lens = mask.sum(1)
            has = lens > 0
            emb = torch.zeros(len(ut), h.shape[1])
            if has.any():
                flat = g[has][mask[has]]
                offs = torch.cat([torch.zeros(1, dtype=torch.long), lens[has].cumsum(0)[:-1]])
                emb[has] = self.ngram(flat, offs)
            h = h + emb[inv]
        num = b['num']
        nt = b['ntype']
        bias = torch.stack([l.bias for l in self.num_lin])  # [R, d]
        out = h + bias[nt]
        cnt_t = NT['CNT']
        for t in (NT['CNT'], NT['SEC'], NT['DD']):
            sel = nt == t
            if not sel.any():
                continue
            if t == cnt_t and self.mono:
                a = pos(self.cnt_a(wid[sel]))
                x = num[sel][:, :1]
                if self.nknots:
                    ramp = F.relu(x - self.knots.unsqueeze(0)) @ pos(self.cnt_ramp)  # [n, d], non-decreasing in x
                    out[sel] = h[sel] + a * ramp
                else:
                    out[sel] = h[sel] + a * x
            else:
                out[sel] = out[sel] + num[sel] @ self.num_lin[t].weight.t()
        if self.bn is not None:
            out = self.bn(out, nt)
        return F.relu(out)


def scatter_max(src, index, n):
    out = torch.zeros(n, src.shape[1], dtype=src.dtype)
    return out.scatter_reduce(0, index.unsqueeze(1).expand_as(src), src, reduce='amax', include_self=True)


def scatter_mean(src, index, n):
    out = torch.zeros(n, src.shape[1], dtype=src.dtype)
    return out.scatter_reduce(0, index.unsqueeze(1).expand_as(src), src, reduce='mean', include_self=False)


class TypeBN(nn.Module):
    """Per-node-type batch normalisation with a non-negative gain. At inference it is a fixed
    per-dimension affine map with positive slope, so it preserves monotonicity."""

    def __init__(self, d, momentum=0.05):
        super().__init__()
        self.g = nn.Parameter(inv_softplus(torch.ones(R, d)))
        self.beta = nn.Parameter(torch.zeros(R, d))
        self.register_buffer('mu', torch.zeros(R, d))
        self.register_buffer('var', torch.ones(R, d))
        self.momentum = momentum

    def forward(self, x, nt):
        d = x.shape[1]
        if self.training:
            cnt = torch.bincount(nt, minlength=R)
            c = cnt.clamp_min(1).to(x.dtype).unsqueeze(1)
            mu = torch.zeros(R, d, dtype=x.dtype).index_add(0, nt, x) / c
            var = torch.zeros(R, d, dtype=x.dtype).index_add(0, nt, (x - mu[nt]) ** 2) / c
            present = (cnt > 1).unsqueeze(1)
            with torch.no_grad():
                upd_mu = (1 - self.momentum) * self.mu + self.momentum * mu
                upd_var = (1 - self.momentum) * self.var + self.momentum * var
                self.mu.copy_(torch.where(present, upd_mu, self.mu))
                self.var.copy_(torch.where(present, upd_var, self.var))
            mu = torch.where(present, mu, self.mu); var = torch.where(present, var, self.var)
        else:
            mu, var = self.mu, self.var
        return pos(self.g)[nt] * (x - mu[nt]) / torch.sqrt(var[nt] + OPT['eps']) + self.beta[nt]


class MonoLayer(nn.Module):
    """Monotone heterogeneous message passing: non-negative weights, max aggregation per relation."""

    def __init__(self, d, mono=True, agg='max'):
        super().__init__()
        self.mono, self.agg = mono, agg
        init = lambda *s: nn.Parameter(torch.empty(*s).uniform_(0, 2.0 / s[-2]) if mono else torch.randn(*s) / math.sqrt(s[-2]))
        self.Wself = init(d, d)
        self.Wup = init(R, d, d)
        self.Wdown = init(d, d)
        self.b = nn.Parameter(torch.zeros(d) - (0.05 if mono else 0.0))
        self.bn = TypeBN(d) if (mono and OPT['bn']) else None

    def w(self, W):
        return posw(W) if self.mono else W

    def forward(self, z, b):
        par, nt = b['parent'], b['ntype']
        N, d = z.shape
        has = par >= 0
        child = torch.nonzero(has).squeeze(1)
        pidx = par[child]
        rel = nt[child]
        Wup = self.w(self.Wup)
        m = torch.empty(len(child), d)
        for t in torch.unique(rel).tolist():
            s = rel == t
            m[s] = z[child[s]] @ Wup[t]
        if self.agg in ('max', 'maxmean') and 'ch' in b:
            # hashed relation channels: max within (parent, type, channel), sum across channels and types
            key = (pidx * R + rel) * OPT['H'] + b['ch'][child]
            uk, inv = torch.unique(key, return_inverse=True)
            mx = scatter_max(m, inv, len(uk))
            tgt = uk // (R * OPT['H'])
            up = torch.zeros(N, d).index_add(0, tgt, mx)
            if self.agg == 'maxmean':
                up = up + torch.zeros(N, d).index_add(0, tgt, scatter_mean(m, inv, len(uk)))
        else:
            key = pidx * R + rel
            if self.agg == 'max':
                up = scatter_max(m, key, N * R).view(N, R, d).sum(1)
            elif self.agg == 'mean':
                up = scatter_mean(m, key, N * R).view(N, R, d).sum(1)
            else:
                up = (scatter_max(m, key, N * R) + scatter_mean(m, key, N * R)).view(N, R, d).sum(1)
        down = torch.zeros(N, d)
        down[child] = z[pidx] @ self.w(self.Wdown)
        pre = (z @ self.w(self.Wself) + up + down) * (OPT['relscale'] if self.mono else 1.0) + self.b
        if self.bn is not None:
            pre = self.bn(pre, nt)
        return F.relu(pre)


def graph_max(x, gidx, nvirt):
    return scatter_max(x, gidx, nvirt)


class ProtoHead(nn.Module):
    """Non-negative prototype MIL head with coverage similarity (monotone) or cosine (ablation)."""

    def __init__(self, d, K, C=1, sim='coverage'):
        super().__init__()
        self.K, self.C, self.sim = K, C, sim
        self.P = nn.Parameter(torch.rand(K, d) * 0.5)
        self.Q = nn.Parameter(torch.full((K, d), -1.0))
        self.Wout = nn.Parameter(torch.full((K, C), 4.0 / K) * (1 + 0.1 * torch.randn(K, C)))
        self.bias = nn.Parameter(torch.zeros(C))
        self.proto_src = [None] * K

    def protos(self):
        return self.P if relaxed() else F.relu(self.P)

    def node_sim(self, z, chunk=4096):
        P, Q = self.protos(), pos(self.Q)
        if self.sim == 'cosine':
            zn = F.normalize(z, dim=1); pn = F.normalize(P + 1e-6, dim=1)
            return zn @ pn.t()
        outs = []
        for i in range(0, z.shape[0], chunk):
            zz = z[i:i + chunk]
            # sum_d q_kd * min(z_d, p_kd) = (zz @ Q^T) - sum_d q_kd * relu(z_d - p_kd)
            a = zz @ Q.t()
            bterm = (F.relu(zz.unsqueeze(1) - P.unsqueeze(0)) * Q.unsqueeze(0)).sum(-1)
            outs.append(a - bterm)
        return torch.cat(outs)

    def norm(self):
        return (pos(self.Q) * self.protos()).sum(1).clamp_min(1e-6)

    def forward(self, z, gidx, nvirt):
        K = self.K
        with torch.no_grad():
            s = self.node_sim(z.detach())
            init = 0.0 if self.sim == 'coverage' else -2.0
            smax0 = torch.full((nvirt, K), init).scatter_reduce(0, gidx.unsqueeze(1).expand_as(s), s, 'amax', include_self=True)
            hit = s >= smax0[gidx] - 1e-7
            nid = torch.arange(len(z)).unsqueeze(1).expand_as(s)
            big = torch.full_like(nid, len(z))
            arg = torch.full((nvirt, K), len(z), dtype=torch.long).scatter_reduce(
                0, gidx.unsqueeze(1).expand_as(s), torch.where(hit, nid, big), 'amin', include_self=True)
        # recompute similarity with gradient only at the arg-max node of every (graph, prototype)
        sel = arg.clamp_max(len(z) - 1)
        zz = z[sel]  # [nvirt, K, d]
        P, Q = self.protos(), pos(self.Q)
        if self.sim == 'coverage':
            smax = (Q.unsqueeze(0) * torch.minimum(zz, P.unsqueeze(0))).sum(-1)
            smax = torch.where(arg < len(z), smax, torch.zeros_like(smax))
        else:
            smax = (F.normalize(zz, dim=-1) * F.normalize(P + 1e-6, dim=1).unsqueeze(0)).sum(-1)
        cov = smax / self.norm() if self.sim == 'coverage' else smax
        logits = cov @ posw(self.Wout) + self.bias
        return logits, cov, dict(s=s, arg=arg)


class CertiProto(nn.Module):
    def __init__(self, vocab_size, ngt, d=64, K=32, C=1, L=2, mono=True, agg='max', sim='coverage', nglob=0):
        super().__init__()
        self.enc = Encoder(vocab_size, ngt, d, mono)
        self.layers = nn.ModuleList([MonoLayer(d, mono, agg) for _ in range(OPT['L'] if mono else L)])
        self.head = ProtoHead(d, K, C, sim)
        self.ulin = nn.Parameter(torch.full((d, C), 1.0 / d))
        self.C = C

    def node_states(self, b, vmap):
        b['ch'] = self.enc.tb[b['tidx']]
        z = self.enc(b, vmap)
        for l in self.layers:
            z = l(z, b)
        return z

    def forward(self, b, vmap, glob=None):
        z = self.node_states(b, vmap)
        if OPT['head'] == 'meanlin':
            h = scatter_mean(z, b['gidx'], b['nvirt'])
            lo = h @ posw(self.ulin) + self.head.bias
            return (lo.squeeze(1) if self.C == 1 else lo), dict(z=z, cov=h, s=None, arg=None)
        if OPT['head'] == 'maxlin':
            h = graph_max(z, b['gidx'], b['nvirt'])
            lo = h @ posw(self.ulin) + self.head.bias
            return (lo.squeeze(1) if self.C == 1 else lo), dict(z=z, cov=h, s=None, arg=None)
        logits, cov, hs = self.head(z, b["gidx"], b["nvirt"])
        if OPT['head'] == 'hybrid':
            # axis-aligned (primitive) prototypes: coverage of e_d with unbounded prototype = max-pool of dim d
            h = graph_max(z, b['gidx'], b['nvirt'])
            logits = logits + h @ posw(self.ulin)
            hs['axis'] = h
        return (logits.squeeze(1) if self.C == 1 else logits), dict(z=z, cov=cov, s=hs["s"], arg=hs["arg"], axis=hs.get('axis'))


class GNNBase(nn.Module):
    """Unconstrained heterogeneous GNN baselines: mean aggregation + mean readout (R-GNN),
    attention aggregation + attention pooling (GAT), or max+mean twin with global features."""

    def __init__(self, vocab_size, ngt, d=64, C=1, L=2, kind='mean', nglob=0):
        super().__init__()
        self.kind = kind
        self.enc = Encoder(vocab_size, ngt, d, mono=False)
        agg = {'mean': 'mean', 'gat': 'mean', 'twin': 'maxmean'}[kind]
        self.layers = nn.ModuleList([MonoLayer(d, False, agg) for _ in range(L)])
        self.norms = nn.ModuleList([nn.LayerNorm(d) for _ in range(L)])
        if kind == 'gat':
            self.att_src = nn.ParameterList([nn.Parameter(torch.randn(d) * 0.1) for _ in range(L)])
            self.att_dst = nn.ParameterList([nn.Parameter(torch.randn(d) * 0.1) for _ in range(L)])
            self.Watt = nn.ModuleList([nn.Linear(d, d) for _ in range(L)])
            self.pool_gate = nn.Linear(d, 1)
        rin = 2 * d if kind == 'twin' else d
        self.nglob = nglob
        self.mlp = nn.Sequential(nn.Linear(rin + (nglob if kind == 'twin' else 0), d), nn.ReLU(), nn.Dropout(0.1), nn.Linear(d, C))
        self.C = C

    def gat_layer(self, l, z, b):
        par = b['parent']; N, d = z.shape
        child = torch.nonzero(par >= 0).squeeze(1); pidx = par[child]
        hz = self.Watt[l](z)
        e = F.leaky_relu((hz[child] * self.att_src[l]).sum(1) + (hz[pidx] * self.att_dst[l]).sum(1), 0.2)
        emax = torch.full((N,), -1e9).scatter_reduce(0, pidx, e, 'amax', include_self=True)
        a = torch.exp(e - emax[pidx])
        den = torch.zeros(N).scatter_add(0, pidx, a)
        a = a / den[pidx].clamp_min(1e-9)
        up = torch.zeros(N, d).index_add(0, pidx, a.unsqueeze(1) * hz[child])
        down = torch.zeros(N, d); down[child] = hz[pidx]
        return F.relu(hz + up + down)

    def forward(self, b, vmap, glob=None):
        b['ch'] = self.enc.tb[b['tidx']]
        z = self.enc(b, vmap)
        for l, layer in enumerate(self.layers):
            z = self.norms[l](self.gat_layer(l, z, b) if self.kind == 'gat' else layer(z, b))
        gi, nv = b['gidx'], b['nvirt']
        if self.kind == 'gatpool':
            g = self.pool_gate(z).squeeze(1)
            gmax = torch.full((nv,), -1e9).scatter_reduce(0, gi, g, 'amax', include_self=True)
            a = torch.exp(g - gmax[gi]); den = torch.zeros(nv).scatter_add(0, gi, a)
            a = a / den[gi]
            h = torch.zeros(nv, z.shape[1]).index_add(0, gi, a.unsqueeze(1) * z)
        elif self.kind in ('mean', 'gat'):
            h = scatter_mean(z, gi, nv)
        else:
            h = torch.cat([scatter_max(z, gi, nv), scatter_mean(z, gi, nv)], 1)
            if self.nglob:
                h = torch.cat([h, glob], 1)
        out = self.mlp(h)
        return (out.squeeze(1) if self.C == 1 else out), dict(z=z)


# ------------------------------------------------------------------ vocab

def build_vocab(train_graphs, tt, min_count=2):
    cnt = collections.Counter()
    for G in train_graphs:
        cnt.update(G.tidx.tolist()); cnt.update([x for x in G.boff.tolist() if x >= 0])
    vmap = np.zeros(len(tt.toks) + 1, np.int64)
    nxt = 1
    for t, c in cnt.items():
        if c >= min_count:
            vmap[t] = nxt; nxt += 1
    return torch.from_numpy(vmap), nxt


def extend_vmap(vmap, tt):
    if len(vmap) < len(tt.toks) + 1:
        vmap = torch.cat([vmap, torch.zeros(len(tt.toks) + 1 - len(vmap), dtype=torch.long)])
    return vmap
